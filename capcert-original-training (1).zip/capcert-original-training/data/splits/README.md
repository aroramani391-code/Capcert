# Splits

Splits live in the `split` column of each manifest rather than in separate
files, so that a sample and its split cannot drift apart.

- 70/10/20 train/val/test, stratified by label, and by family on BIG-2015.
- Exact duplicates removed by SHA-256.
- Near-duplicates — pairs whose canonical multisets have Jaccard similarity
  >= 0.9 — are kept in the *same* split, so that a near-copy of a training
  sample cannot appear in the test set.
- Hyperparameters are chosen on validation data only; the test split is used
  once per configuration.

EV6 derives three further splits from the same manifest without re-collecting
anything: temporal (by `collected`), family-disjoint (by `family`), and
cross-source (by `source`). See `experiments/ev6_generalization.py`.
