# Dataset manifests

One CSV per corpus, with the columns in `capcert.datasets.MANIFEST_FIELDS`:

```
sha256,label,family,split,source,collected,packer,compiler,packed_flag,selfmod_flag,path
```

The binaries are not redistributed. A manifest lets a reader who holds the
same files rebuild exactly the splits a run used, and lets anyone check that
two runs used the same data, without anyone shipping malware.

`template.csv` has the header and one example row. `docs/REAL_DATA.md` says
how to fill one in and how to verify it.

Three columns are easy to leave wrong and matter a great deal:

- **`source`** drives the cross-source split of EV6, which is the measurement
  that bounds how much of a result provenance could explain. A corpus whose
  two classes come from different places and whose `source` column says
  otherwise will report a cross-source result that means nothing.
- **`packed_flag` / `selfmod_flag`** drive assumption A1 and Table XXX. Left at
  zero, they silently fold the excluded population back into every headline
  figure.
