# Artifact checklist

What the reproduction repository is required to contain, and where each item
is. Three rows are **open**; they are open because they need the real corpora
or a release step, not because the code is missing, and saying so is part of
the artifact.

| Required | Where | State |
|---|---|---|
| Rust LFR, dependency accessor | `rust/lfr/` (accessor + tests), `capcert/lfr.py` (reference) | done |
| Canonicalization engine R1–R6 | `capcert/rewrite.py`, `capcert/canonical.py` | done |
| Hash partitioning | `capcert/partition.py` | done |
| Base classifier | `capcert/model.py` (torch and numpy backends) | done |
| Certified-margin objective | `capcert/model.py::mil_losses` (eq. 28–30) | done |
| TV1–TV5 scripts | `verification/tv1…tv5` | done |
| Termination verification | `verification/tv1_termination.py`, with `--emulate-name-order` negative control | done |
| Critical-pair joining sequences | `verification/tv2_critical_pairs.py`; count is whatever the corpus generates and is reported, not asserted | done |
| Z3 SMT obligations and logs | `verification/tv3_smt.py`; logs in `results/logs/tv3_smt/` | done |
| L0 audit and fault injection | `verification/tv4_conformance.py`, `verification/l0_fault_injection.py` | done |
| Dataset manifests, labels, splits, provenance, fingerprints | `data/manifests/` schema + template + loader/validator | **schema done, real manifests open** |
| Baselines: code or upstream commits, configs, 5-seed logs | `baselines/REGISTRY.yaml`, `baselines/configs/` | **registry and configs done; upstream commit pins and 5-seed logs open** |
| EV1–EV9 executable scripts | `experiments/` | done |
| Packed-binary evaluation | `experiments/ev_packed.py` | code done; **the Table XXX detection rate needs a measured run** |
| Statistical analysis | `capcert/stats.py`: Clopper–Pearson, bootstrap, paired bootstrap, McNemar, Wilcoxon, Holm–Bonferroni, mean/sd | done |
| Table and figure regeneration | `reporting/make_tables.py`, `reporting/make_figures.py` | done |
| Diff against the manuscript | `reporting/verify_against_manuscript.py`, `reporting/manuscript_values.yaml` | done |
| README, requirements, environment.yml, Cargo.lock, Dockerfile, pinned versions | repository root, `VERSIONS.lock` | done |
| Restricted component documented | `docs/RESTRICTED.md` | done |

## The three open rows

**Real manifests.** The corpora are not redistributable. The schema, loader,
validator and template are here; filling them is step 2 of
`docs/REAL_DATA.md`.

**Baseline pins and logs.** `REGISTRY.yaml` records what each of the fourteen
baselines is, which are re-implemented, what each re-implementation commits to,
and the reproduction gap against each published score. The `upstream.commit`
fields are `null` and must carry the hashes actually used before release; a
null means the pin was not recorded, not that any commit will do. The per-seed
metric logs come from running the baselines against the real corpora.

**Table XXX's detection rate.** No value for it exists in the manuscript or
here. `experiments/ev_packed.py` produces it, prints it in the shape the table
wants, and refuses to let a synthetic figure pass for a measured one.
`manuscript_values.yaml` records it as `null` rather than guessing.

## Claims a synthetic run settles outright

These do not depend on which corpus is used, and
`verify_against_manuscript.py` marks them apart from the rest:

- Theorem 1: every transformation in `T_inv` leaves the canonical form
  bit-identical (EV1, 100.00%);
- Corollary 1: every measured footprint lies within its family's bound (EV2,
  TV4);
- Theorem 2: a changed canonical function moves at most `k` buckets (TV4);
- Theorem 4: no certified sample flips inside its radius (TV4, EV4);
- Property L0: no byte is read outside `Dep_x(e)`, and the audit that checks
  it can fail (TV4 + fault injection);
- Lemma 2 / Newman: `mu` strictly decreases on every step, and every generated
  critical pair joins (TV1, TV2);
- rule soundness at 8/16/32/64 bits (TV3).
