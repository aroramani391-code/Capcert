# Original datasets referenced in the CAPCert manuscript

The CAPCert manuscript evaluates on three real malware corpora (Table XI) plus
a PDB ground-truth corpus for the recovery study. None of these are
redistributable, so the artifact ships only the *original training corpus*
(the generated reference corpus used for pipeline demonstration). To produce
`measured` results, obtain the corpora below yourself and point the pipeline
at them via `--manifest` as described in `docs/REAL_DATA.md`.

## 1. DikeDataset

Benign + malicious PE samples curated from VirusShare with per-file family
labels. Released publicly on GitHub by Octavian Iosifache and used in the
"dike" explainability thesis.

- Primary: [github.com/iosifache/DikeDataset](https://github.com/iosifache/DikeDataset)
- Parent project: [github.com/iosifache/dike](https://github.com/iosifache/dike)
- Hugging Face mirror: [huggingface.co/datasets/cycloevan/DikeDataset](https://huggingface.co/datasets/cycloevan/DikeDataset/blob/main/README.md)
- Record the snapshot commit SHA when you clone, and keep it in your
  manifest's `collected` column.

## 2. Dataset-K

Dataset-K is the PE / Windows API graph corpus used by MalGraph and in the
CAPCert comparison. It is the dataset of reference [7] of the manuscript
(MalGraph: Hierarchical Graph Neural Networks for Robust Windows Malware
Detection, INFOCOM 2021). It is not redistributed by its authors; request
access from them directly, or rebuild as **Dataset-K'** by the protocol in
Section VI-B of the manuscript.

- MalGraph paper (reference [7]): [nesa.zju.edu.cn/download/lx_pdf_malgraph.pdf](https://nesa.zju.edu.cn/download/lx_pdf_malgraph.pdf)
- Mal2GCN reproduction (uses the same corpus family): [arxiv.org/pdf/2108.12473](https://arxiv.org/pdf/2108.12473)
- MalSensor (Wu et al., TOSEM 2024) — same corpus family used for
  comparison: [wu-yueming.github.io/Files/TOSEM2024_MalSensor.pdf](https://wu-yueming.github.io/Files/TOSEM2024_MalSensor.pdf)

## 3. BIG-2015 (Microsoft Malware Classification Challenge)

Microsoft's family-classification corpus released for the 2015 Kaggle
competition. ~500 GB uncompressed; family-stratified splits are required
(Section VI-B).

- Kaggle competition: [kaggle.com/competitions/malware-classification](https://www.kaggle.com/competitions/malware-classification)
- Paper ("Microsoft Malware Classification Challenge", Ronen et al., 2018):
  [arxiv.org/abs/1802.10135](https://arxiv.org/pdf/1802.10135)
- Alternate mirror: [baselight.app/u/kaggle/dataset/dheemanthbhat_microsoft_malware_sample](https://baselight.app/u/kaggle/dataset/dheemanthbhat_microsoft_malware_sample)
- BIG 2015 conference page: [archives.iw3c2.org/www2015/big-2015/](https://archives.iw3c2.org/www2015/big-2015/)

## 4. PDB ground truth for recovery (Table XXI)

Not a published corpus. Build it per Section VI-G: open-source Windows
projects compiled with MSVC at several optimisation levels, keeping the
PDB symbols as ground-truth block/edge labels. Suggested inputs include
7-Zip, Notepad++, OpenSSL and the Microsoft Research PDB dumper tool.

- Ghidra 11.3 (P-code lifter for Stage 1):
  [github.com/NationalSecurityAgency/ghidra/releases](https://github.com/NationalSecurityAgency/ghidra/releases)

## Related benchmarks used by baselines (REGISTRY.yaml)

- **EMBER 2018** (static PE features, 1M samples, LightGBM baseline):
  - Paper: [arxiv.org/abs/1804.04637](https://arxiv.org/pdf/1804.04637)
  - Elastic release note: [elastic.co/blog/introducing-ember-open-source-classifier-and-dataset](https://www.elastic.co/blog/introducing-ember-open-source-classifier-and-dataset)
  - Code / download: [github.com/elastic/ember](https://github.com/elastic/ember)
- **EMBER 2024** (holistic evaluation benchmark):
  - Paper: [arxiv.org/abs/2506.05074](https://arxiv.org/abs/2506.05074)
  - Code: [github.com/FutureComputing4AI/EMBER2024](https://awesome.ecosyste.ms/projects/github.com%2Ffuturecomputing4ai%2Fember2024)

---

### How to wire these into the pipeline

Once you have the raw files on disk, build a manifest CSV with the schema in
`data/manifests/README.md` and run:

```bash
export CAPCERT_FRONTEND=/path/to/capcert-lfr
export CAPCERT_GHIDRA=/path/to/ghidra_11.3_PUBLIC
python experiments/ev5_clean.py --dataset Dataset-K \
       --manifest data/manifests/dataset_k.csv --seeds 0 1 2 3 4
python reporting/make_tables.py --strict     # measured runs only, no watermark
```

See `docs/REAL_DATA.md` for the full procedure and safe-handling notes for
live malware.
