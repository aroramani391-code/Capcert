# Running against the real corpora

Out of the box every run uses the synthetic corpus and is stamped `synthetic`.
To produce `measured` results you need three things this repository cannot
ship, and one change to how Stage 1 is fed.

## 1. The corpora

| corpus | how to obtain |
|---|---|
| DikeDataset | public GitHub repository; record the snapshot commit |
| Dataset-K | from the authors of [7]; if unobtainable, rebuild as Dataset-K' by the protocol in Section VI-B and document it the same way |
| BIG-2015 | Microsoft Malware Classification Challenge (Kaggle) |
| PDB ground truth | build it: open-source Windows programs compiled with MSVC at several optimisation levels, keeping the PDB symbols |

Handle live malware in an isolated VM without network access, as Section
VIII-E requires.

## 2. A manifest per corpus

`capcert/datasets.py` reads a CSV with these columns:

```
sha256,label,family,split,source,collected,packer,compiler,packed_flag,selfmod_flag,path
```

- `label` — `malicious` or `benign`
- `split` — `train`, `val`, `test`; 70/10/20 stratified by label (and by
  family on BIG-2015)
- `source` — the collection source; this is what the cross-source split of EV6
  separates on, so it must be filled in honestly
- `packed_flag`, `selfmod_flag` — assumption A1's exclusions. These drive
  Table XXX, so they must be set by the entropy / import-table rule of
  Section VI-B rather than left at zero.

Check one before using it:

```python
from capcert.datasets import load_manifest, verify_manifest
c = load_manifest("data/manifests/dataset_k.csv", "Dataset-K")
print(verify_manifest(c, check_hashes=True))
```

`data/manifests/` holds the schema and a template row.

## 3. The Stage 1 front end

The artifact ships a reference LFR over its own container format so that the
rewrite system, the L0 contract and the certificate are checkable without a
disassembler. A measured run needs the real front end:

- **Ghidra 11.3** headless, used only as a P-code lifter (Section VI-G);
- the Rust LFR in `rust/lfr`, built with `cargo build --release`.

Point the pipeline at it:

```bash
export CAPCERT_FRONTEND=/path/to/capcert-lfr
export CAPCERT_GHIDRA=/path/to/ghidra_11.3_PUBLIC
python experiments/ev5_clean.py --dataset Dataset-K \
       --manifest data/manifests/dataset_k.csv --seeds 0 1 2 3 4
```

Any script given `--manifest` without a working front end stops with a message
naming this file rather than silently falling back to synthetic data. That is
deliberate: a run that quietly substituted a different corpus would be worse
than one that refused.

## 4. What changes, and what does not

Only the source of Gamma(x) changes. Canonicalization, partitioning, the vote,
the certificate, the verification suite and the reporting are identical, and
the logs they write differ only in the provenance stamp.

Once a run is `measured`:

```bash
python reporting/make_tables.py --strict      # now emits without a watermark
python reporting/verify_against_manuscript.py # corpus-dependent claims resolve
python experiments/ev_packed.py --dataset Dataset-K \
       --manifest data/manifests/dataset_k.csv --seeds 0 1 2 3 4
```

The last one produces the detection rate that Table XXX is missing.
