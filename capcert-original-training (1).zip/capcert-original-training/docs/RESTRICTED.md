# Restricted component: the adaptive attack generator

## What is withheld

The attack generator described in Section VIII-E of the manuscript: the tool
that searches for functionality-preserving problem-space edits against a real
Windows PE and verifies, in a sandbox, that the edited sample still runs and
still behaves maliciously.

## Why

It is evasion tooling. It takes a sample that a deployed static detector
catches and produces one that it does not, with the behaviour preserved. That
is directly useful to an attacker against detectors other than CAPCert, and
publishing it would help attackers more than it helps defenders.

The recovery code, the rule set, the hash keys, the certificate computation
and the evaluation scripts are released openly, because they help defenders
and do not make evasion easier.

## Availability

Shared with vetted researchers on request, under the terms in the paper.
Requests go to the corresponding author.

## What is in the repository instead

`experiments/ev4_attacks.py` implements three white-box attacks that know the
hash keys, the canonicalizer and the threshold — the attacker Theorem 4 is
stated against:

- **bucket targeting**, which synthesizes canonical functions landing in the
  buckets currently voting malicious and inserts them through new root-table
  entries (Corollary 1(d), one unit each);
- **benign dilution**;
- **duplicate flooding**, which the occurrence cap of Table XIV blunts.

These operate on the canonical representation only. They need the keys, they
produce canonical multisets rather than PE files, and they do not check or
preserve functionality. They cannot be pointed at a binary to produce a
working evasive sample.

## Does any result depend on the withheld component?

No, and this is checkable rather than asserted:

- **The certificate** is deterministic and computed in one pass over the
  buckets. It does not involve an attack at all.
- **TV4** uses the released random and adversarial edit sequences from
  `capcert/edits.py`, which are the nine Corollary 1 families.
- **TV5** uses the Theorem 5 construction, which is in
  `verification/tv5_tightness.py` and needs no PE file.
- **EV4's** results are empirical robust accuracy, which the manuscript labels
  an upper bound for the attacks tried and never cites as evidence of
  robustness.

The one figure that the withheld tool produced and this repository cannot
reproduce is the problem-space attack-success column of Table XVIII measured
against *real binaries with functionality verified in a sandbox*. Everything
in that table measured in canonical units reproduces here.
