//! CAPCert Stage 1: Local Function Recovery.
//!
//! This crate holds the part of the pipeline whose *performance* matters and
//! whose *contract* matters most: function recovery, and the accessor that
//! makes Property L0 checkable.  The rest of the pipeline -- canonicalization,
//! partitioning, the vote and the certificate -- is in the Python package,
//! which is the reference implementation the manuscript's results come from.
//!
//! The two implementations are kept in step by the same audit: both record
//! every byte read while a view is built, and both are required to agree with
//! an independently computed dependency closure.  See
//! `verification/tv4_conformance.py`.

pub mod dep_accessor;

pub use dep_accessor::{AccessError, Accessor, Role};

/// Version of the L0 contract this build implements.
pub const L0_CONTRACT_VERSION: &str = "1.0";
