//! The dependency-recording accessor: the L0 contract, in Rust.
//!
//! Property L0 says kappa(f_e) is a function of View_x(e) alone, and that
//! View_x(e) is a function of the bytes in Dep_x(e) up to relocation.  That is
//! a contract on this file.  The recovery code cannot reach the image except
//! through `Accessor`, every read is declared either `Content` or `Locator`,
//! and the instrumentation that records what was read sits *below* the
//! declaration, so a read that the recovery forgets to declare is still
//! visible to the audit.
//!
//! That last point is what makes the audit able to fail.  An accessor that
//! only recorded declared reads would report exactly what the recovery
//! claimed, and the audit above it would be vacuous.  The jump-table
//! off-by-one found during development read one entry past the bound and never
//! declared it; `undeclared()` is what catches that shape of defect.

use std::collections::BTreeSet;
use std::ops::Range;

/// Why a byte was read.
///
/// `Content` bytes may determine the canonical form.  `Locator` bytes say only
/// *where* something is -- a record offset, a table length -- and are never
/// used as values, which is what lets a relocation move code without changing
/// any canonical form.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Role {
    Content,
    Locator,
}

#[derive(Debug)]
pub enum AccessError {
    OutOfBounds { offset: usize, len: usize, image_len: usize },
}

impl std::fmt::Display for AccessError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            AccessError::OutOfBounds { offset, len, image_len } => write!(
                f,
                "read of {len} bytes at {offset} is outside the {image_len}-byte image"
            ),
        }
    }
}

impl std::error::Error for AccessError {}

pub struct Accessor<'a> {
    data: &'a [u8],
    content: BTreeSet<usize>,
    locator: BTreeSet<usize>,
    all_reads: BTreeSet<usize>,
    recording: bool,
    reads: u64,
}

impl<'a> Accessor<'a> {
    pub fn new(data: &'a [u8]) -> Self {
        Self {
            data,
            content: BTreeSet::new(),
            locator: BTreeSet::new(),
            all_reads: BTreeSet::new(),
            recording: true,
            reads: 0,
        }
    }

    /// The only way to obtain bytes of the image.
    pub fn read(&mut self, offset: usize, len: usize, role: Role) -> Result<&'a [u8], AccessError> {
        let end = offset.checked_add(len).unwrap_or(usize::MAX);
        if end > self.data.len() {
            return Err(AccessError::OutOfBounds {
                offset,
                len,
                image_len: self.data.len(),
            });
        }
        self.reads += 1;
        // Always recorded, whatever the recovery declared.
        self.all_reads.extend(offset..end);
        if self.recording {
            let target = match role {
                Role::Content => &mut self.content,
                Role::Locator => &mut self.locator,
            };
            target.extend(offset..end);
        }
        Ok(&self.data[offset..end])
    }

    pub fn u8(&mut self, offset: usize, role: Role) -> Result<u8, AccessError> {
        Ok(self.read(offset, 1, role)?[0])
    }

    pub fn u16(&mut self, offset: usize, role: Role) -> Result<u16, AccessError> {
        let b = self.read(offset, 2, role)?;
        Ok(u16::from_le_bytes([b[0], b[1]]))
    }

    pub fn u32(&mut self, offset: usize, role: Role) -> Result<u32, AccessError> {
        let b = self.read(offset, 4, role)?;
        Ok(u32::from_le_bytes([b[0], b[1], b[2], b[3]]))
    }

    /// Dep_x(e): the content bytes this view depends on.
    pub fn content(&self) -> &BTreeSet<usize> {
        &self.content
    }

    /// Bytes used only to locate; a relocation may move them freely.
    pub fn locator(&self) -> &BTreeSet<usize> {
        &self.locator
    }

    /// Bytes read but never declared.  Must be empty; anything here is an L0
    /// violation, and it is invisible to a comparison of declared sets.
    pub fn undeclared(&self) -> BTreeSet<usize> {
        self.all_reads
            .difference(&(&self.content | &self.locator))
            .copied()
            .collect()
    }

    pub fn reads(&self) -> u64 {
        self.reads
    }

    /// Fault injection, for the negative control only.  With recording off,
    /// reads still appear in `all_reads`, so `undeclared()` reports them --
    /// which is exactly the behaviour the audit must have.
    #[doc(hidden)]
    pub fn set_recording(&mut self, on: bool) {
        self.recording = on;
    }

    pub fn audit_clean(&self) -> bool {
        self.undeclared().is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn declared_reads_are_recorded() {
        let data = vec![1u8; 32];
        let mut a = Accessor::new(&data);
        a.read(4, 8, Role::Content).unwrap();
        a.read(16, 4, Role::Locator).unwrap();
        assert_eq!(a.content().len(), 8);
        assert_eq!(a.locator().len(), 4);
        assert!(a.audit_clean());
    }

    #[test]
    fn undeclared_reads_are_caught() {
        let data = vec![1u8; 32];
        let mut a = Accessor::new(&data);
        a.read(0, 4, Role::Content).unwrap();
        a.set_recording(false);
        a.read(20, 4, Role::Content).unwrap(); // the defect
        a.set_recording(true);
        assert!(!a.audit_clean(), "an undeclared read must not pass the audit");
        assert_eq!(a.undeclared().len(), 4);
    }

    #[test]
    fn out_of_bounds_is_an_error_not_a_panic() {
        let data = vec![0u8; 8];
        let mut a = Accessor::new(&data);
        assert!(a.read(6, 4, Role::Content).is_err());
    }
}
