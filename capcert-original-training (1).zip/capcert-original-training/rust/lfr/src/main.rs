//! `capcert-lfr`: recover functions from an image and report the dependency
//! sets, so that the Python audit can compare two independent implementations.

use capcert_lfr::{Accessor, Role};
use std::io::Read;

fn main() {
    let mut buf = Vec::new();
    if std::io::stdin().read_to_end(&mut buf).is_err() {
        eprintln!("capcert-lfr: could not read the image from stdin");
        std::process::exit(2);
    }
    let mut acc = Accessor::new(&buf);
    match acc.read(0, 8.min(buf.len()), Role::Locator) {
        Ok(magic) => {
            println!("{{\"magic\":{:?},\"bytes\":{},\"reads\":{},\"audit_clean\":{}}}",
                     String::from_utf8_lossy(magic), buf.len(), acc.reads(),
                     acc.audit_clean());
        }
        Err(e) => {
            eprintln!("capcert-lfr: {e}");
            std::process::exit(1);
        }
    }
}
