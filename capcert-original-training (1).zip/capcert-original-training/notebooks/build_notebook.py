#!/usr/bin/env python3
"""Generate CAPCert_Reproduction.ipynb.

The notebook is generated rather than hand-edited so that its cells stay in
step with the scripts they call.  Rerun this after changing the CLI of any
runner.
"""
from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def md(text: str) -> dict:
    return {"cell_type": "markdown", "metadata": {}, "source": text.strip().split("\n")}


def code(text: str) -> dict:
    return {"cell_type": "code", "execution_count": None, "metadata": {},
            "outputs": [], "source": text.strip("\n").split("\n")}


cells = []

cells.append(md(r"""
# CAPCert — reproduction notebook

Runs the whole pipeline end to end and writes **real logs and checkpoints from
a real run** into `results/`, then regenerates the manuscript's tables from
those logs and diffs them against the paper's claims.

## Read this first

Out of the box this notebook runs on a **synthetic demonstration corpus**. It
contains no malware. Every file the run writes is stamped `synthetic`, every
table it produces is watermarked, and the verifier reports corpus-dependent
claims as `STRUCTURAL` rather than reproduced.

That is not a limitation to work around — it is the honest state of a public
artifact for a malware paper. DikeDataset, Dataset-K and BIG-2015 are not
redistributable, so a notebook that claimed to reproduce their numbers without
them would be fabricating results.

**What a synthetic run does establish**, and these are checked here:

- the rewrite system terminates, is locally confluent, and cancels every
  transformation in `T_inv` *exactly* (Theorem 1);
- every one of the nine Corollary 1 edit families respects its footprint bound;
- Property L0 holds, and the audit that checks it can actually fail;
- the certificate is sound: no sample flips inside its radius;
- the Z3 obligations discharge;
- the training objective, the vote and the certified radius all compute.

**What it cannot establish**: any number about malware. For that, see
`docs/REAL_DATA.md` and the last section of this notebook.

Runtime: about 15 minutes on a free Colab CPU runtime. No GPU needed.
"""))

cells.append(md("## 1. Get the artifact"))

cells.append(code(r'''
# If you have the repository as a zip or folder, point ARTIFACT at it.
# In Colab, upload capcert-artifact.zip and run this cell as is.
import os, sys, subprocess, shutil, zipfile
from pathlib import Path

ARTIFACT = Path("/content/capcert-artifact")

if not ARTIFACT.exists():
    zips = sorted(Path("/content").glob("capcert-artifact*.zip")) if Path("/content").exists() else []
    if zips:
        with zipfile.ZipFile(zips[-1]) as z:
            z.extractall("/content")
        print("extracted", zips[-1].name)
    elif Path.cwd().name == "capcert-artifact":
        ARTIFACT = Path.cwd()
    elif (Path.cwd() / "capcert").is_dir():
        ARTIFACT = Path.cwd()

assert (ARTIFACT / "capcert").is_dir(), (
    f"could not find the artifact at {ARTIFACT}. Upload capcert-artifact.zip "
    "to /content, or run this notebook from inside the repository."
)
os.chdir(ARTIFACT)
sys.path.insert(0, str(ARTIFACT))
print("working in", Path.cwd())
'''))

cells.append(code(r'''
# Dependencies. numpy/scipy/pyyaml/matplotlib are already in Colab;
# z3-solver is the one that usually needs installing.
try:
    import z3
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "z3-solver"], check=True)
    import z3

import numpy, scipy, yaml
try:
    import torch
    torch_v = torch.__version__
except ImportError:
    torch_v = "not installed (the pipeline falls back to the numpy backend)"

print("numpy", numpy.__version__)
print("scipy", scipy.__version__)
print("z3   ", z3.get_version_string())
print("torch", torch_v)
'''))

cells.append(md(r"""
## 2. Configuration

`RESULTS` is where every log, checkpoint and table lands. `MANIFEST` is the
switch between a synthetic run and a measured one: leave it `None` unless you
have the real corpora and a Stage 1 front end wired up per `docs/REAL_DATA.md`.
"""))

cells.append(code(r'''
RESULTS  = "results"
MANIFEST = None          # e.g. "data/manifests/dataset_k.csv" for a measured run
DATASET  = "synthetic" if MANIFEST is None else "Dataset-K"

N        = 300           # synthetic corpus size
EPOCHS   = 40
B, K, T  = 64, 2, 5      # buckets, hashes per function, vote threshold
SEEDS    = [0, 1, 2]

from pathlib import Path
Path(RESULTS).mkdir(exist_ok=True)

def run(script, *args, show=40):
    """Run a runner and show its tail."""
    cmd = [sys.executable, script, "--results", RESULTS, *map(str, args)]
    if MANIFEST and script.startswith("experiments/"):
        cmd += ["--manifest", MANIFEST, "--dataset", DATASET]
    print("$", " ".join(cmd[1:]))
    p = subprocess.run(cmd, capture_output=True, text=True)
    out = (p.stdout + p.stderr).strip().split("\n")
    print("\n".join(out[-show:]))
    print(f"[exit {p.returncode}]\n")
    return p.returncode
'''))

cells.append(md(r"""
## 3. Verification suite (TV1–TV5)

These check the implementation against the proven results. Passing does not
establish a guarantee — the proofs do that. A failure reveals a defect.
"""))

cells.append(code(r'''
rc = {}
rc["TV1 termination"]     = run("verification/tv1_termination.py", "--n", 60)
rc["TV2 critical pairs"]  = run("verification/tv2_critical_pairs.py", "--n", 40)
rc["TV3 SMT (Z3)"]        = run("verification/tv3_smt.py")
'''))

cells.append(code(r'''
rc["TV4 conformance"] = run("verification/tv4_conformance.py",
                            "--n", 30, "--sequences", 3,
                            "--B", B, "--k", K, "--t", 3)
rc["TV5 tightness"]   = run("verification/tv5_tightness.py",
                            "--n", 20, "--B", B, "--k", K, "--t", 3)
'''))

cells.append(md(r"""
### The negative controls

These are the cells that make the ones above mean something. Each reinstates a
real defect and the check must **fail**.

- `l0_fault_injection` puts back the jump-table off-by-one of Section VII-J:
  LFR reads one entry past the declared bound and never records it as a
  dependency. The injected phase must report violations.
- `tv1 --emulate-name-order` puts back the R5 defect: a comparison that is not
  an order, so a commutative pair swaps back and forth for ever.

If either of these *passes*, the corresponding check above is proving nothing.
"""))

cells.append(code(r'''
rc["L0 fault injection"] = run("verification/l0_fault_injection.py", "--n", 20)

print("=" * 70)
print("negative control for TV1 — this one is EXPECTED to report failures:")
p = subprocess.run([sys.executable, "verification/tv1_termination.py",
                    "--n", "20", "--emulate-name-order",
                    "--results", "/tmp/negative-control"],
                   capture_output=True, text=True)
print((p.stdout + p.stderr).strip())
assert "FAIL" in p.stdout, (
    "the TV1 negative control PASSED. That means the termination check cannot "
    "detect the defect it is meant to detect, so a clean TV1 result above is "
    "not evidence of anything."
)
print("\nGood: the check can fail, so its passing above is informative.")
'''))

cells.append(md(r"""
## 4. Experiments (EV1–EV9)

EV1 and EV2 are the ones whose results are corpus-independent: Theorem 1's
invariance is exact, and the Corollary 1 footprint bounds hold for every binary
and every edit. A synthetic run settles those outright.
"""))

cells.append(code(r'''
rc["EV1 invariance"] = run("experiments/ev1_invariance.py", "--n", 60, "--repeats", 2, show=14)
rc["EV2 recovery"]   = run("experiments/ev2_recovery.py",  "--n", 40, "--trials", 2, show=18)
'''))

cells.append(code(r'''
# EV5 trains the base classifier and writes the checkpoints every other
# experiment reuses. This is the slowest cell.
rc["EV5 clean + training"] = run(
    "experiments/ev5_clean.py", "--n", N, "--epochs", EPOCHS,
    "--B", B, "--k", K, "--t", T, "--seeds", *SEEDS)
'''))

cells.append(code(r'''
rc["EV3 certified accuracy"] = run(
    "experiments/ev3_certified.py", "--n", N, "--epochs", EPOCHS,
    "--B", B, "--k", K, "--t", T, "--seeds", *SEEDS, show=14)
'''))

cells.append(code(r'''
rc["EV4/EV8 attacks"] = run("experiments/ev4_attacks.py", "--n", 200,
                            "--epochs", 30, "--B", B, "--k", K, "--t", T,
                            "--budget-max", 8, "--variants", 2000, show=16)
rc["EV8 partition"]   = run("experiments/ev8_partition.py", "--n", 80,
                            "--B", B, "--k", K, show=10)
'''))

cells.append(code(r'''
rc["EV6 generalization"] = run("experiments/ev6_generalization.py", "--n", 200,
                               "--epochs", 25, "--B", B, "--k", K, "--t", T, show=10)
rc["EV7 efficiency"]     = run("experiments/ev7_efficiency.py", "--n", 120,
                               "--epochs", 20, "--B", B, "--k", K, "--t", T, show=12)
rc["EV9 training"]       = run("experiments/ev9_training.py", "--n", 150,
                               "--epochs", 20, "--B", B, "--k", K, "--t", T, show=18)
'''))

cells.append(md(r"""
### The packed and self-modifying subsets — Table XXX

This is the run that fills the cell the manuscript leaves empty. It trains on
the admitted subset only, then evaluates on the flagged subset the model has
never seen, and checks that **no certificate is issued** on it: a packer
rewrites every function, so the footprint of unpacking is the whole program and
no non-trivial radius exists.

On the synthetic corpus the detection rate it prints is a demonstration, not a
manuscript result. Rerun with `MANIFEST` set to fill Table XXX for real.
"""))

cells.append(code(r'''
rc["Table XXX packed subset"] = run(
    "experiments/ev_packed.py", "--n", N, "--epochs", 25,
    "--B", B, "--k", K, "--t", T, "--seeds", *SEEDS, show=18)
'''))

cells.append(md("## 5. Regenerate the tables and diff against the manuscript"))

cells.append(code(r'''
rc["tables"] = run("reporting/make_tables.py", show=20)
rc["verify"] = run("reporting/verify_against_manuscript.py", show=80)
'''))

cells.append(code(r'''
print("Run summary")
print("=" * 50)
for name, code_ in rc.items():
    print(f"  {'ok  ' if code_ == 0 else 'FAIL'}  {name}")
bad = [k for k, v in rc.items() if v != 0]
print("\nall green" if not bad else f"\nnon-zero exit: {bad}")
'''))

cells.append(md(r"""
## 6. What the run produced

Logs are append-only JSONL with a manifest beside each one carrying the run
stamp, the environment, the config and a SHA-256 of the log. Checkpoints carry
a `.meta.json` sidecar with everything needed to reproduce them.
"""))

cells.append(code(r'''
import json
from capcert.provenance import load_manifests, collective_provenance

ms = load_manifests(RESULTS)
print(f"{len(ms)} run manifests, collective provenance: {collective_provenance(ms)}\n")
print(f"{'component':24s} {'prov':10s} {'seed':>4s} {'records':>8s}  headline")
print("-" * 100)
for m in sorted(ms, key=lambda m: (m['stamp']['component'], m['stamp']['seed'])):
    st, res = m["stamp"], m.get("results", {})
    head = next((f"{k}={res[k]}" for k in
                 ("passed", "violations", "pairs_not_joinable", "invalid",
                  "verdict_changes_inside_radius", "test_f1", "flips_inside_radius")
                 if k in res), "")
    print(f"{st['component']:24s} {st['provenance']:10s} {st['seed']:>4} "
          f"{m['records']:>8}  {head}")
'''))

cells.append(code(r'''
from pathlib import Path
print("checkpoints")
for p in sorted(Path(RESULTS, "checkpoints").glob("*")):
    if p.suffix != ".json" or not p.name.endswith(".meta.json"):
        print(f"  {p.name:60s} {p.stat().st_size:>9,} bytes")
print("\ntables")
for p in sorted(Path(RESULTS, "tables").glob("*.txt")):
    print(f"  {p.name}")
'''))

cells.append(code(r'''
# Look at one table in full, watermark and all.
print(Path(RESULTS, "tables", "table_XVII.txt").read_text())
'''))

cells.append(md("## 7. A look at the mechanism, not just the numbers"))

cells.append(code(r'''
# Theorem 1 in one cell: a function, an obfuscating rewrite from T_inv, and
# the same canonical digest on both sides.
import random
from capcert.datasets import synthetic_image
from capcert.edits import T_INV, T_INV_OPS, OUT_OF_CLASS, out_of_class, image_functions
from capcert.canonical import digest, canonical_text

img = synthetic_image(7, malicious=True)
fn  = image_functions(img)["fn0"]
rng = random.Random(0)

print(f"original canonical digest  {digest(fn)[:32]}…\n")
print("in class (Theorem 1 says these are cancelled exactly):")
for cls in T_INV:
    g = T_INV_OPS[cls](fn, rng)
    same = digest(g) == digest(fn)
    print(f"  {cls:28s} {'identical' if same else 'DIFFERENT'}")

print("\nout of class (nothing is claimed for these):")
for cls in OUT_OF_CLASS:
    g = out_of_class(cls, fn, rng)
    print(f"  {cls:28s} {'identical' if digest(g)==digest(fn) else 'different'}")
'''))

cells.append(code(r'''
# Corollary 1 in one cell: measured footprint against the stated bound,
# for all nine edit families.
from capcert.edits import EDIT_FAMILIES, FAMILIES, footprint_report
from capcert.lfr import ownership

om = ownership(img)
print(f"max omega (bytes owned by several roots): {max(om.values())}\n")
print(f"{'family':38s} {'measured':>9} {'bound':>8}  ok")
rng = random.Random(3)
for fam, desc in FAMILIES.items():
    rep = footprint_report(img, EDIT_FAMILIES[fam](img, rng))
    print(f"({fam}) {desc:34s} {rep.measured:>9} {str(rep.bound):>8}  "
          f"{'yes' if rep.within_bound else 'NO'}")
'''))

cells.append(code(r'''
# The certificate itself: vote, radius, and the Theorem 2 cap on how many
# buckets one canonical-function edit can move.
from capcert.edits import canonical_of_image
from capcert.partition import PartitionConfig, theorem2_bound
from capcert.vote import VoteConfig, LinearBaseClassifier, vote

pcfg, vcfg = PartitionConfig(B=B, k=K), VoteConfig(t=3)
cx = canonical_of_image(img)
g  = LinearBaseClassifier.fit_reference(sorted(cx))
v  = vote(cx, g, pcfg, vcfg)
print(f"V(x) = {v.votes} of {pcfg.B} buckets,  t = {vcfg.t},  "
      f"label = {v.label},  rho_hat = {v.radius}")
print(f"  radius = floor((V - t)/k) = floor(({v.votes} - {vcfg.t})/{pcfg.k}) = {v.radius}\n")

res = EDIT_FAMILIES["d"](img, rng)          # one unit by Corollary 1(d)
cy  = canonical_of_image(res.image)
changed, cap = theorem2_bound(cx, cy, pcfg)
print(f"one root-table insertion moved {changed} buckets; "
      f"Theorem 2 caps it at k*d = {cap}")
'''))

cells.append(md(r"""
## 8. Download the results

The zip holds every log, manifest, checkpoint and table the run produced.
"""))

cells.append(code(r'''
import shutil
archive = shutil.make_archive("/tmp/capcert-results", "zip", RESULTS)
print(archive, f"{Path(archive).stat().st_size/1e6:.1f} MB")
try:
    from google.colab import files
    files.download(archive)
except Exception:
    print("not in Colab — the archive is at the path above")
'''))

cells.append(md(r"""
## 9. Going from `synthetic` to `measured`

Everything above runs the real pipeline. The only thing standing between it
and manuscript results is the source of Γ(x).

1. Obtain DikeDataset, Dataset-K and BIG-2015, and build the PDB ground-truth
   corpus. Handle live malware in an isolated VM without network access.
2. Write a manifest per corpus with the columns in
   `data/manifests/template.csv`. Three columns decide whether the results
   mean anything: `source` (drives the cross-source split that bounds
   provenance bias), and `packed_flag` / `selfmod_flag` (drive assumption A1
   and Table XXX).
3. Build the Stage 1 front end: `cd rust/lfr && cargo build --release`, plus
   Ghidra 11.3 headless as the P-code lifter.
4. Set `MANIFEST` in section 2 and rerun. Any script given `--manifest`
   without a working front end stops and points at `docs/REAL_DATA.md` rather
   than silently falling back to synthetic data.

Then:

```bash
python reporting/make_tables.py --strict        # emits without a watermark
python reporting/verify_against_manuscript.py   # corpus-dependent claims resolve
python experiments/ev_packed.py --manifest data/manifests/dataset_k.csv \
       --dataset Dataset-K --seeds 0 1 2 3 4    # fills Table XXX
```

One component stays out: the adaptive attack generator of Section VIII-E. It
is evasion tooling and is shared with vetted researchers on request.
`docs/RESTRICTED.md` records what it is, what is here instead, and why no
certified result depends on it.
"""))

nb = {
    "cells": cells,
    "metadata": {
        "colab": {"provenance": [], "toc_visible": True},
        "kernelspec": {"display_name": "Python 3", "name": "python3"},
        "language_info": {"name": "python"},
    },
    "nbformat": 4,
    "nbformat_minor": 0,
}

out = HERE / "CAPCert_Reproduction.ipynb"
out.write_text(json.dumps(nb, indent=1), encoding="utf-8")
print(f"wrote {out} ({len(cells)} cells)")
