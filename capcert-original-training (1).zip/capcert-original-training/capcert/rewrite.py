"""The canonicalizing rewrite system R1-R6 and its termination measure.

Section IV-B of the manuscript.  Each rule here carries its precondition, the
component of the measure mu it strictly decreases (Lemma 2), and the soundness
argument that Proposition 2 and Appendix A state for it.

mu is the lexicographic tuple

    (|blocks|, |ops|, |foldable ops|, |commutative inversions|, |alias calls|)

and the components are ordered so that each rule decreases one of them while
leaving every earlier one unchanged:

    R1 block merge           -> |blocks|
    R2 empty-block elision   -> |blocks|
    R3 dead code elimination -> |ops|
    R4 constant folding      -> |foldable ops|   (COPY is not foldable, so a
                                                  fold strictly decreases this
                                                  even when it propagates a
                                                  constant and creates new
                                                  folding sites downstream)
    R5 operand normalisation -> |inversions|
    R6 API alias folding     -> |alias calls|

Lexicographic comparison is what lets R4 propagate constants freely: the
propagation may raise |inversions|, but |foldable ops| sits strictly earlier in
the tuple, so mu still decreases.  That ordering is the whole content of
Lemma 2 and is what TV1 checks on every step over the whole corpus.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from .ir import (
    BOOLEAN_RESULT_OPS,
    COMMUTATIVE_OPS,
    Block,
    Function,
    Op,
    Varnode,
    const,
    eval_op,
)

Mu = Tuple[int, int, int, int, int]

# --------------------------------------------------------------------------
# API alias table (R6).  Maps a concrete import to its API family.
# --------------------------------------------------------------------------

API_ALIASES: Dict[str, str] = {
    # ANSI / wide pairs
    "CreateFileA": "api::CreateFile", "CreateFileW": "api::CreateFile",
    "CreateProcessA": "api::CreateProcess", "CreateProcessW": "api::CreateProcess",
    "RegOpenKeyExA": "api::RegOpenKeyEx", "RegOpenKeyExW": "api::RegOpenKeyEx",
    "GetModuleHandleA": "api::GetModuleHandle", "GetModuleHandleW": "api::GetModuleHandle",
    "LoadLibraryA": "api::LoadLibrary", "LoadLibraryW": "api::LoadLibrary",
    "WinExec": "api::CreateProcess",
    # api-set forwarders
    "api-ms-win-core-file-l1-1-0!CreateFile": "api::CreateFile",
    "api-ms-win-core-processthreads-l1-1-0!CreateProcess": "api::CreateProcess",
    "api-ms-win-core-libraryloader-l1-1-0!LoadLibrary": "api::LoadLibrary",
    # CRT wrappers that forward
    "_open": "api::CreateFile", "fopen": "api::CreateFile",
    "system": "api::CreateProcess",
}


def canonical_api(name: str) -> str:
    return API_ALIASES.get(name, name)


def is_alias_call(op: Op) -> bool:
    return (
        op.opcode == "CALL"
        and op.target is not None
        and op.target in API_ALIASES
        and API_ALIASES[op.target] != op.target
    )


# --------------------------------------------------------------------------
# Termination measure
# --------------------------------------------------------------------------

def _inversions(fn: Function) -> int:
    n = 0
    for op in fn.all_ops():
        if op.opcode in COMMUTATIVE_OPS and len(op.ins) == 2:
            if op.ins[0].structural_key() > op.ins[1].structural_key():
                n += 1
    return n


def mu(fn: Function) -> Mu:
    ops = fn.all_ops()
    return (
        len(fn.blocks),
        len(ops),
        sum(1 for o in ops if o.is_foldable),
        _inversions(fn),
        sum(1 for o in ops if is_alias_call(o)),
    )


# --------------------------------------------------------------------------
# Liveness, for R3
# --------------------------------------------------------------------------

def _uses(fn: Function) -> Dict[Varnode, int]:
    counts: Dict[Varnode, int] = {}
    for op in fn.all_ops():
        for v in op.ins:
            if not v.is_const:
                counts[v] = counts.get(v, 0) + 1
    return counts


def _escapes(fn: Function, v: Varnode) -> bool:
    """A varnode escapes if it is live-out, or read by an effectful op."""
    if v in fn.live_out:
        return True
    for op in fn.all_ops():
        if op.opcode in ("STORE", "CALL", "CALLIND", "RETURN", "CBRANCH", "BRANCHIND"):
            if v in op.ins:
                return True
    # a register may be read by a caller; only uniques are safely local
    return v.space != "unique"


# --------------------------------------------------------------------------
# Redexes
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class Redex:
    """One applicable rule instance, located precisely enough to replay it."""

    rule: str
    site: Tuple  # rule-specific locator, hashable and comparable

    def key(self) -> Tuple:
        return (self.rule, self.site)


def _r1_sites(fn: Function) -> List[Redex]:
    """Merge b1 -> b2 when b2 is b1's only successor and b1 is b2's only pred."""
    preds = fn.predecessors()
    out = []
    for lbl in fn.order():
        blk = fn.blocks[lbl]
        t = blk.terminator
        if t is None or t.opcode != "BRANCH" or not t.target:
            continue
        succ = t.target
        if succ == lbl or succ not in fn.blocks:
            continue
        if succ == fn.entry:
            continue
        if len(preds.get(succ, [])) == 1 and preds[succ][0] == lbl:
            out.append(Redex("R1", (lbl, succ)))
    return out


def _r2_sites(fn: Function) -> List[Redex]:
    """Elide a block whose only op is an unconditional BRANCH."""
    out = []
    for lbl in fn.order():
        if lbl == fn.entry:
            continue
        ops = fn.blocks[lbl].ops
        if len(ops) == 1 and ops[0].opcode == "BRANCH" and ops[0].target:
            if ops[0].target != lbl:
                out.append(Redex("R2", (lbl,)))
    return out


def _r3_sites(fn: Function) -> List[Redex]:
    """Delete a pure op whose result is unused and does not escape."""
    uses = _uses(fn)
    out = []
    for lbl, i, op in fn.iter_ops():
        if not op.is_pure or op.out is None:
            continue
        if uses.get(op.out, 0) == 0 and not _escapes(fn, op.out):
            out.append(Redex("R3", (lbl, i)))
    return out


def _r4_sites(fn: Function) -> List[Redex]:
    """Fold a foldable op whose inputs are all constants."""
    out = []
    for lbl, i, op in fn.iter_ops():
        if op.is_foldable and op.out is not None and op.ins and all(v.is_const for v in op.ins):
            out.append(Redex("R4", (lbl, i)))
    return out


def _r5_sites(fn: Function) -> List[Redex]:
    out = []
    for lbl, i, op in fn.iter_ops():
        if op.opcode in COMMUTATIVE_OPS and len(op.ins) == 2:
            if op.ins[0].structural_key() > op.ins[1].structural_key():
                out.append(Redex("R5", (lbl, i)))
    return out


def _r6_sites(fn: Function) -> List[Redex]:
    out = []
    for lbl, i, op in fn.iter_ops():
        if is_alias_call(op):
            out.append(Redex("R6", (lbl, i)))
    return out


SITE_FINDERS: Dict[str, Callable[[Function], List[Redex]]] = {
    "R1": _r1_sites, "R2": _r2_sites, "R3": _r3_sites,
    "R4": _r4_sites, "R5": _r5_sites, "R6": _r6_sites,
}

RULES: Tuple[str, ...] = ("R1", "R2", "R3", "R4", "R5", "R6")

RULE_DOC: Dict[str, str] = {
    "R1": "block merge: b2 is b1's only successor via unconditional BRANCH and "
          "b1 is b2's only predecessor; concatenate and drop the BRANCH",
    "R2": "empty-block elision: a block holding only a direct BRANCH is removed "
          "and all incoming edges are redirected in one step",
    "R3": "dead code elimination: a pure non-faulting op whose output is unused "
          "and does not escape is deleted",
    "R4": "constant folding: a foldable op with all-constant inputs is replaced "
          "by COPY of the folded constant, and the constant is propagated to "
          "the uses of its single-definition unique output",
    "R5": "operand normalisation: the two inputs of a commutative op are placed "
          "in structural order (space rank, width, offset)",
    "R6": "API alias folding: a CALL to a known alias is rewritten to its API "
          "family name",
}

RULE_DECREASES: Dict[str, str] = {
    "R1": "|blocks|", "R2": "|blocks|", "R3": "|ops|",
    "R4": "|foldable ops|", "R5": "|inversions|", "R6": "|alias calls|",
}


def redexes(fn: Function, rules: Sequence[str] = RULES) -> List[Redex]:
    out: List[Redex] = []
    for r in rules:
        out.extend(SITE_FINDERS[r](fn))
    return out


# --------------------------------------------------------------------------
# Application
# --------------------------------------------------------------------------

def _retarget(fn: Function, old: str, new: str) -> None:
    for blk in fn.blocks.values():
        for i, op in enumerate(blk.ops):
            if op.opcode == "BRANCH" and op.target == old:
                blk.ops[i] = Op("BRANCH", target=new)
            elif op.opcode == "CBRANCH" and old in op.targets:
                blk.ops[i] = Op(
                    "CBRANCH", ins=op.ins,
                    targets=tuple(new if t == old else t for t in op.targets),
                )


def apply_redex(fn: Function, rx: Redex) -> Function:
    """Apply one rule instance, returning a new function.  Never mutates ``fn``."""
    g = fn.copy()
    if rx.rule == "R1":
        b1, b2 = rx.site
        if b1 not in g.blocks or b2 not in g.blocks:
            raise ValueError("R1 site no longer present")
        head = [o for o in g.blocks[b1].ops if not (o.opcode == "BRANCH" and o.target == b2)]
        g.blocks[b1] = Block(b1, head + list(g.blocks[b2].ops))
        del g.blocks[b2]
        _retarget(g, b2, b1)
        return g

    if rx.rule == "R2":
        (lbl,) = rx.site
        target = g.blocks[lbl].ops[0].target
        del g.blocks[lbl]
        _retarget(g, lbl, target)
        return g

    if rx.rule == "R3":
        lbl, i = rx.site
        ops = list(g.blocks[lbl].ops)
        del ops[i]
        g.blocks[lbl] = Block(lbl, ops)
        return g

    if rx.rule == "R4":
        lbl, i = rx.site
        op = g.blocks[lbl].ops[i]
        value = eval_op(op, [v.offset for v in op.ins])
        out_vn = op.out
        size = out_vn.size if out_vn is not None else op.ins[0].size
        if op.opcode in BOOLEAN_RESULT_OPS:
            size = out_vn.size if out_vn is not None else 1
        folded = const(value, size)
        ops = list(g.blocks[lbl].ops)
        ops[i] = Op("COPY", out=out_vn, ins=(folded,))
        g.blocks[lbl] = Block(lbl, ops)
        # Propagate the constant to the uses of the output -- but only when
        # the output is a unique with exactly one definition in the function.
        # Without that precondition the propagation crosses a redefinition and
        # is unsound; the TV4 conformance audit catches it as a non-zero
        # footprint for an edit in T_inv, which is how it was found here.
        single_def = (
            out_vn is not None
            and out_vn.space == "unique"
            and sum(1 for o in g.all_ops() if o.out == out_vn) == 1
        )
        if single_def:
            for blbl, blk in g.blocks.items():
                new_ops = []
                for j, o in enumerate(blk.ops):
                    if blbl == lbl and j == i:
                        new_ops.append(o)
                        continue
                    if out_vn in o.ins:
                        new_ops.append(o.with_ins(
                            [folded if v == out_vn else v for v in o.ins]))
                    else:
                        new_ops.append(o)
                g.blocks[blbl] = Block(blbl, new_ops)
        return g

    if rx.rule == "R5":
        lbl, i = rx.site
        ops = list(g.blocks[lbl].ops)
        op = ops[i]
        ops[i] = op.with_ins(sorted(op.ins, key=lambda v: v.structural_key()))
        g.blocks[lbl] = Block(lbl, ops)
        return g

    if rx.rule == "R6":
        lbl, i = rx.site
        ops = list(g.blocks[lbl].ops)
        op = ops[i]
        ops[i] = Op(op.opcode, out=op.out, ins=op.ins, target=canonical_api(op.target or ""))
        g.blocks[lbl] = Block(lbl, ops)
        return g

    raise KeyError(rx.rule)


# --------------------------------------------------------------------------
# Normalisation
# --------------------------------------------------------------------------

class TerminationViolation(RuntimeError):
    """Raised when a step fails to decrease mu.  TV1 treats this as a defect."""


@dataclass
class Step:
    rule: str
    site: Tuple
    mu_before: Mu
    mu_after: Mu


def normalize(
    fn: Function,
    rules: Sequence[str] = RULES,
    max_steps: int = 100_000,
    on_step: Optional[Callable[[Step], None]] = None,
    check_mu: bool = True,
) -> Tuple[Function, List[Step]]:
    """Rewrite to normal form under the leftmost-outermost strategy.

    ``on_step`` receives every step, which is how TV1 records mu before and
    after each rewrite over the whole corpus.
    """
    cur = fn
    steps: List[Step] = []
    for _ in range(max_steps):
        rs = redexes(cur, rules)
        if not rs:
            return cur, steps
        rx = min(rs, key=lambda r: (RULES.index(r.rule), repr(r.site)))
        before = mu(cur)
        nxt = apply_redex(cur, rx)
        after = mu(nxt)
        step = Step(rx.rule, rx.site, before, after)
        steps.append(step)
        if on_step is not None:
            on_step(step)
        if check_mu and not (after < before):
            raise TerminationViolation(
                f"rule {rx.rule} at {rx.site}: mu {before} -> {after} did not decrease"
            )
        cur = nxt
    raise TerminationViolation(f"no normal form after {max_steps} steps")


def normal_form(fn: Function, rules: Sequence[str] = RULES) -> Function:
    return normalize(fn, rules)[0]
