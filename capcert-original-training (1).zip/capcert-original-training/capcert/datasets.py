"""Corpora: manifests for the real datasets, and a synthetic demonstration corpus.

The real corpora of Table XI are not redistributable.  What the artifact ships
instead is

  * a manifest *schema* and loader, so that a reader holding DikeDataset,
    Dataset-K or BIG-2015 can point the pipeline at them and get ``measured``
    provenance, and
  * a synthetic corpus generator, so that every script in this repository runs
    end to end on a machine with no malware on it, producing real logs from a
    real run whose provenance is stamped ``synthetic``.

The synthetic corpus is a demonstration of the pipeline, not a stand-in for the
datasets.  Nothing produced from it may be reported as a manuscript result, and
``reporting/make_tables.py`` enforces that.
"""
from __future__ import annotations

import csv
import hashlib
import json
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from .image import ProgramImage, build_image
from .ir import Block, Function, Op, Varnode, const
from .rewrite import API_ALIASES

# --------------------------------------------------------------------------
# Manifests for the real corpora
# --------------------------------------------------------------------------

MANIFEST_FIELDS = (
    "sha256",            # of the binary
    "label",             # "malicious" | "benign"
    "family",            # AVClass2 family, or "" for benign/unknown
    "split",             # "train" | "val" | "test"
    "source",            # collection source, for the cross-source split (EV6)
    "collected",         # ISO date or year
    "packer",            # detected packer, or ""
    "compiler",          # compiler/linker fingerprint, or ""
    "packed_flag",       # "1" if excluded by assumption A1
    "selfmod_flag",      # "1" if self-modifying
    "path",              # path on the reader's machine
)


@dataclass
class Sample:
    sha256: str
    label: str
    family: str
    split: str
    source: str
    collected: str
    packer: str
    compiler: str
    packed_flag: bool
    selfmod_flag: bool
    path: str

    @property
    def is_malicious(self) -> bool:
        return self.label == "malicious"

    @property
    def excluded_by_a1(self) -> bool:
        return self.packed_flag or self.selfmod_flag


@dataclass
class Corpus:
    name: str
    samples: List[Sample] = field(default_factory=list)
    provenance: str = "measured"

    def split(self, which: str, include_excluded: bool = False) -> List[Sample]:
        return [s for s in self.samples
                if s.split == which and (include_excluded or not s.excluded_by_a1)]

    def malware_test(self, include_excluded: bool = False) -> List[Sample]:
        return [s for s in self.split("test", include_excluded) if s.is_malicious]

    def excluded(self) -> List[Sample]:
        return [s for s in self.samples if s.excluded_by_a1]

    def counts(self) -> Dict[str, int]:
        return {
            "total": len(self.samples),
            "malicious": sum(1 for s in self.samples if s.is_malicious),
            "benign": sum(1 for s in self.samples if not s.is_malicious),
            "packed_or_selfmod": len(self.excluded()),
            "test_malware_admitted": len(self.malware_test()),
        }


def load_manifest(path: str | Path, name: Optional[str] = None) -> Corpus:
    """Read a CSV manifest with the columns of ``MANIFEST_FIELDS``."""
    path = Path(path)
    rows: List[Sample] = []
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        missing = set(MANIFEST_FIELDS) - set(reader.fieldnames or ())
        if missing:
            raise ValueError(f"{path}: manifest is missing columns {sorted(missing)}")
        for r in reader:
            rows.append(Sample(
                sha256=r["sha256"].strip().lower(),
                label=r["label"].strip(),
                family=r["family"].strip(),
                split=r["split"].strip(),
                source=r["source"].strip(),
                collected=r["collected"].strip(),
                packer=r["packer"].strip(),
                compiler=r["compiler"].strip(),
                packed_flag=r["packed_flag"].strip() in ("1", "true", "True"),
                selfmod_flag=r["selfmod_flag"].strip() in ("1", "true", "True"),
                path=r["path"].strip(),
            ))
    return Corpus(name=name or path.stem, samples=rows, provenance="measured")


def verify_manifest(corpus: Corpus, check_hashes: bool = False) -> Dict[str, object]:
    """Check a manifest for the properties the experiments assume."""
    problems: List[str] = []
    seen: Dict[str, int] = {}
    for s in corpus.samples:
        seen[s.sha256] = seen.get(s.sha256, 0) + 1
    dupes = [h for h, n in seen.items() if n > 1]
    if dupes:
        problems.append(f"{len(dupes)} duplicate SHA-256 entries")
    splits = {s.split for s in corpus.samples}
    if not splits <= {"train", "val", "test"}:
        problems.append(f"unexpected split labels: {sorted(splits - {'train','val','test'})}")
    mismatched = 0
    if check_hashes:
        for s in corpus.samples:
            p = Path(s.path)
            if not p.exists():
                mismatched += 1
                continue
            h = hashlib.sha256(p.read_bytes()).hexdigest()
            if h != s.sha256:
                mismatched += 1
        if mismatched:
            problems.append(f"{mismatched} files missing or hash-mismatched")
    return {"ok": not problems, "problems": problems, "counts": corpus.counts()}


# --------------------------------------------------------------------------
# Synthetic demonstration corpus
# --------------------------------------------------------------------------

_BENIGN_APIS = ["api::CreateFile", "GetModuleHandleA", "RegOpenKeyExA", "fopen"]
_MALICIOUS_APIS = ["api::CreateProcess", "WinExec", "LoadLibraryW", "system"]


def _rand_function(name: str, rng: random.Random, malicious: bool,
                   n_blocks: int = 3) -> Function:
    """A synthetic function that exercises every rewrite rule.

    Values are threaded through the function and the last one is copied to a
    live-out register, so that most ops are live.  Without that, R3 removes
    everything before R4 or R5 ever sees a redex and the demonstration corpus
    silently stops testing two of the six rules.  A mixture of op shapes is
    generated on purpose:

      all-constant inputs            -> R4 folding sites
      commutative ops out of order   -> R5 normalisation sites
      a genuinely unused result      -> R3 sites
      aliased API calls              -> R6 sites

    R1 and R2 come from the block structure below.
    """
    blocks: Dict[str, Block] = {}
    labels = [f"L{i}" for i in range(n_blocks)]
    ret = Varnode("register", 0, 4)
    live: List[Varnode] = [Varnode("register", r * 4, 4) for r in range(1, 4)]
    uid = 0

    for i, lbl in enumerate(labels):
        ops: List[Op] = []
        for _ in range(rng.randrange(3, 7)):
            uid += 1
            dst = Varnode("unique", uid, 4)
            kind = rng.random()
            if kind < 0.22:
                # all-constant inputs: an R4 folding site
                ops.append(Op(rng.choice(["INT_ADD", "INT_MULT", "INT_XOR", "INT_OR"]),
                              out=dst,
                              ins=(const(rng.randrange(1 << 10), 4),
                                   const(rng.randrange(1 << 10), 4))))
                live.append(dst)
            elif kind < 0.50:
                # register first, constant second: out of structural order,
                # so a commutative opcode here is an R5 site
                src = rng.choice(live)
                ops.append(Op(rng.choice(["INT_ADD", "INT_XOR", "INT_AND", "INT_MULT"]),
                              out=dst, ins=(src, const(rng.randrange(1 << 12), 4))))
                live.append(dst)
            elif kind < 0.62:
                a, b = rng.choice(live), rng.choice(live)
                ops.append(Op(rng.choice(["INT_SUB", "INT_LESS", "INT_OR"]),
                              out=dst, ins=(a, b)))
                live.append(dst)
            elif kind < 0.74:
                # a result nobody reads: an R3 site
                ops.append(Op("INT_NEGATE",
                              out=Varnode("unique", 50_000 + uid, 4),
                              ins=(rng.choice(live),)))
            elif kind < 0.86:
                ops.append(Op("LOAD", out=dst,
                              ins=(Varnode("ram", rng.randrange(1 << 16), 4),)))
                live.append(dst)
            else:
                pool = _MALICIOUS_APIS if malicious else _BENIGN_APIS
                ops.append(Op("CALL", ins=(), target=rng.choice(pool)))
        if i + 1 < len(labels):
            r = rng.random()
            if r < 0.30:
                ops.append(Op("CBRANCH", ins=(rng.choice(live),),
                              targets=(labels[i + 1], labels[-1])))
            elif r < 0.45:
                # an indirect branch through a jump table: the construct the
                # jump-table length rule handles, and the one the injected
                # off-by-one of Section VII-J gets wrong
                ops.append(Op("BRANCHIND", ins=(rng.choice(live),),
                              targets=tuple(labels[i + 1:]) or (labels[-1],)))
            else:
                ops.append(Op("BRANCH", target=labels[i + 1]))
        else:
            ops.append(Op("COPY", out=ret, ins=(rng.choice(live),)))
            ops.append(Op("RETURN", ins=()))
        blocks[lbl] = Block(lbl, ops)
    # Guarantee at least one API call, so that every template carries the
    # signal the bucket classifier is meant to pick up.  Without this a large
    # share of templates have no call at all and are indistinguishable between
    # the two classes however well the model is trained.
    pool = _MALICIOUS_APIS if malicious else _BENIGN_APIS
    head = blocks[labels[0]]
    head.ops.insert(0, Op("CALL", ins=(), target=rng.choice(pool)))
    return Function(name=name, entry=labels[0], blocks=blocks, live_out=(ret,))


_LIBRARY_CACHE: Dict[Tuple[int, int, int], Tuple[List[Function], List[Function]]] = {}


def function_library(
    seed: int = 20260101, n_benign: int = 90, n_malicious: int = 40
) -> Tuple[List[Function], List[Function]]:
    """A shared pool of function templates, drawn from by every sample.

    This is the premise the whole method rests on and it has to be present in
    the demonstration corpus or the corpus tests nothing: programs share code,
    so the same canonical form recurs across binaries, and a bucket classifier
    can learn which forms are evidence of malice.  A corpus of independently
    random functions has no recurring canonical form at all, so every digest
    is unique, every bucket readout is noise, and the classifier cannot
    generalise from the training split to the test split no matter how it is
    trained.

    Function *names* are not part of kappa, so two samples that draw the same
    template under different names still produce the same canonical digest --
    which is the behaviour being demonstrated.
    """
    key = (seed, n_benign, n_malicious)
    if key not in _LIBRARY_CACHE:
        rng = random.Random(seed)
        ben = [_rand_function(f"lib_b{i}", rng, False) for i in range(n_benign)]
        mal = [_rand_function(f"lib_m{i}", rng, True) for i in range(n_malicious)]
        _LIBRARY_CACHE[key] = (ben, mal)
    return _LIBRARY_CACHE[key]


def _rename(fn: Function, name: str) -> Function:
    g = fn.copy()
    g.name = name
    return g


def synthetic_image(seed: int, malicious: bool,
                    n_functions: int = 16, n_roots: int = 10) -> ProgramImage:
    """One synthetic 'binary'.

    The function and root counts matter for more than realism.  C(x) must hold
    enough canonical functions that the k-overlap partition occupies a decent
    share of the B buckets; otherwise V(x) can never reach a threshold worth
    certifying and the demonstration run reports a radius of zero for every
    sample, which would say nothing about the pipeline.  With 10 roots, B = 64
    and k = 2 roughly a quarter of the buckets are occupied, which is the
    regime Section VII-B operates in.

    Malicious evidence is spread over several roots rather than concentrated
    in one, because spreading it is exactly what the certified-margin
    objective is supposed to reward.
    """
    rng = random.Random(seed)
    ben_lib, mal_lib = function_library()
    names = [f"fn{i}" for i in range(n_functions)]
    n_bad = max(2, n_roots // 2) if malicious else 0
    fns: List[Function] = []
    for i, nm in enumerate(names):
        src = rng.choice(mal_lib) if i < n_bad else rng.choice(ben_lib)
        fns.append(_rename(src, nm))
    # Wire direct calls into a small set of shared helper routines, so that
    # ownership counts exceed one.  This is the Example 1 situation -- one byte
    # of shared code owned by several roots -- and the certificate has to stay
    # correct there, so the corpus must contain it rather than avoid it.
    #
    # The wiring is deterministic in the template index rather than random.
    # A root's canonical form includes the body of the callee inlined into its
    # view, so a randomly chosen helper would make kappa(root) differ between
    # two samples that use the same root template, and no canonical form would
    # ever recur across the corpus.
    n_helpers = 4
    helpers = [_rename(ben_lib[-(j + 1)], f"helper{j}") for j in range(n_helpers)]
    fns.extend(helpers)
    roots = [("entry", names[0])] + \
            [("export", nm) for nm in names[1:n_roots]]
    root_names = [nm for _, nm in roots]
    for idx, nm in enumerate(root_names):
        fn = next(f for f in fns if f.name == nm)
        l = fn.entry
        ops = list(fn.blocks[l].ops)
        ops.insert(max(0, len(ops) - 1),
                   Op("CALL", ins=(), target=f"helper{idx % n_helpers}"))
        fn.blocks[l] = Block(l, ops)
    overlay = bytes(rng.randrange(256) for _ in range(rng.randrange(64, 512)))
    return build_image(fns, roots, overlay)


def synthetic_corpus(
    n_malicious: int = 60,
    n_benign: int = 60,
    seed: int = 0,
    packed_share: float = 0.10,
    n_sources: int = 2,
) -> Tuple[Corpus, Dict[str, ProgramImage]]:
    """A labelled corpus of synthetic images with a manifest-shaped index.

    The split is 70/10/20 stratified by label, matching Section VI-H, and a
    ``packed_share`` of samples carry the A1 exclusion flag so that the
    packed-subset path (``experiments/ev_packed.py``) has something to run on.
    """
    rng = random.Random(seed)
    samples: List[Sample] = []
    images: Dict[str, ProgramImage] = {}
    items = [(i, True) for i in range(n_malicious)] + \
            [(i, False) for i in range(n_benign)]
    for idx, (i, mal) in enumerate(items):
        img = synthetic_image(seed * 100003 + idx, mal)
        h = hashlib.sha256(bytes(img.data)).hexdigest()
        r = rng.random()
        split = "train" if r < 0.70 else ("val" if r < 0.80 else "test")
        packed = rng.random() < packed_share
        selfmod = packed and rng.random() < 0.25
        samples.append(Sample(
            sha256=h,
            label="malicious" if mal else "benign",
            family=(f"synthfam{i % 5}" if mal else ""),
            split=split,
            source=f"source{idx % n_sources}" if not mal else f"source{(idx + 1) % n_sources}",
            collected="2025-01-01",
            packer="synthetic-packer" if packed else "",
            compiler="synthetic-msvc",
            packed_flag=packed,
            selfmod_flag=selfmod,
            path=f"synthetic://{h[:16]}",
        ))
        images[h] = img
    return Corpus("original", samples, provenance="original"), images


def write_manifest(corpus: Corpus, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(MANIFEST_FIELDS))
        w.writeheader()
        for s in corpus.samples:
            w.writerow({
                "sha256": s.sha256, "label": s.label, "family": s.family,
                "split": s.split, "source": s.source, "collected": s.collected,
                "packer": s.packer, "compiler": s.compiler,
                "packed_flag": "1" if s.packed_flag else "0",
                "selfmod_flag": "1" if s.selfmod_flag else "0",
                "path": s.path,
            })
    return path
