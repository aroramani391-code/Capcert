"""Stage 3: content-addressed k-overlap partitioning (Section IV-C).

Every canonical function is placed into k buckets chosen by k keyed hashes of
its *content*.  Nothing is keyed on an identifier, an address or a position,
which is what makes Theorem 2 hold: changing one canonical function can move at
most k buckets, by construction rather than by analysis.

The keys are not secrets.  They fix the partition so that a certificate is
reproducible, and the white-box attacker of Section VII-C is assumed to know
them.
"""
from __future__ import annotations

import hashlib
import hmac
from collections import Counter
from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence, Tuple


DEFAULT_KEYS: Tuple[bytes, ...] = (
    b"capcert/partition/key/0",
    b"capcert/partition/key/1",
    b"capcert/partition/key/2",
)


@dataclass(frozen=True)
class PartitionConfig:
    B: int = 64            # number of buckets
    k: int = 2             # hashes per canonical function
    keys: Tuple[bytes, ...] = DEFAULT_KEYS
    occurrence_cap: int = 16   # Table XIV: cap on repeats in the readout

    def __post_init__(self) -> None:
        if self.k > len(self.keys):
            raise ValueError(f"need at least k={self.k} keys, have {len(self.keys)}")
        if self.B < self.k:
            raise ValueError("B must be at least k")


def bucket_indices(digest_hex: str, cfg: PartitionConfig) -> Tuple[int, ...]:
    """The k buckets a canonical form belongs to.

    Distinct keys give distinct hash families; the i-th bucket is the keyed
    digest reduced mod B.  Deterministic in the content alone.
    """
    out = []
    raw = digest_hex.encode("ascii")
    for i in range(cfg.k):
        mac = hmac.new(cfg.keys[i], raw, hashlib.sha256).digest()
        out.append(int.from_bytes(mac[:8], "big") % cfg.B)
    return tuple(out)


def buckets(cx: Counter, cfg: PartitionConfig) -> Dict[int, Counter]:
    """S_b(x) for every b: the content of each bucket, as a multiset.

    Multiplicity is retained (convention C3); the occurrence cap of Table XIV
    is applied in the readout, not here, so that d() and the certificate stay
    defined on the uncapped multiset.
    """
    out: Dict[int, Counter] = {b: Counter() for b in range(cfg.B)}
    for dg, mult in cx.items():
        for b in bucket_indices(dg, cfg):
            out[b][dg] += mult
    return out


def changed_buckets(
    cx: Counter, cy: Counter, cfg: PartitionConfig
) -> List[int]:
    """Buckets whose content differs between two programs."""
    bx, by = buckets(cx, cfg), buckets(cy, cfg)
    return [b for b in range(cfg.B) if bx[b] != by[b]]


def theorem2_bound(cx: Counter, cy: Counter, cfg: PartitionConfig) -> Tuple[int, int]:
    """(observed changed buckets, k * d(x,x')) -- Theorem 2, equation (21).

    The first must never exceed the second.  ``verification/tv4_conformance``
    checks this on every edit it applies.
    """
    from .canonical import edit_distance

    return len(changed_buckets(cx, cy, cfg)), cfg.k * edit_distance(cx, cy)


def occupancy(cx: Counter, cfg: PartitionConfig) -> List[int]:
    """|S_b(x)| for each b, counted with multiplicity."""
    bx = buckets(cx, cfg)
    return [sum(bx[b].values()) for b in range(cfg.B)]


def expected_occupancy(n: int, cfg: PartitionConfig) -> float:
    """E|S_b(x)| = n [1 - (1 - 1/B)^k] -- Proposition 1, equation (32)."""
    return n * (1.0 - (1.0 - 1.0 / cfg.B) ** cfg.k)


def q_k(cfg: PartitionConfig) -> float:
    """q_k = k! / B^k -- the per-candidate hit probability of Theorem 5."""
    import math

    return math.factorial(cfg.k) / (cfg.B ** cfg.k)


def readout_vector(bucket_content: Counter, cfg: PartitionConfig, dim: int = 256) -> List[float]:
    """A fixed-width feature vector for one bucket's content.

    Deterministic in the multiset of digests alone.  The occurrence cap of
    Table XIV applies here: a canonical form occurring more than ``cap`` times
    contributes ``cap`` times, which stops duplicate flooding (EV8) from
    dominating a bucket.
    """
    vec = [0.0] * dim
    for dg, mult in bucket_content.items():
        m = min(mult, cfg.occurrence_cap)
        raw = bytes.fromhex(dg)
        for j in range(0, 16, 2):
            idx = int.from_bytes(raw[j:j + 2], "big") % dim
            vec[idx] += float(m)
    norm = sum(v * v for v in vec) ** 0.5
    return [v / norm for v in vec] if norm > 0 else vec
