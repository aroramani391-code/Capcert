"""The statistical protocol of Section VI-H.

Everything the manuscript reports an interval or a p-value for is computed
here, so that a reader can check a claim by calling one function rather than
reconstructing a procedure from prose:

  * exact Clopper-Pearson intervals for proportions (certified accuracy),
  * percentile bootstrap intervals for F1 and AUC, paired and unpaired,
  * McNemar's test for two detectors on the same test set,
  * the Wilcoxon signed-rank test across seeds,
  * Holm-Bonferroni adjustment over a family of p-values,
  * the effect sizes the protocol requires alongside each test.

Only ``scipy`` and ``numpy`` are needed; nothing here depends on the model.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
from scipy import stats as _st

Interval = Tuple[float, float]


# --------------------------------------------------------------------------
# Proportions
# --------------------------------------------------------------------------

def clopper_pearson(k: int, n: int, alpha: float = 0.05) -> Interval:
    """Exact Clopper-Pearson interval for k successes in n trials, in percent.

    Used for every certified-accuracy figure, which is a proportion of a fixed
    malware test set, so no bootstrap is needed and the interval is exact.
    """
    if n <= 0:
        raise ValueError("n must be positive")
    if not 0 <= k <= n:
        raise ValueError("need 0 <= k <= n")
    lo = 0.0 if k == 0 else _st.beta.ppf(alpha / 2, k, n - k + 1)
    hi = 1.0 if k == n else _st.beta.ppf(1 - alpha / 2, k + 1, n - k)
    return (round(float(lo) * 100, 2), round(float(hi) * 100, 2))


@dataclass
class Proportion:
    k: int
    n: int
    alpha: float = 0.05

    @property
    def value(self) -> float:
        return round(100.0 * self.k / self.n, 2) if self.n else float("nan")

    @property
    def interval(self) -> Interval:
        return clopper_pearson(self.k, self.n, self.alpha)

    def as_cell(self) -> str:
        lo, hi = self.interval
        return f"{self.value:.2f} [{lo:.2f}, {hi:.2f}]"


# --------------------------------------------------------------------------
# Classification metrics
# --------------------------------------------------------------------------

def confusion(y_true: Sequence[int], y_pred: Sequence[int]) -> Dict[str, int]:
    yt, yp = np.asarray(y_true, int), np.asarray(y_pred, int)
    return {
        "tp": int(((yt == 1) & (yp == 1)).sum()),
        "fn": int(((yt == 1) & (yp == 0)).sum()),
        "fp": int(((yt == 0) & (yp == 1)).sum()),
        "tn": int(((yt == 0) & (yp == 0)).sum()),
    }


def metrics(y_true: Sequence[int], y_pred: Sequence[int],
            scores: Optional[Sequence[float]] = None) -> Dict[str, float]:
    c = confusion(y_true, y_pred)
    tp, fn, fp, tn = c["tp"], c["fn"], c["fp"], c["tn"]
    prec = tp / (tp + fp) if tp + fp else 0.0
    rec = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
    acc = (tp + tn) / max(1, tp + tn + fp + fn)
    out = {"accuracy": acc * 100, "precision": prec * 100,
           "recall": rec * 100, "f1": f1 * 100, **c}
    if scores is not None and len(set(y_true)) == 2:
        out["auc"] = float(_st.rankdata(scores)[np.asarray(y_true) == 1].mean()
                           - (np.sum(np.asarray(y_true) == 1) + 1) / 2) \
            / max(1, np.sum(np.asarray(y_true) == 0)) * 100
    return out


def _f1_from_counts(tp: int, fn: int, fp: int) -> float:
    d = 2 * tp + fp + fn
    return 200.0 * tp / d if d else 0.0


# --------------------------------------------------------------------------
# Bootstrap
# --------------------------------------------------------------------------

def bootstrap_metric(
    y_true: Sequence[int],
    y_pred: Sequence[int],
    metric: str = "f1",
    n_resamples: int = 10_000,
    alpha: float = 0.05,
    seed: int = 0,
) -> Tuple[float, Interval]:
    """Percentile bootstrap over test samples, as specified in Section VI-H."""
    yt, yp = np.asarray(y_true, int), np.asarray(y_pred, int)
    n = len(yt)
    rng = np.random.default_rng(seed)
    point = metrics(yt, yp)[metric]
    draws = np.empty(n_resamples)
    for i in range(n_resamples):
        idx = rng.integers(0, n, n)
        draws[i] = metrics(yt[idx], yp[idx])[metric]
    lo, hi = np.percentile(draws, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return round(float(point), 2), (round(float(lo), 2), round(float(hi), 2))


def paired_bootstrap_difference(
    y_true: Sequence[int],
    y_pred_a: Sequence[int],
    y_pred_b: Sequence[int],
    metric: str = "f1",
    n_resamples: int = 10_000,
    alpha: float = 0.05,
    seed: int = 0,
) -> Tuple[float, Interval]:
    """Paired bootstrap of metric(A) - metric(B) on the same test set.

    Pairing is what makes the non-inferiority criterion of Section VI-H
    meaningful: the two models see the same resample, so their shared errors
    cancel instead of inflating the interval.
    """
    yt = np.asarray(y_true, int)
    a, b = np.asarray(y_pred_a, int), np.asarray(y_pred_b, int)
    n = len(yt)
    rng = np.random.default_rng(seed)
    point = metrics(yt, a)[metric] - metrics(yt, b)[metric]
    draws = np.empty(n_resamples)
    for i in range(n_resamples):
        idx = rng.integers(0, n, n)
        draws[i] = metrics(yt[idx], a[idx])[metric] - metrics(yt[idx], b[idx])[metric]
    lo, hi = np.percentile(draws, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return round(float(point), 2), (round(float(lo), 2), round(float(hi), 2))


def non_inferior(diff_interval: Interval, epsilon: float = 0.5) -> bool:
    """The pass criterion of Section VI-H: lower bound above -epsilon."""
    return diff_interval[0] > -epsilon


# --------------------------------------------------------------------------
# Hypothesis tests with effect sizes
# --------------------------------------------------------------------------

@dataclass
class TestResult:
    name: str
    statistic: float
    p_value: float
    effect_name: str
    effect: float
    detail: Dict[str, float]

    def as_row(self) -> Dict[str, object]:
        return {"test": self.name, "statistic": round(self.statistic, 4),
                "p": self.p_value, self.effect_name: round(self.effect, 4),
                **self.detail}


def mcnemar(y_true: Sequence[int], a: Sequence[int], b: Sequence[int],
            exact: bool = True) -> TestResult:
    """McNemar's test for two detectors on the same test set.

    The effect size is the odds ratio of discordant pairs, which is what the
    protocol asks for; ``n01``/``n10`` are reported so the reader can see the
    counts the test actually used.
    """
    yt = np.asarray(y_true, int)
    ca, cb = (np.asarray(a, int) == yt), (np.asarray(b, int) == yt)
    n01 = int((~ca & cb).sum())   # A wrong, B right
    n10 = int((ca & ~cb).sum())   # A right, B wrong
    n = n01 + n10
    if n == 0:
        return TestResult("mcnemar", 0.0, 1.0, "odds_ratio", 1.0,
                          {"n01": 0, "n10": 0})
    if exact and n < 200:
        p = float(min(1.0, 2 * _st.binom.cdf(min(n01, n10), n, 0.5)))
        stat = float(min(n01, n10))
    else:
        stat = (abs(n01 - n10) - 1) ** 2 / n
        p = float(_st.chi2.sf(stat, 1))
    or_ = (n10 + 0.5) / (n01 + 0.5)
    return TestResult("mcnemar", float(stat), p, "odds_ratio", float(or_),
                      {"n01": n01, "n10": n10})


def wilcoxon_seeds(a: Sequence[float], b: Sequence[float]) -> TestResult:
    """Wilcoxon signed-rank across seeds, with matched-pairs rank-biserial r."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    if len(a) != len(b):
        raise ValueError("paired samples must have equal length")
    d = a - b
    if np.allclose(d, 0):
        return TestResult("wilcoxon", 0.0, 1.0, "rank_biserial", 0.0, {"n": len(a)})
    res = _st.wilcoxon(a, b, zero_method="wilcox", alternative="two-sided")
    nz = d[d != 0]
    ranks = _st.rankdata(np.abs(nz))
    rplus = float(ranks[nz > 0].sum())
    rminus = float(ranks[nz < 0].sum())
    total = rplus + rminus
    r = (rplus - rminus) / total if total else 0.0
    return TestResult("wilcoxon", float(res.statistic), float(res.pvalue),
                      "rank_biserial", float(r), {"n": len(a)})


def holm_bonferroni(p_values: Sequence[float], alpha: float = 0.05
                    ) -> List[Dict[str, object]]:
    """Holm-Bonferroni step-down adjustment.

    Returns one record per input p-value, in the input order, carrying the
    adjusted p-value and the reject decision at ``alpha``.
    """
    p = list(map(float, p_values))
    m = len(p)
    order = sorted(range(m), key=lambda i: p[i])
    adjusted = [0.0] * m
    running = 0.0
    for rank, idx in enumerate(order):
        val = (m - rank) * p[idx]
        running = max(running, min(1.0, val))
        adjusted[idx] = running
    return [{"index": i, "p": p[i], "p_adj": round(adjusted[i], 6),
             "reject": adjusted[i] <= alpha} for i in range(m)]


# --------------------------------------------------------------------------
# Aggregation across seeds
# --------------------------------------------------------------------------

def mean_sd(values: Sequence[float]) -> Tuple[float, float]:
    v = np.asarray(values, float)
    if v.size == 0:
        return (float("nan"), float("nan"))
    return (round(float(v.mean()), 2),
            round(float(v.std(ddof=1)) if v.size > 1 else 0.0, 2))


def summarize_seeds(per_seed: Dict[int, float]) -> Dict[str, object]:
    vals = [per_seed[s] for s in sorted(per_seed)]
    m, s = mean_sd(vals)
    return {"seeds": sorted(per_seed), "values": vals, "mean": m, "sd": s,
            "n_seeds": len(vals)}


def certified_accuracy_curve(
    radii: Sequence[Optional[int]], n_total: int, budgets: Sequence[int]
) -> Dict[int, Proportion]:
    """CA(u) of equation (5), with its Clopper-Pearson interval, for each u.

    ``radii`` holds rho_hat(x) for every malware test sample, with ``None``
    for samples the detector missed.  Convention C1 is enforced here: a missed
    sample never counts as certified at any budget.
    """
    out: Dict[int, Proportion] = {}
    for u in budgets:
        k = sum(1 for r in radii if r is not None and r >= u)
        out[u] = Proportion(k, n_total)
    return out
