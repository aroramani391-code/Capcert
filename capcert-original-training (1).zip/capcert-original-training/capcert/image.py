"""A minimal container format standing in for a PE image.

The artifact needs a byte-level object that an *edit* can be applied to, so
that footprints can be measured in the units Lemma 1 and Corollary 1 use.  A
real PE parser is not what any of the claims turn on; what they turn on is that

  * functions live in a byte stream and move when bytes are inserted,
  * call targets are located through an index rather than read as values,
  * roots come from a root table (entry point, exports, TLS callbacks,
    exception directory), and
  * there are regions (overlay, resources, padding) that no view ever reads.

This module provides exactly that, and nothing else.  ``capcert.lfr`` recovers
functions from it under the dependency-recording accessor, so Property L0 is a
checkable statement about this format rather than a stipulation.

Layout
------
    [MAGIC 8]
    [code section: concatenated function records]
    [overlay region: arbitrary bytes, never read by a view]
    [index:  u16 count, then (name, u32 offset) entries]
    [roots:  u16 count, then (kind u8, name) entries]
    [u32 index_offset][u32 roots_offset][MAGIC_END 8]

A function record is
    [u32 total_len][u8 name_len][name][u16 n_ops][ops...]
and an op is
    [u8 opcode][u8 flags][out varnode?][u8 n_ins][ins...]
    [u8 target_len][target][u8 n_succ][(u8 len, label)...]
    [u8 n_jt][(u8 len, label)...]          # jump table, present iff BRANCHIND
with a varnode encoded as [u8 space][u32 offset][u8 size].
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from .ir import (
    BOOLEAN_RESULT_OPS,
    PURE_OPS,
    SPACES,
    Block,
    Function,
    Op,
    Varnode,
)

MAGIC = b"CAPCERT\x00"
MAGIC_END = b"\x00CAPCERT"

OPCODES: Tuple[str, ...] = tuple(PURE_OPS) + (
    "LOAD", "STORE", "CALL", "CALLIND", "RETURN", "BRANCH", "CBRANCH", "BRANCHIND",
)
OPCODE_ID = {o: i for i, o in enumerate(OPCODES)}

ROOT_KINDS: Tuple[str, ...] = ("entry", "export", "tls", "seh")
ROOT_KIND_ID = {k: i for i, k in enumerate(ROOT_KINDS)}


# --------------------------------------------------------------------------
# Encoding
# --------------------------------------------------------------------------

def _enc_vn(v: Varnode) -> bytes:
    return struct.pack("<BIB", SPACES.index(v.space), v.offset, v.size)


def _enc_str(s: str) -> bytes:
    raw = s.encode("utf-8")
    if len(raw) > 255:
        raise ValueError("name too long")
    return bytes([len(raw)]) + raw


def _enc_op(op: Op, jt_desc: Optional[Tuple[int, int, int]] = None) -> bytes:
    flags = 1 if op.out is not None else 0
    out = bytes([OPCODE_ID[op.opcode], flags])
    if op.out is not None:
        out += _enc_vn(op.out)
    out += bytes([len(op.ins)]) + b"".join(_enc_vn(v) for v in op.ins)
    out += _enc_str(op.target or "")
    # A BRANCHIND's successors live in the jump-table section, outside the
    # function record, referenced by absolute offset, byte extent and count --
    # which is where real jump tables live, and what makes "reading one entry
    # past the bound" a read outside the function's dependency set rather than
    # a harmless read of the next instruction.
    if op.opcode == "BRANCHIND":
        succs = ()
        jt_off, jt_bytes, jt_count = jt_desc or (0, 0, 0)
    else:
        succs = op.targets
        jt_off, jt_bytes, jt_count = 0, 0, 0
    out += bytes([len(succs)]) + b"".join(_enc_str(t) for t in succs)
    out += struct.pack("<IHB", jt_off, jt_bytes, jt_count)
    return out


def encode_jump_table(targets: Sequence[str]) -> bytes:
    return b"".join(_enc_str(t) for t in targets)


def encode_function(fn: Function,
                    jt_descs: Optional[List[Tuple[int, int, int]]] = None) -> bytes:
    """Serialise one function.  ``jt_descs`` supplies one (offset, bytes,
    count) descriptor per BRANCHIND, in op order."""
    descs = list(jt_descs or [])
    body = _enc_str(fn.name)
    ops: List[bytes] = []
    for lbl in fn.order():
        ops.append(_enc_op(Op("BRANCH", target="#block:" + lbl)))
        for op in fn.blocks[lbl].ops:
            d = descs.pop(0) if (op.opcode == "BRANCHIND" and descs) else None
            ops.append(_enc_op(op, d))
    body += struct.pack("<H", len(ops)) + b"".join(ops)
    return struct.pack("<I", len(body) + 4) + body


def branchind_ops(fn: Function) -> List[Op]:
    return [op for lbl in fn.order() for op in fn.blocks[lbl].ops
            if op.opcode == "BRANCHIND"]


@dataclass
class ProgramImage:
    """A byte image plus the structural tables, kept in sync."""

    data: bytearray
    index: Dict[str, int]                  # function name -> absolute offset
    roots: List[Tuple[str, str]]           # (kind, function name)
    index_offset: int
    roots_offset: int
    overlay: Tuple[int, int] = (0, 0)      # [start, end) never read by a view
    jt_section: Tuple[int, int] = (0, 0)   # [start, end) of the jump tables

    def copy(self) -> "ProgramImage":
        return ProgramImage(
            bytearray(self.data), dict(self.index), list(self.roots),
            self.index_offset, self.roots_offset, self.overlay, self.jt_section,
        )

    def root_names(self) -> List[str]:
        return [name for _, name in self.roots]

    def __len__(self) -> int:
        return len(self.data)


def build_image(
    functions: Sequence[Function],
    roots: Sequence[Tuple[str, str]],
    overlay_bytes: bytes = b"",
) -> ProgramImage:
    """Serialise functions into an image with an index and a root table."""
    # Pass 1: lay out the jump-table section immediately after the magic, so
    # that its absolute offsets are known before any code is encoded.
    jt_blob = bytearray()
    jt_base = len(MAGIC)
    per_fn: Dict[str, List[Tuple[int, int, int]]] = {}
    for fn in functions:
        descs: List[Tuple[int, int, int]] = []
        for op in branchind_ops(fn):
            raw = encode_jump_table(op.targets)
            descs.append((jt_base + len(jt_blob), len(raw), len(op.targets)))
            jt_blob += raw
        per_fn[fn.name] = descs

    # Pass 2: the image.
    buf = bytearray(MAGIC)
    buf += jt_blob
    jt_section = (jt_base, jt_base + len(jt_blob))
    index: Dict[str, int] = {}
    for fn in functions:
        index[fn.name] = len(buf)
        buf += encode_function(fn, per_fn.get(fn.name))

    overlay_start = len(buf)
    buf += overlay_bytes
    overlay_end = len(buf)

    index_offset = len(buf)
    buf += struct.pack("<H", len(index))
    for name, off in sorted(index.items()):
        buf += _enc_str(name) + struct.pack("<I", off)

    roots_offset = len(buf)
    buf += struct.pack("<H", len(roots))
    for kind, name in roots:
        buf += bytes([ROOT_KIND_ID[kind]]) + _enc_str(name)

    buf += struct.pack("<II", index_offset, roots_offset) + MAGIC_END
    return ProgramImage(buf, index, list(roots), index_offset, roots_offset,
                        (overlay_start, overlay_end), jt_section)


# --------------------------------------------------------------------------
# Dependency-recording accessor  (the L0 contract)
# --------------------------------------------------------------------------

class L0Violation(RuntimeError):
    """A read outside the dependency set.  TV4 treats this as a defect."""


@dataclass
class Accessor:
    """The only way to read a byte of the image.

    Every read is recorded, and each read is declared either ``content`` -- the
    bytes the canonical form may depend on -- or ``locator`` -- bytes used only
    to find something, never as a value.  Property L0 is the statement that
    kappa is a function of the content bytes alone, and that locator bytes
    affect only where things are, which is what "up to relocation" means in
    Section IV-A.

    ``record`` is the fault-injection switch used by
    ``verification/l0_fault_injection.py``: with it set to False the accessor
    reads without recording, which is precisely the defect the L0 audit must
    detect (and precisely the shape of the jump-table off-by-one reported in
    Section VII-J).
    """

    image: ProgramImage
    content: set = field(default_factory=set)
    locator: set = field(default_factory=set)
    #: every byte this accessor handed out, whether or not the recovery
    #: declared it as a dependency.  The instrumentation sits *below* the
    #: recording logic on purpose: code that forgets to declare a read is
    #: still visible here, and that is the only way the audit can catch a
    #: read that was never recorded.
    all_reads: set = field(default_factory=set)
    record: bool = True
    reads: int = 0

    def read(self, offset: int, n: int, role: str = "content") -> bytes:
        if offset < 0 or offset + n > len(self.image.data):
            raise L0Violation(f"read out of image bounds at {offset}+{n}")
        self.reads += 1
        self.all_reads.update(range(offset, offset + n))
        if self.record:
            tgt = self.content if role == "content" else self.locator
            tgt.update(range(offset, offset + n))
        return bytes(self.image.data[offset:offset + n])

    def undeclared(self) -> set:
        """Bytes read but never declared as a dependency.  Must be empty."""
        return self.all_reads - self.content - self.locator

    def u8(self, off: int, role: str = "content") -> int:
        return self.read(off, 1, role)[0]

    def u16(self, off: int, role: str = "content") -> int:
        return struct.unpack("<H", self.read(off, 2, role))[0]

    def u32(self, off: int, role: str = "content") -> int:
        return struct.unpack("<I", self.read(off, 4, role))[0]

    def string(self, off: int, role: str = "content") -> Tuple[str, int]:
        n = self.u8(off, role)
        return self.read(off + 1, n, role).decode("utf-8"), off + 1 + n
