"""Stage 5: the asymmetric threshold vote and the certified radius.

Section IV-E.  The detector labels x malicious when at least t of the B buckets
vote malicious, and the certified radius is

    rho_hat(x) = floor( (V(x) - t) / k )                       (25)

computed in one pass over the buckets, with no sampling, so it holds with
certainty.  For family classification the plurality version of Theorem 3(b) is
used instead.

Conventions C1-C5 of Section IV-E are enforced here rather than assumed:

  C1  the radius is defined only when F(x) = 1; a missed sample gets ``None``
      and is never counted as certified;
  C2  the vote is >= t, not > t;
  C3  multiplicity is kept everywhere (see ``canonical``/``partition``);
  C4  ties in family classification go to the lower class index;
  C5  the radius is a non-negative integer, and a radius of zero still
      certifies every x' at distance zero.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from .partition import PartitionConfig, buckets, readout_vector

#: A base classifier maps one bucket's content to a malicious logit z_b.
BaseClassifier = Callable[[Counter, PartitionConfig], float]


@dataclass(frozen=True)
class VoteConfig:
    t: int = 7            # threshold, swept on validation (Table XIV)
    margin_m: int = 4     # m = k * u_star, used by the training objective


@dataclass
class Verdict:
    label: int                     # 1 = malicious
    votes: int                     # V(x)
    logits: List[float]            # z_b for each bucket
    radius: Optional[int]          # rho_hat(x); None when label != 1  (C1)


def as_base_classifier(g) -> BaseClassifier:
    """Accept either a plain callable or a model exposing ``bucket_logit``."""
    fn = getattr(g, "bucket_logit", None)
    return fn if callable(fn) else g


def vote(
    cx: Counter,
    g: BaseClassifier,
    pcfg: PartitionConfig,
    vcfg: VoteConfig,
) -> Verdict:
    """Run the detector on a canonical multiset."""
    g = as_base_classifier(g)
    content = buckets(cx, pcfg)
    logits = [g(content[b], pcfg) for b in range(pcfg.B)]
    V = sum(1 for z in logits if z > 0.0)
    label = 1 if V >= vcfg.t else 0                      # C2
    radius = certified_radius(V, pcfg, vcfg) if label == 1 else None   # C1
    return Verdict(label=label, votes=V, logits=logits, radius=radius)


def certified_radius(V: int, pcfg: PartitionConfig, vcfg: VoteConfig) -> int:
    """floor((V - t) / k), equation (25).  Non-negative by C5."""
    if V < vcfg.t:
        raise ValueError("radius is undefined when the sample is not detected (C1)")
    return (V - vcfg.t) // pcfg.k


def certified_radius_family(
    counts: Sequence[int], pcfg: PartitionConfig
) -> int:
    """Theorem 3(b): plurality version for family classification.

    With n_c the number of buckets voting class c and c-hat the plurality
    class, a changed bucket can lower n_chat by one and raise some n_c by one,
    so the margin must cover 2*k*d.  Ties go to the lower index (C4).
    """
    if not counts:
        raise ValueError("no classes")
    best = max(range(len(counts)), key=lambda c: (counts[c], -c))
    margins = []
    for c in range(len(counts)):
        if c == best:
            continue
        # the tie rule gives c-hat the tie, so c needs a strict excess
        slack = counts[best] - counts[c] - (1 if c < best else 0)
        margins.append(slack)
    if not margins:
        return 0
    return max(0, min(margins) // (2 * pcfg.k))


# --------------------------------------------------------------------------
# A deterministic reference base classifier
# --------------------------------------------------------------------------

class LinearBaseClassifier:
    """A reference g_theta with no learned state beyond a weight vector.

    The artifact ships this so that every verification harness (TV1-TV5) and
    every certificate computation runs without a GPU, a trained checkpoint or
    PyTorch.  ``capcert.model`` provides the GIN classifier of Section IV-D
    for the experiments that need it; both satisfy the same interface, and the
    certificate is a property of the vote, not of which one is plugged in.
    """

    def __init__(self, weights: Sequence[float], bias: float = 0.0, dim: int = 256):
        self.w = list(weights)
        self.b = float(bias)
        self.dim = dim

    def __call__(self, content: Counter, pcfg: PartitionConfig) -> float:
        if not content:
            return -1.0
        v = readout_vector(content, pcfg, self.dim)
        return sum(wi * vi for wi, vi in zip(self.w, v)) + self.b

    @classmethod
    def fit_reference(
        cls,
        malicious_digests: Sequence[str],
        dim: int = 256,
        strength: float = 1.0,
    ) -> "LinearBaseClassifier":
        """A transparent, deterministic g: positive on buckets holding any of
        the given digests, negative otherwise.  Used by the verification
        harnesses, which need a fixed g rather than a good one."""
        w = [0.0] * dim
        for dg in malicious_digests:
            raw = bytes.fromhex(dg)
            for j in range(0, 16, 2):
                w[int.from_bytes(raw[j:j + 2], "big") % dim] += strength
        return cls(w, bias=-1e-6, dim=dim)


# --------------------------------------------------------------------------
# Surrogate gap (Proposition 3)
# --------------------------------------------------------------------------

import math  # noqa: E402


def soft_vote(logits: Sequence[float], tau: float) -> float:
    """s(x) of equation (28)."""
    return sum(1.0 / (1.0 + math.exp(-z / tau)) for z in logits)


def surrogate_gap(logits: Sequence[float], tau: float) -> float:
    """epsilon_tau(x) of equation (31); bounds |s(x) - V(x)|."""
    return sum(1.0 / (1.0 + math.exp(abs(z) / tau)) for z in logits)


def radius_lower_bound(
    logits: Sequence[float], tau: float, pcfg: PartitionConfig, vcfg: VoteConfig
) -> Optional[int]:
    """The second inequality of (31), when its right-hand side is non-negative."""
    s = soft_vote(logits, tau)
    eps = surrogate_gap(logits, tau)
    val = (s - eps - vcfg.t) / pcfg.k
    return int(math.floor(val)) if val >= 0 else None
