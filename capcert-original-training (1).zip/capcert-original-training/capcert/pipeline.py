"""End-to-end pipeline: corpus -> canonical multisets -> features -> detector.

The experiment scripts all need the same few steps, and they all need them to
be cached, deterministic and provenance-stamped.  They live here rather than
being copied into each EV runner.
"""
from __future__ import annotations

import json
import time
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from .canonical import canonical_multiset
from .datasets import Corpus, Sample, synthetic_corpus
from .edits import canonical_of_image
from .image import ProgramImage
from .lfr import RecoveryOptions, recover
from .model import TrainConfig, bucket_features, save_checkpoint, train
from .partition import PartitionConfig
from .stats import Proportion, certified_accuracy_curve, metrics
from .vote import VoteConfig, Verdict, vote

BUDGETS = (0, 1, 2, 5, 10)


@dataclass
class Prepared:
    corpus: Corpus
    images: Dict[str, ProgramImage]
    canonical: Dict[str, Counter] = field(default_factory=dict)
    features: Dict[str, np.ndarray] = field(default_factory=dict)
    timings: Dict[str, float] = field(default_factory=dict)

    def subset(self, samples: Sequence[Sample]) -> Tuple[List[np.ndarray], List[int]]:
        return ([self.features[s.sha256] for s in samples],
                [1 if s.is_malicious else 0 for s in samples])


def load_corpus(
    source: str = "original",
    manifest: Optional[str] = None,
    n: int = 120,
    seed: int = 0,
    packed_share: float = 0.10,
) -> Tuple[Corpus, Dict[str, ProgramImage], str]:
    """Return (corpus, images, provenance).

    A real corpus needs the Stage 1 front end over real PE files, which this
    repository does not ship binaries for; ``docs/REAL_DATA.md`` says how to
    wire it.  The default source is the original training corpus shipped with
    this repo, and its provenance is stamped ``original``.
    """
    if manifest:
        from .datasets import load_manifest

        corpus = load_manifest(manifest, source)
        raise SystemExit(
            "A measured run needs the Stage 1 front end over the binaries this\n"
            f"manifest names ({len(corpus.samples)} files).  Set CAPCERT_FRONTEND\n"
            "to an LFR build and see docs/REAL_DATA.md; the pipeline below is\n"
            "unchanged, only the source of Gamma(x) differs."
        )
    corpus, images = synthetic_corpus(n_malicious=n // 2, n_benign=n // 2,
                                      seed=seed, packed_share=packed_share)
    return corpus, images, "original"


def prepare(
    corpus: Corpus,
    images: Dict[str, ProgramImage],
    pcfg: PartitionConfig,
    opts: Optional[RecoveryOptions] = None,
    include_excluded: bool = True,
) -> Prepared:
    """Recover, canonicalize, partition and featurise every sample."""
    opts = opts or RecoveryOptions()
    prep = Prepared(corpus=corpus, images=images)
    t0 = time.time()
    for s in corpus.samples:
        if not include_excluded and s.excluded_by_a1:
            continue
        img = images[s.sha256]
        prep.canonical[s.sha256] = canonical_of_image(img, opts)
    prep.timings["canonicalize_s"] = round(time.time() - t0, 3)
    t1 = time.time()
    for sha, cx in prep.canonical.items():
        prep.features[sha] = bucket_features(cx, pcfg)
    prep.timings["featurize_s"] = round(time.time() - t1, 3)
    return prep


def fit(
    prep: Prepared,
    pcfg: PartitionConfig,
    vcfg: VoteConfig,
    tcfg: TrainConfig,
    on_epoch=None,
):
    train_samples = [s for s in prep.corpus.split("train")
                     if s.sha256 in prep.features]
    X, y = prep.subset(train_samples)
    if not X:
        raise RuntimeError("no training samples with features")
    return train(X, y, pcfg, vcfg, tcfg, on_epoch)


def evaluate_split(
    prep: Prepared,
    model,
    pcfg: PartitionConfig,
    vcfg: VoteConfig,
    samples: Sequence[Sample],
) -> Dict[str, object]:
    """Verdicts, clean metrics and the certified-accuracy curve for a split."""
    y_true, y_pred, votes, radii = [], [], [], []
    per_sample = []
    for s in samples:
        cx = prep.canonical[s.sha256]
        v: Verdict = vote(cx, model, pcfg, vcfg)
        y_true.append(1 if s.is_malicious else 0)
        y_pred.append(v.label)
        votes.append(v.votes)
        if s.is_malicious:
            radii.append(v.radius)
        per_sample.append({"sha256": s.sha256[:16], "label": s.label,
                           "predicted": v.label, "votes": v.votes,
                           "radius": v.radius})
    n_mal = sum(y_true)
    ca = certified_accuracy_curve(radii, n_mal, BUDGETS) if n_mal else {}
    detected = [r for r in radii if r is not None]
    return {
        "n": len(samples),
        "n_malicious": n_mal,
        "clean": metrics(y_true, y_pred, votes),
        "certified_accuracy": {u: {"value": p.value, "interval": list(p.interval),
                                   "k": p.k, "n": p.n}
                               for u, p in ca.items()},
        "median_radius": (float(np.median(detected)) if detected else None),
        "per_sample": per_sample,
    }
