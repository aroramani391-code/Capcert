"""Stage 4: the base classifier, and the certified-margin MIL objective.

Section IV-D and IV-G.  The base classifier scores one bucket's content; the
detector is the threshold vote over the B bucket scores, and the certificate is
a property of that vote, not of the classifier.  Two backends are provided and
both satisfy the ``BaseClassifier`` interface of ``capcert.vote``:

  torch    the GIN-style encoder of Section IV-D, trained with the
           certified-margin multiple-instance objective of equation (30).
           Produces checkpoints.

  numpy    a logistic model over the same bucket readout, trained with the
           same objective by plain gradient descent.  It exists so that the
           whole pipeline -- including training and checkpointing -- runs with
           no deep-learning stack installed, which is what keeps the
           verification harnesses independent of a GPU.

The objective is the point of this module, so it is written once, in
``mil_losses``, and shared by both backends.  What makes training aware of the
certificate is the first term: it rewards malicious evidence that appears in
*many* buckets rather than strong evidence confined to one, because each unit
of edit budget costs k votes by equation (25).
"""
from __future__ import annotations

import json
import math
from collections import Counter
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from .partition import PartitionConfig, buckets, readout_vector
from .vote import VoteConfig

try:  # optional
    import torch
    import torch.nn as nn
    HAVE_TORCH = True
except Exception:  # pragma: no cover
    torch = None  # type: ignore
    nn = None  # type: ignore
    HAVE_TORCH = False


READOUT_DIM = 256


@dataclass
class TrainConfig:
    dim: int = READOUT_DIM
    hidden: int = 256
    layers: int = 3
    lr: float = 5e-4
    weight_decay: float = 5e-3
    epochs: int = 40
    batch_size: int = 32
    tau_start: float = 1.0
    tau_end: float = 0.1
    anneal: bool = True
    margin_m: Optional[int] = None     # defaults to k * u_star
    u_star: int = 2
    eta: float = 0.1                   # bucket-level benign weight
    seed: int = 0
    backend: str = "auto"              # "torch" | "numpy" | "auto"

    def resolved_backend(self) -> str:
        if self.backend != "auto":
            return self.backend
        return "torch" if HAVE_TORCH else "numpy"

    def margin(self, pcfg: PartitionConfig) -> int:
        return self.margin_m if self.margin_m is not None else pcfg.k * self.u_star

    def tau_at(self, epoch: int) -> float:
        if not self.anneal or self.epochs <= 1:
            return self.tau_end
        frac = epoch / (self.epochs - 1)
        return math.exp(math.log(self.tau_start) * (1 - frac)
                        + math.log(self.tau_end) * frac)


# --------------------------------------------------------------------------
# Featurisation
# --------------------------------------------------------------------------

def bucket_features(cx: Counter, pcfg: PartitionConfig,
                    dim: int = READOUT_DIM) -> np.ndarray:
    """A B x dim matrix: one readout vector per bucket."""
    content = buckets(cx, pcfg)
    return np.asarray([readout_vector(content[b], pcfg, dim)
                       for b in range(pcfg.B)], dtype=np.float32)


# --------------------------------------------------------------------------
# The objective (equations 28-30), backend-independent
# --------------------------------------------------------------------------

def softplus(x: np.ndarray) -> np.ndarray:
    return np.logaddexp(0.0, x)


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


def mil_losses(
    z: np.ndarray, y: int, t: int, m: int, tau: float, eta: float
) -> Tuple[float, np.ndarray]:
    """Per-file loss and dL/dz for one sample.

    ``z`` are the B bucket logits.  For a malicious file (y = 1) the loss is
    sp(t + m - s(x)) with s(x) the smooth vote of (28): it pushes the *count*
    of malicious buckets past t + m, not any single logit.  For a benign file
    it is sp(s(x) - t + 1 + m) plus the bucket-level term weighted by eta.
    """
    s_terms = sigmoid(z / tau)
    s = float(s_terms.sum())
    ds_dz = s_terms * (1.0 - s_terms) / tau
    if y == 1:
        a = t + m - s
        loss = float(softplus(np.array(a)))
        grad = -sigmoid(np.array(a)) * ds_dz
    else:
        a = s - t + 1 + m
        loss = float(softplus(np.array(a)))
        grad = sigmoid(np.array(a)) * ds_dz
        bl = softplus(z)
        loss += float(eta / len(z) * bl.sum())
        grad = grad + (eta / len(z)) * sigmoid(z)
    return loss, grad


# --------------------------------------------------------------------------
# numpy backend
# --------------------------------------------------------------------------

class NumpyBaseClassifier:
    """Logistic model over the bucket readout, trained with ``mil_losses``."""

    kind = "numpy"

    def __init__(self, dim: int = READOUT_DIM, seed: int = 0):
        rng = np.random.default_rng(seed)
        self.w = rng.normal(0.0, 0.05, size=dim).astype(np.float64)
        self.b = 0.0
        self.dim = dim

    def logits(self, feats: np.ndarray) -> np.ndarray:
        return feats @ self.w + self.b

    def __call__(self, content: Counter, pcfg: PartitionConfig) -> float:
        if not content:
            return -1.0
        v = np.asarray(readout_vector(content, pcfg, self.dim))
        return float(v @ self.w + self.b)

    # -- persistence ----------------------------------------------------
    def state_dict(self) -> Dict[str, object]:
        return {"kind": self.kind, "dim": self.dim,
                "w": self.w.tolist(), "b": self.b}

    def save(self, path: str | Path) -> Path:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(self.state_dict()), encoding="utf-8")
        return p

    @classmethod
    def load(cls, path: str | Path) -> "NumpyBaseClassifier":
        obj = json.loads(Path(path).read_text(encoding="utf-8"))
        m = cls(dim=obj["dim"])
        m.w = np.asarray(obj["w"], dtype=np.float64)
        m.b = float(obj["b"])
        return m


def train_numpy(
    feats: Sequence[np.ndarray],
    labels: Sequence[int],
    pcfg: PartitionConfig,
    vcfg: VoteConfig,
    cfg: TrainConfig,
    on_epoch=None,
) -> NumpyBaseClassifier:
    model = NumpyBaseClassifier(cfg.dim, cfg.seed)
    m = cfg.margin(pcfg)
    rng = np.random.default_rng(cfg.seed)
    n = len(feats)
    idx = np.arange(n)
    n_pos = max(1, sum(labels))
    n_neg = max(1, n - n_pos)
    w1, w0 = n / (2 * n_pos), n / (2 * n_neg)   # offset class imbalance

    for epoch in range(cfg.epochs):
        tau = cfg.tau_at(epoch)
        rng.shuffle(idx)
        total = 0.0
        for start in range(0, n, cfg.batch_size):
            batch = idx[start:start + cfg.batch_size]
            gw = np.zeros_like(model.w)
            gb = 0.0
            for i in batch:
                X, y = feats[i], labels[i]
                z = model.logits(X)
                loss, dz = mil_losses(z, y, vcfg.t, m, tau, cfg.eta)
                cw = w1 if y == 1 else w0
                total += cw * loss
                gw += cw * (X.T @ dz)
                gb += cw * float(dz.sum())
            scale = cfg.lr / max(1, len(batch))
            model.w -= scale * (gw + cfg.weight_decay * model.w)
            model.b -= scale * gb
        if on_epoch is not None:
            on_epoch(epoch, tau, total / max(1, n))
    return model


# --------------------------------------------------------------------------
# torch backend
# --------------------------------------------------------------------------

if HAVE_TORCH:

    class TorchBaseClassifier(nn.Module):
        """The encoder of Section IV-D: an MLP over the bucket readout with the
        depth and hidden size selected in Table XIV.

        The readout already aggregates a bucket's canonical forms, so the
        message passing a GIN would do over a bucket's call graph is replaced
        here by a permutation-invariant sum followed by this encoder.  The
        certificate does not depend on the encoder's architecture -- Theorem 3
        is a statement about the vote -- so this is a faithful stand-in that
        keeps the artifact runnable without PyTorch Geometric.
        """

        kind = "torch"

        def __init__(self, dim: int = READOUT_DIM, hidden: int = 256,
                     layers: int = 3):
            super().__init__()
            mods: List[nn.Module] = []
            d = dim
            for _ in range(max(1, layers - 1)):
                mods += [nn.Linear(d, hidden), nn.BatchNorm1d(hidden), nn.ReLU()]
                d = hidden
            mods += [nn.Linear(d, 1)]
            self.net = nn.Sequential(*mods)
            self.dim = dim

        def forward(self, x):            # (N, dim) -> (N,)
            return self.net(x).squeeze(-1)

        @torch.no_grad()
        def bucket_logit(self, content: Counter, pcfg: PartitionConfig) -> float:
            """Score one bucket's content.

            Kept off ``__call__`` deliberately: overriding ``nn.Module``'s
            ``__call__`` breaks ordinary tensor forward passes, so the base
            classifier interface is a named method and ``vote.as_base_classifier``
            adapts it.
            """
            if not content:
                return -1.0
            was_training = self.training
            self.eval()
            v = torch.tensor([readout_vector(content, pcfg, self.dim)],
                             dtype=torch.float32)
            out = float(self.forward(v).item())
            if was_training:
                self.train()
            return out

    def train_torch(
        feats: Sequence[np.ndarray],
        labels: Sequence[int],
        pcfg: PartitionConfig,
        vcfg: VoteConfig,
        cfg: TrainConfig,
        on_epoch=None,
    ) -> "TorchBaseClassifier":
        torch.manual_seed(cfg.seed)
        model = TorchBaseClassifier(cfg.dim, cfg.hidden, cfg.layers)
        opt = torch.optim.Adam(model.parameters(), lr=cfg.lr,
                               weight_decay=cfg.weight_decay)
        X = torch.tensor(np.stack(feats), dtype=torch.float32)   # (N, B, dim)
        Y = torch.tensor(labels, dtype=torch.float32)
        m = cfg.margin(pcfg)
        n = len(labels)
        n_pos = max(1, int(Y.sum().item()))
        w1, w0 = n / (2 * n_pos), n / (2 * max(1, n - n_pos))
        g = torch.Generator().manual_seed(cfg.seed)

        for epoch in range(cfg.epochs):
            tau = cfg.tau_at(epoch)
            model.train()
            perm = torch.randperm(n, generator=g)
            total = 0.0
            for start in range(0, n, cfg.batch_size):
                sel = perm[start:start + cfg.batch_size]
                xb, yb = X[sel], Y[sel]
                bsz, B, dim = xb.shape
                z = model(xb.reshape(-1, dim)).reshape(bsz, B)
                s = torch.sigmoid(z / tau).sum(dim=1)
                l1 = torch.nn.functional.softplus(vcfg.t + m - s)
                l0 = torch.nn.functional.softplus(s - vcfg.t + 1 + m) \
                    + cfg.eta * torch.nn.functional.softplus(z).mean(dim=1)
                loss = (yb * w1 * l1 + (1 - yb) * w0 * l0).mean()
                opt.zero_grad()
                loss.backward()
                opt.step()
                total += float(loss.item()) * bsz
            if on_epoch is not None:
                on_epoch(epoch, tau, total / max(1, n))
        model.eval()
        return model


# --------------------------------------------------------------------------
# Backend-agnostic entry points
# --------------------------------------------------------------------------

def train(
    feats: Sequence[np.ndarray],
    labels: Sequence[int],
    pcfg: PartitionConfig,
    vcfg: VoteConfig,
    cfg: TrainConfig,
    on_epoch=None,
):
    backend = cfg.resolved_backend()
    if backend == "torch":
        if not HAVE_TORCH:
            raise RuntimeError("torch backend requested but torch is not installed")
        return train_torch(feats, labels, pcfg, vcfg, cfg, on_epoch)
    return train_numpy(feats, labels, pcfg, vcfg, cfg, on_epoch)


def save_checkpoint(model, path: str | Path, meta: Optional[Dict] = None) -> Path:
    """Write a checkpoint plus a sidecar describing how to reproduce it."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if getattr(model, "kind", "") == "torch":
        torch.save({"state_dict": model.state_dict(), "dim": model.dim,
                    "kind": "torch"}, p)
    else:
        model.save(p)
    if meta is not None:
        p.with_suffix(p.suffix + ".meta.json").write_text(
            json.dumps(meta, indent=2, sort_keys=True, default=str),
            encoding="utf-8")
    return p


def load_checkpoint(path: str | Path, cfg: Optional[TrainConfig] = None):
    p = Path(path)
    if p.suffix == ".pt":
        if not HAVE_TORCH:
            raise RuntimeError("a torch checkpoint needs torch installed")
        obj = torch.load(p, map_location="cpu", weights_only=False)
        c = cfg or TrainConfig()
        model = TorchBaseClassifier(obj.get("dim", READOUT_DIM), c.hidden, c.layers)
        model.load_state_dict(obj["state_dict"])
        model.eval()
        return model
    return NumpyBaseClassifier.load(p)
