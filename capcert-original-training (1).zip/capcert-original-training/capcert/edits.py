"""Atomic binary edits and their footprints (Section III-C, Corollary 1).

Each edit family of Corollary 1 is implemented as a transformation of a
``ProgramImage``, together with the bound Corollary 1 states for it.  The
measured footprint is then

    pi(a) = d( C(x), C(a(x)) )

computed over the canonical multisets, and ``footprint_report`` returns both
the measured value and the bound so that every call site can assert

    measured <= bound.

That assertion is EV2a and part of TV4.  It is the only place in the artifact
where a claimed guarantee meets a measurement, so it is checked on every edit
rather than sampled.
"""
from __future__ import annotations

import random
import struct
from collections import Counter
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Sequence, Set, Tuple

from .canonical import canonical_multiset, edit_distance
from .image import ProgramImage, build_image
from .ir import (
    COMMUTATIVE_OPS,
    Block,
    Function,
    Op,
    Varnode,
    const,
)
from .lfr import (
    RecoveryOptions,
    dependency_closure,
    enumerate_roots,
    owners,
    ownership,
    recover,
)
from .rewrite import API_ALIASES

#: Corollary 1 families, keyed by their letter in the manuscript.
FAMILIES: Dict[str, str] = {
    "a": "invariant rewrite",
    "b": "container edit",
    "c": "unreferenced insertion",
    "d": "insertion through a root table",
    "e": "live insertion",
    "f": "deletion",
    "g": "modification",
    "h": "root-table edit",
    "i": "code pointers in data",
}

#: T_inv: the transformation classes Theorem 1 cancels exactly.
T_INV = (
    "commutative-operand-swap",
    "dead-code-insertion",
    "constant-unfolding",
    "block-splitting",
    "api-alias-substitution",
)


# --------------------------------------------------------------------------
# Decoding an image back into editable functions
# --------------------------------------------------------------------------

def image_functions(image: ProgramImage) -> Dict[str, Function]:
    """Recover every stored record as a Function, by name."""
    from .lfr import _decode_record, _assemble
    from .image import Accessor

    out: Dict[str, Function] = {}
    for name, off in image.index.items():
        acc = Accessor(image, record=False)
        nm, items, _ = _decode_record(acc, off, RecoveryOptions())
        out[nm] = _assemble(nm, items)
    return out


def rebuild(
    functions: Dict[str, Function],
    roots: Sequence[Tuple[str, str]],
    overlay: bytes = b"",
) -> ProgramImage:
    order = sorted(functions)
    return build_image([functions[n] for n in order], list(roots), overlay)


def _overlay_bytes(image: ProgramImage) -> bytes:
    s, e = image.overlay
    return bytes(image.data[s:e])


# --------------------------------------------------------------------------
# T_inv transformations (used by edit family (a) and by EV1)
# --------------------------------------------------------------------------

def t_inv_commutative_swap(fn: Function, rng: random.Random) -> Function:
    g = fn.copy()
    sites = [(l, i) for l in g.order()
             for i, o in enumerate(g.blocks[l].ops)
             if o.opcode in COMMUTATIVE_OPS and len(o.ins) == 2]
    if not sites:
        return g
    l, i = rng.choice(sites)
    ops = list(g.blocks[l].ops)
    ops[i] = ops[i].with_ins(tuple(reversed(ops[i].ins)))
    g.blocks[l] = Block(l, ops)
    return g


def t_inv_dead_code(fn: Function, rng: random.Random) -> Function:
    g = fn.copy()
    l = rng.choice(g.order())
    ops = list(g.blocks[l].ops)
    junk = Op("INT_XOR",
              out=Varnode("unique", 9000 + rng.randrange(1000), 4),
              ins=(const(rng.randrange(1 << 16), 4), const(rng.randrange(1 << 16), 4)))
    pos = max(0, len(ops) - 1)
    ops.insert(pos, junk)
    g.blocks[l] = Block(l, ops)
    return g


def t_inv_constant_unfold(fn: Function, rng: random.Random) -> Function:
    """Replace a constant c by (c + d) - d, which R4 folds straight back."""
    g = fn.copy()
    sites = [(l, i, j) for l in g.order()
             for i, o in enumerate(g.blocks[l].ops)
             for j, v in enumerate(o.ins)
             if v.is_const and o.opcode in COMMUTATIVE_OPS]
    if not sites:
        return g
    l, i, j = rng.choice(sites)
    ops = list(g.blocks[l].ops)
    op = ops[i]
    v = op.ins[j]
    d = rng.randrange(1, 1 << 12)
    # two distinct temporaries: each is single-definition, which is the
    # precondition R4's constant propagation requires
    base = 8000 + rng.randrange(1000) * 2
    tmp1 = Varnode("unique", base, v.size)
    tmp2 = Varnode("unique", base + 1, v.size)
    pre = Op("INT_ADD", out=tmp1, ins=(const(v.offset + d, v.size), const(0, v.size)))
    sub = Op("INT_SUB", out=tmp2, ins=(tmp1, const(d, v.size)))
    ops[i] = op.with_ins([tmp2 if jj == j else vv for jj, vv in enumerate(op.ins)])
    ops[i:i] = [pre, sub]
    g.blocks[l] = Block(l, ops)
    return g


def t_inv_block_split(fn: Function, rng: random.Random) -> Function:
    """Split a block in two, joined by an unconditional BRANCH (R1 undoes it)."""
    g = fn.copy()
    cands = [l for l in g.order() if len(g.blocks[l].ops) >= 2]
    if not cands:
        return g
    l = rng.choice(cands)
    ops = list(g.blocks[l].ops)
    cut = rng.randrange(1, len(ops))
    new_lbl = f"{l}__split{rng.randrange(1 << 20)}"
    g.blocks[l] = Block(l, ops[:cut] + [Op("BRANCH", target=new_lbl)])
    g.blocks[new_lbl] = Block(new_lbl, ops[cut:])
    return g


def t_inv_api_alias(fn: Function, rng: random.Random) -> Function:
    """Swap a canonical API family back to a concrete alias (R6 re-folds it)."""
    g = fn.copy()
    inverse: Dict[str, List[str]] = {}
    for alias, fam in API_ALIASES.items():
        inverse.setdefault(fam, []).append(alias)
    sites = [(l, i) for l in g.order()
             for i, o in enumerate(g.blocks[l].ops)
             if o.opcode == "CALL" and o.target in inverse]
    if not sites:
        return g
    l, i = rng.choice(sites)
    ops = list(g.blocks[l].ops)
    fam = ops[i].target
    ops[i] = Op("CALL", out=ops[i].out, ins=ops[i].ins,
                target=rng.choice(sorted(inverse[fam])))
    g.blocks[l] = Block(l, ops)
    return g


T_INV_OPS: Dict[str, Callable[[Function, random.Random], Function]] = {
    "commutative-operand-swap": t_inv_commutative_swap,
    "dead-code-insertion": t_inv_dead_code,
    "constant-unfolding": t_inv_constant_unfold,
    "block-splitting": t_inv_block_split,
    "api-alias-substitution": t_inv_api_alias,
}

#: Out-of-class obfuscations: Theorem 1 says nothing about these, and EV1
#: measures how many functions they move (Table XX).
OUT_OF_CLASS = ("opaque-predicate-chain", "bogus-control-flow", "control-flow-flattening")


def out_of_class(name: str, fn: Function, rng: random.Random) -> Function:
    g = fn.copy()
    if name == "opaque-predicate-chain":
        l = rng.choice(g.order())
        dead = f"{l}__opaque{rng.randrange(1 << 20)}"
        v = Varnode("unique", 7000 + rng.randrange(500), 4)
        ops = list(g.blocks[l].ops)
        guard = [
            Op("INT_MULT", out=v, ins=(Varnode("register", 0, 4), Varnode("register", 0, 4))),
            Op("CBRANCH", ins=(v,), targets=(dead, l)),
        ]
        g.blocks[dead] = Block(dead, [Op("RETURN", ins=())])
        g.blocks[l] = Block(l, guard + ops)
        return g
    if name == "bogus-control-flow":
        for _ in range(2):
            lbl = f"bogus{rng.randrange(1 << 20)}"
            g.blocks[lbl] = Block(lbl, [
                Op("INT_ADD", out=Varnode("unique", 6000 + rng.randrange(500), 4),
                   ins=(Varnode("register", 4, 4), const(rng.randrange(1 << 8), 4))),
                Op("RETURN", ins=()),
            ])
        l = rng.choice([x for x in g.order() if not x.startswith("bogus")])
        ops = list(g.blocks[l].ops)
        tgt = next(x for x in g.blocks if x.startswith("bogus"))
        ops.insert(0, Op("CBRANCH", ins=(Varnode("register", 8, 4),), targets=(tgt, l)))
        g.blocks[l] = Block(l, ops)
        return g
    if name == "control-flow-flattening":
        order = [l for l in g.order()]
        if len(order) < 2:
            return g
        disp = f"disp{rng.randrange(1 << 20)}"
        state = Varnode("stack", 4096, 4)
        g.blocks[disp] = Block(disp, [
            Op("BRANCHIND", ins=(state,), targets=tuple(order)),
        ])
        for idx, l in enumerate(order):
            ops = [o for o in g.blocks[l].ops if o.opcode not in ("BRANCH",)]
            ops.append(Op("COPY", out=state, ins=(const(idx + 1, 4),)))
            ops.append(Op("BRANCH", target=disp))
            g.blocks[l] = Block(l, ops)
        g.entry = disp
        return g
    raise KeyError(name)


# --------------------------------------------------------------------------
# Atomic edits
# --------------------------------------------------------------------------

@dataclass
class EditResult:
    family: str
    description: str
    image: ProgramImage
    #: bytes of x that the edit changed or removed -- W(a) of Section IV-A
    W: Set[int]
    added_roots: Tuple[str, ...]
    removed_roots: Tuple[str, ...]


def _new_leaf(name: str, value: int) -> Function:
    """A function returning a distinct constant.

    This is the Corollary 1(d) construction, and the variant supply of
    Assumption G: the constant is live-out, so canonicalization keeps it and
    the canonical forms of distinct values are distinct.
    """
    out = Varnode("register", 0, 4)
    return Function(
        name=name, entry="b0",
        blocks={"b0": Block("b0", [
            Op("COPY", out=out, ins=(const(value, 4),)),
            Op("RETURN", ins=()),
        ])},
        live_out=(out,),
    )


def edit_invariant_rewrite(image: ProgramImage, rng: random.Random,
                           which: Optional[str] = None) -> EditResult:
    """(a) transform owners by a member of T_inv.  Bound: pi = 0."""
    fns = image_functions(image)
    name = rng.choice(sorted(fns))
    which = which or rng.choice(T_INV)
    fns[name] = T_INV_OPS[which](fns[name], rng)
    img = rebuild(fns, image.roots, _overlay_bytes(image))
    return EditResult("a", f"T_inv:{which} on {name}", img, set(), (), ())


def edit_container(image: ProgramImage, rng: random.Random) -> EditResult:
    """(b) pad the overlay region, which no view reads.  Bound: pi = 0."""
    fns = image_functions(image)
    pad = bytes(rng.randrange(256) for _ in range(rng.randrange(16, 256)))
    img = rebuild(fns, image.roots, _overlay_bytes(image) + pad)
    return EditResult("b", f"overlay padding +{len(pad)}B", img, set(), (), ())


def edit_unreferenced_insertion(image: ProgramImage, rng: random.Random) -> EditResult:
    """(c) insert code no root table, direct call or constant reaches.  pi = 0."""
    fns = image_functions(image)
    nm = f"unref_{rng.randrange(1 << 30):08x}"
    fns[nm] = _new_leaf(nm, rng.randrange(1 << 24))
    img = rebuild(fns, image.roots, _overlay_bytes(image))
    return EditResult("c", f"unreferenced function {nm}", img, set(), (), ())


def edit_root_table_insertion(image: ProgramImage, rng: random.Random) -> EditResult:
    """(d) a new function reached only through a new export.  pi = |R+| = 1."""
    fns = image_functions(image)
    nm = f"export_{rng.randrange(1 << 30):08x}"
    fns[nm] = _new_leaf(nm, rng.randrange(1 << 24))
    roots = list(image.roots) + [("export", nm)]
    img = rebuild(fns, roots, _overlay_bytes(image))
    return EditResult("d", f"new export {nm}", img, set(), (nm,), ())


def edit_live_insertion(image: ProgramImage, rng: random.Random) -> EditResult:
    """(e) a new function reached through a new call site in existing code."""
    fns = image_functions(image)
    host = rng.choice(sorted(fns))
    nm = f"live_{rng.randrange(1 << 30):08x}"
    fns[nm] = _new_leaf(nm, rng.randrange(1 << 24))
    g = fns[host].copy()
    l = g.entry
    ops = list(g.blocks[l].ops)
    ops.insert(max(0, len(ops) - 1), Op("CALL", ins=(), target=nm))
    g.blocks[l] = Block(l, ops)
    fns[host] = g
    W = set(dependency_closure(image, host)) if host in image.root_names() else set()
    if not W:
        ext = image.index.get(host)
        if ext is not None:
            total = struct.unpack("<I", image.data[ext:ext + 4])[0]
            W = set(range(ext + 4, ext + total))
    img = rebuild(fns, image.roots, _overlay_bytes(image))
    return EditResult("e", f"live call to {nm} from {host}", img, W, (nm,), ())


def edit_deletion(image: ProgramImage, rng: random.Random) -> EditResult:
    """(f) remove a function together with its call sites."""
    fns = image_functions(image)
    roots = set(image.root_names())
    cands = [n for n in sorted(fns) if n not in roots]
    if not cands:
        return edit_container(image, rng)
    victim = rng.choice(cands)
    W: Set[int] = set()
    for nm, fn in list(fns.items()):
        if nm == victim:
            continue
        if any(o.opcode == "CALL" and o.target == victim for o in fn.all_ops()):
            ext = image.index.get(nm)
            if ext is not None:
                total = struct.unpack("<I", image.data[ext:ext + 4])[0]
                W |= set(range(ext + 4, ext + total))
            g = fn.copy()
            for l in list(g.blocks):
                g.blocks[l] = Block(l, [o for o in g.blocks[l].ops
                                        if not (o.opcode == "CALL" and o.target == victim)])
            fns[nm] = g
    del fns[victim]
    img = rebuild(fns, image.roots, _overlay_bytes(image))
    return EditResult("f", f"delete {victim}", img, W, (), ())


def edit_modification(image: ProgramImage, rng: random.Random) -> EditResult:
    """(g) a change outside T_inv in existing code."""
    fns = image_functions(image)
    name = rng.choice(sorted(fns))
    g = fns[name].copy()
    l = rng.choice(g.order())
    ops = list(g.blocks[l].ops)
    ops.insert(0, Op("STORE", ins=(Varnode("ram", rng.randrange(1 << 20), 4),
                                   const(rng.randrange(1 << 16), 4))))
    g.blocks[l] = Block(l, ops)
    fns[name] = g
    ext = image.index.get(name)
    total = struct.unpack("<I", image.data[ext:ext + 4])[0]
    W = set(range(ext + 4, ext + total))
    img = rebuild(fns, image.roots, _overlay_bytes(image))
    return EditResult("g", f"non-invariant modification of {name}", img, W, (), ())


def edit_root_table_edit(image: ProgramImage, rng: random.Random) -> EditResult:
    """(h) remove an export from the root table, leaving its code in place."""
    exports = [(k, n) for k, n in image.roots if k == "export"]
    if not exports:
        return edit_root_table_insertion(image, rng)
    victim = rng.choice(exports)
    roots = [r for r in image.roots if r != victim]
    fns = image_functions(image)
    img = rebuild(fns, roots, _overlay_bytes(image))
    return EditResult("h", f"drop export {victim[1]}", img, set(), (), (victim[1],))


def edit_data_pointer(image: ProgramImage, rng: random.Random) -> EditResult:
    """(i) edit code pointers held in data.  pi = 0 for LFR, by construction.

    The cost of this family is not footprint but coverage: Example 4.  LFR does
    not follow such pointers, so the function they reach is outside Gamma(x)
    altogether -- see ``experiments/ev2_recovery.py``.
    """
    fns = image_functions(image)
    ov = bytearray(_overlay_bytes(image))
    if len(ov) < 8:
        ov += bytes(8 - len(ov))
    pos = rng.randrange(0, max(1, len(ov) - 4))
    ov[pos:pos + 4] = struct.pack("<I", rng.randrange(1 << 31))
    img = rebuild(fns, image.roots, bytes(ov))
    return EditResult("i", f"rewrite data pointer at overlay+{pos}", img, set(), (), ())


EDIT_FAMILIES: Dict[str, Callable[[ProgramImage, random.Random], EditResult]] = {
    "a": edit_invariant_rewrite,
    "b": edit_container,
    "c": edit_unreferenced_insertion,
    "d": edit_root_table_insertion,
    "e": edit_live_insertion,
    "f": edit_deletion,
    "g": edit_modification,
    "h": edit_root_table_edit,
    "i": edit_data_pointer,
}


# --------------------------------------------------------------------------
# Footprints
# --------------------------------------------------------------------------

def canonical_of_image(image: ProgramImage,
                       opts: Optional[RecoveryOptions] = None) -> Counter:
    """C(x) for an image."""
    return canonical_multiset([r.function for r in recover(image, opts)])


def corollary1_bound(image: ProgramImage, res: EditResult,
                     opts: Optional[RecoveryOptions] = None) -> Optional[int]:
    """The bound Corollary 1 states for this edit family.

    ``None`` means the family carries no closed-form bound in this
    configuration and only Lemma 1's general inequality applies.
    """
    fam = res.family
    if fam in ("a", "b", "c", "i"):
        return 0
    omega = ownership(image, opts)
    sum_omega = sum(omega.get(v, 0) for v in res.W)
    Rplus, Rminus = len(res.added_roots), len(res.removed_roots)
    if fam == "d":
        return Rplus
    if fam == "e":
        return Rplus + 2 * sum_omega
    if fam == "f":
        return Rminus + 2 * sum_omega
    if fam == "g":
        return Rplus + Rminus + 2 * sum_omega
    if fam == "h":
        return Rplus + Rminus
    return None


@dataclass
class FootprintReport:
    family: str
    description: str
    measured: int
    bound: Optional[int]
    within_bound: bool
    n_roots_before: int
    n_roots_after: int


def footprint_report(
    image: ProgramImage, res: EditResult, opts: Optional[RecoveryOptions] = None
) -> FootprintReport:
    cx = canonical_of_image(image, opts)
    cy = canonical_of_image(res.image, opts)
    measured = edit_distance(cx, cy)
    bound = corollary1_bound(image, res, opts)
    return FootprintReport(
        family=res.family,
        description=res.description,
        measured=measured,
        bound=bound,
        within_bound=(bound is None) or (measured <= bound),
        n_roots_before=len(image.roots),
        n_roots_after=len(res.image.roots),
    )


def apply_sequence(
    image: ProgramImage,
    families: Sequence[str],
    rng: random.Random,
    opts: Optional[RecoveryOptions] = None,
) -> Tuple[ProgramImage, List[FootprintReport]]:
    """Apply edits one at a time, charging each against the *intermediate*
    binary, which is the convention equation (27) uses.

    This is the accounting point the manuscript's "Accounting for interacting
    edits" remark makes: footprints are evaluated against x_{i-1}, never
    against x_0, and the dependency sets are recomputed between edits.
    """
    cur = image
    reports: List[FootprintReport] = []
    for fam in families:
        res = EDIT_FAMILIES[fam](cur, rng)
        reports.append(footprint_report(cur, res, opts))
        cur = res.image
    return cur, reports
