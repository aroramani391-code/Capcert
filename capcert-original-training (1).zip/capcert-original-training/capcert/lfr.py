"""Stage 1: Local Function Recovery (Section IV-A).

LFR recovers one function per root by recursive descent from that root, reading
only bytes it declares as dependencies.  It deliberately does *not* follow code
pointers held in data: that is the coverage cost of Section VII-E, and it is
what keeps Property L0 true.

Two independent computations of the dependency set are provided:

  ``recover_root``        builds the view through the recording accessor; the
                          recorded content set is Dep_x(e) as the running code
                          sees it;
  ``dependency_closure``  computes Dep_x(e) structurally, without the accessor.

The L0 audit compares them.  Two implementations that must agree is what makes
the audit able to fail; an audit that simply reported what the accessor
recorded would pass vacuously, which is the point ``l0_fault_injection`` makes.

A Rust implementation with the same contract lives in ``rust/lfr``; this module
is the reference the artifact runs by default so that the whole pipeline works
without a toolchain.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Set, Tuple

from .image import (
    MAGIC,
    OPCODES,
    ROOT_KINDS,
    Accessor,
    L0Violation,
    ProgramImage,
)
from .ir import Block, Function, Op, SPACES, Varnode


@dataclass
class RecoveryOptions:
    #: follow code pointers held in data.  False is LFR (the default and the
    #: configuration every certificate in the manuscript is computed under);
    #: True is the LFR+D variant of Table XXI, which gains recall and loses
    #: the locality bound.
    follow_data_pointers: bool = False
    #: deliberately read one jump-table entry past the bound without recording
    #: it.  This reproduces the defect of Section VII-J for the fault-injection
    #: test; it must never be enabled outside that test.
    inject_jumptable_off_by_one: bool = False
    max_functions_per_root: int = 256


@dataclass
class RecoveredRoot:
    root: str
    kind: str
    function: Function
    reached: Tuple[str, ...]          # local functions reached from this root
    dep_content: Set[int] = field(default_factory=set)
    dep_locator: Set[int] = field(default_factory=set)


# --------------------------------------------------------------------------
# Root enumeration (Phase A)
# --------------------------------------------------------------------------

def enumerate_roots(image: ProgramImage) -> List[Tuple[str, str]]:
    """R(x): the root set, read from the root table.

    This is a separate phase on purpose.  Dep_x(e) covers the construction of
    *e's view* and not the enumeration of the other roots, which is what makes
    Corollary 1(h) true: editing an unrelated root-table entry adds or removes
    roots without changing any surviving view.
    """
    off = image.roots_offset
    n = struct.unpack("<H", image.data[off:off + 2])[0]
    off += 2
    out: List[Tuple[str, str]] = []
    for _ in range(n):
        kind = ROOT_KINDS[image.data[off]]
        off += 1
        ln = image.data[off]
        off += 1
        name = bytes(image.data[off:off + ln]).decode("utf-8")
        off += ln
        out.append((kind, name))
    return out


def _resolve(acc: Accessor, name: str) -> Optional[int]:
    """Look a function name up in the index.

    The offset is read with role ``locator``: it says *where* the record is and
    is never used as a value, so relocating the record cannot change the view.
    """
    off = acc.image.index_offset
    n = acc.u16(off, "locator")
    off += 2
    for _ in range(n):
        nm, off = acc.string(off, "locator")
        val = acc.u32(off, "locator")
        off += 4
        if nm == name:
            return val
    return None


# --------------------------------------------------------------------------
# Decoding one function record
# --------------------------------------------------------------------------

def _dec_vn(acc: Accessor, off: int) -> Tuple[Varnode, int]:
    space, offset, size = struct.unpack("<BIB", acc.read(off, 6))
    return Varnode(SPACES[space], offset, size), off + 6


def _decode_record(
    acc: Accessor, base: int, opts: RecoveryOptions
) -> Tuple[str, List[Tuple[Optional[str], Op]], List[str]]:
    """Decode one record into (name, [(block_label|None, op)], call targets)."""
    total = acc.u32(base, "locator")
    off = base + 4
    name, off = acc.string(off)
    n_ops = acc.u16(off)
    off += 2
    items: List[Tuple[Optional[str], Op]] = []
    calls: List[str] = []
    cur_label: Optional[str] = None
    for _ in range(n_ops):
        opcode = OPCODES[acc.u8(off)]
        off += 1
        flags = acc.u8(off)
        off += 1
        out_vn = None
        if flags & 1:
            out_vn, off = _dec_vn(acc, off)
        n_ins = acc.u8(off)
        off += 1
        ins = []
        for _ in range(n_ins):
            v, off = _dec_vn(acc, off)
            ins.append(v)
        target, off = acc.string(off)
        n_succ = acc.u8(off)
        off += 1
        succs = []
        for _ in range(n_succ):
            s, off = acc.string(off)
            succs.append(s)
        jt_off, jt_bytes, n_jt = struct.unpack("<IHB", acc.read(off, 7, "locator"))
        off += 7
        jt: List[str] = []
        if opcode == "BRANCHIND" and n_jt:
            # The jump-table length rule: read exactly n_jt entries, and never
            # step outside the declared extent [jt_off, jt_off + jt_bytes).
            cur = jt_off
            limit = jt_off + jt_bytes
            for _ in range(n_jt):
                if cur >= limit:
                    break
                ln = acc.u8(cur)
                if cur + 1 + ln > limit:
                    break
                jt.append(acc.read(cur + 1, ln).decode("utf-8", "replace"))
                cur += 1 + ln
        if opts.inject_jumptable_off_by_one and opcode == "BRANCHIND" and n_jt:
            # The defect of Section VII-J: read one jump-table entry past the
            # bound, *use* it (it becomes a successor, so the canonical form
            # depends on it), and fail to record it in Dep.  A set comparison
            # cannot see this -- the read was never recorded -- which is why
            # the detector is the differential test: kappa now depends on a
            # byte outside Dep_x(e), so mutating that byte moves kappa.
            saved = acc.record
            acc.record = False
            try:
                past = jt_off + jt_bytes          # one entry past the bound
                ln = min(acc.u8(past), 16)
                extra = acc.read(past + 1, ln).decode("utf-8", "replace")
                if extra:
                    jt.append(extra)
            except (L0Violation, UnicodeDecodeError, IndexError):
                pass
            finally:
                acc.record = saved

        if opcode == "BRANCH" and target.startswith("#block:"):
            cur_label = target[len("#block:"):]
            continue
        op = Op(opcode, out=out_vn, ins=tuple(ins),
                target=(target or None), targets=tuple(succs or jt))
        items.append((cur_label, op))
        if opcode == "CALL" and target:
            calls.append(target)
    return name, items, calls


def _prefix_labels(op: Op, prefix: str) -> Op:
    """Rewrite intra-function branch targets to match the prefixed block labels.

    When a callee is inlined into a root's view its blocks are renamed, so its
    own BRANCH and CBRANCH targets have to be renamed with them.  Leaving them
    unprefixed makes the successor edges dangle, which silently stops R1 from
    merging inside an inlined callee and shows up as an invariant rewrite with
    a non-zero footprint.  CALL targets are function names and are left alone.
    """
    if not prefix or op.opcode not in ("BRANCH", "CBRANCH", "BRANCHIND"):
        return op
    return Op(
        op.opcode,
        out=op.out,
        ins=op.ins,
        target=(prefix + op.target) if op.target else None,
        targets=tuple(prefix + t for t in op.targets),
    )


def _assemble(name: str, items: Sequence[Tuple[Optional[str], Op]]) -> Function:
    blocks: Dict[str, Block] = {}
    order: List[str] = []
    for lbl, op in items:
        key = lbl or "b0"
        if key not in blocks:
            blocks[key] = Block(key, [])
            order.append(key)
        blocks[key].ops.append(op)
    if not order:
        blocks["b0"] = Block("b0", [])
        order.append("b0")
    live_out = tuple(sorted(
        {op.out for _, op in items
         if op.out is not None and op.out.space in ("register", "stack")},
        key=lambda v: v.structural_key()))
    return Function(name=name, entry=order[0], blocks=blocks, live_out=live_out)


# --------------------------------------------------------------------------
# Recovery (Phase B)
# --------------------------------------------------------------------------

def recover_root(
    image: ProgramImage,
    root: str,
    kind: str = "entry",
    opts: Optional[RecoveryOptions] = None,
    accessor: Optional[Accessor] = None,
) -> RecoveredRoot:
    """Build View_x(e) for one root and return it with its dependency sets."""
    opts = opts or RecoveryOptions()
    acc = accessor or Accessor(image)
    acc.read(0, len(MAGIC), "locator")

    seen: List[str] = []
    items: List[Tuple[Optional[str], Op]] = []
    work = [root]
    while work and len(seen) < opts.max_functions_per_root:
        nm = work.pop(0)
        if nm in seen:
            continue
        off = _resolve(acc, nm)
        if off is None:
            continue
        seen.append(nm)
        _, these, calls = _decode_record(acc, off, opts)
        prefix = f"{nm}:" if nm != root else ""
        for lbl, op in these:
            items.append(((prefix + lbl) if lbl else None, _prefix_labels(op, prefix)))
        for c in calls:
            if c in image.index and c not in seen:
                work.append(c)

    fn = _assemble(root, items)
    return RecoveredRoot(
        root=root, kind=kind, function=fn, reached=tuple(seen),
        dep_content=set(acc.content), dep_locator=set(acc.locator),
    )


def recover(
    image: ProgramImage, opts: Optional[RecoveryOptions] = None
) -> List[RecoveredRoot]:
    """Gamma(x): one recovered function per root."""
    opts = opts or RecoveryOptions()
    return [recover_root(image, name, kind, opts)
            for kind, name in enumerate_roots(image)]


# --------------------------------------------------------------------------
# Independent dependency closure, for the audit
# --------------------------------------------------------------------------

def _record_extent(image: ProgramImage, name: str) -> Optional[Tuple[int, int]]:
    off = image.index.get(name)
    if off is None:
        return None
    total = struct.unpack("<I", image.data[off:off + 4])[0]
    return (off, off + total)


def _record_layout(
    image: ProgramImage, base: int, opts: RecoveryOptions
) -> Tuple[List[Tuple[int, int]], List[Tuple[int, int]]]:
    """Split a record into its locator ranges and its jump-table extents.

    Derived from the record layout rather than from what the recovery read, so
    that the closure and the accessor stay two independent computations.  The
    content of a record is everything in it except the length prefix and the
    per-op jump-table descriptors, both of which only say *where* something is.
    """
    acc = Accessor(image, record=False)
    clean = RecoveryOptions(follow_data_pointers=opts.follow_data_pointers,
                            inject_jumptable_off_by_one=False,
                            max_functions_per_root=opts.max_functions_per_root)
    jt_extents: List[Tuple[int, int]] = []
    locators: List[Tuple[int, int]] = [(base, base + 4)]
    total = acc.u32(base)
    off = base + 4
    _, off = acc.string(off)
    n_ops = acc.u16(off)
    off += 2
    from .image import OPCODES as _OPC

    for _ in range(n_ops):
        opcode = _OPC[acc.u8(off)]
        off += 1
        flags = acc.u8(off)
        off += 1
        if flags & 1:
            off += 6
        n_ins = acc.u8(off)
        off += 1
        off += 6 * n_ins
        _, off = acc.string(off)
        n_succ = acc.u8(off)
        off += 1
        for _ in range(n_succ):
            _, off = acc.string(off)
        jt_off, jt_bytes, n_jt = struct.unpack("<IHB", acc.read(off, 7))
        locators.append((off, off + 7))
        off += 7
        if opcode == "BRANCHIND" and n_jt and jt_bytes:
            jt_extents.append((jt_off, jt_bytes))
    return locators, jt_extents


def dependency_closure(
    image: ProgramImage, root: str, opts: Optional[RecoveryOptions] = None
) -> Set[int]:
    """Dep_x(e), computed structurally rather than by observing reads.

    Walks the same recursive-descent closure as ``recover_root`` but derives
    the byte ranges from the record layout, so a discrepancy between this set
    and what the accessor recorded is a real disagreement between two
    implementations and not a tautology.
    """
    opts = opts or RecoveryOptions()
    out: Set[int] = set()
    seen: Set[str] = set()
    work = [root]
    while work and len(seen) < opts.max_functions_per_root:
        nm = work.pop(0)
        if nm in seen or nm not in image.index:
            continue
        seen.add(nm)
        ext = _record_extent(image, nm)
        if ext is None:
            continue
        start, end = ext
        locators, jt_extents = _record_layout(image, start, opts)
        content = set(range(start, end))
        for lo, hi in locators:          # length prefix, jump-table descriptors
            content -= set(range(lo, hi))
        for jt_off, jt_bytes in jt_extents:
            content |= set(range(jt_off, jt_off + jt_bytes))
        out |= content
        acc = Accessor(image, record=False)
        _, _, calls = _decode_record(acc, start, opts)
        for c in calls:
            if c in image.index and c not in seen:
                work.append(c)
    return out


def ownership(
    image: ProgramImage, opts: Optional[RecoveryOptions] = None
) -> Dict[int, int]:
    """omega_x(v): how many roots depend on each byte (equation 12).

    Bytes in a tail-called or shared routine have omega > 1, which is the
    Example 1 situation in which one byte edit costs several canonical
    functions.
    """
    counts: Dict[int, int] = {}
    for kind, name in enumerate_roots(image):
        for v in dependency_closure(image, name, opts):
            counts[v] = counts.get(v, 0) + 1
    return counts


def owners(
    image: ProgramImage, byte_set: Sequence[int], opts: Optional[RecoveryOptions] = None
) -> Set[str]:
    """Own_x(W): the roots whose dependency set meets W."""
    W = set(byte_set)
    out: Set[str] = set()
    for kind, name in enumerate_roots(image):
        if dependency_closure(image, name, opts) & W:
            out.add(name)
    return out
