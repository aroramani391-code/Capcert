"""Stage 2: the canonicalization map kappa and the canonical-function digest.

kappa(f) is the normal form of f under R1-R6, re-labelled so that nothing in
the digest depends on an address, a name, or an order the recovery happened to
produce.  That last property is what makes Theorem 1 hold: two functions that
differ only by a transformation in T_inv reach the same normal form and
therefore the same digest.
"""
from __future__ import annotations

import hashlib
from typing import Dict, List, Tuple

from .ir import Function, Op, Varnode, Block
from .rewrite import normalize


def _relabel(fn: Function) -> Function:
    """Alpha-rename blocks and uniques into position-determined names.

    Block labels become b0, b1, ... in reverse-postorder from the entry, and
    unique varnodes are numbered in order of first definition.  Registers,
    stack slots and ram references keep their offsets, since those carry
    meaning the classifier should see.
    """
    order = fn.order()
    block_map = {lbl: f"b{i}" for i, lbl in enumerate(order)}

    uniq_map: Dict[Tuple[int, int], int] = {}

    def remap(v: Varnode) -> Varnode:
        if v.space != "unique":
            return v
        key = (v.offset, v.size)
        if key not in uniq_map:
            uniq_map[key] = len(uniq_map)
        return Varnode("unique", uniq_map[key], v.size)

    # first pass fixes the numbering in definition order
    for lbl in order:
        for op in fn.blocks[lbl].ops:
            if op.out is not None:
                remap(op.out)
            for v in op.ins:
                remap(v)

    blocks: Dict[str, Block] = {}
    for lbl in order:
        ops: List[Op] = []
        for op in fn.blocks[lbl].ops:
            ops.append(
                Op(
                    op.opcode,
                    out=remap(op.out) if op.out is not None else None,
                    ins=tuple(remap(v) for v in op.ins),
                    target=(block_map.get(op.target, op.target)
                            if op.opcode in ("BRANCH",) else op.target),
                    targets=tuple(block_map.get(t, t) for t in op.targets),
                )
            )
        blocks[block_map[lbl]] = Block(block_map[lbl], ops)

    return Function(
        name="",  # the name is never part of the canonical form
        entry=block_map[fn.entry],
        blocks=blocks,
        live_out=tuple(sorted((remap(v) for v in fn.live_out),
                              key=lambda v: v.structural_key())),
    )


def kappa(fn: Function) -> Function:
    """The canonical form of a recovered function."""
    nf, _ = normalize(fn)
    return _relabel(nf)


def canonical_text(fn: Function) -> str:
    return kappa(fn).to_text()


def digest(fn: Function) -> str:
    """SHA-256 of the canonical text.  This is the element of C(x)."""
    return hashlib.sha256(canonical_text(fn).encode("utf-8")).hexdigest()


def digest_of_canonical(canon: Function) -> str:
    """Digest of an already-canonical function (skips re-normalising)."""
    return hashlib.sha256(canon.to_text().encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------
# C(x): the canonical multiset of a program
# --------------------------------------------------------------------------

from collections import Counter  # noqa: E402


def canonical_multiset(functions: List[Function]) -> Counter:
    """C(x) of equation (1), as a multiset of digests.

    Multiplicity is kept here and everywhere downstream, which is convention
    C3: two identical canonical functions count twice.
    """
    return Counter(digest(f) for f in functions)


def edit_distance(cx: Counter, cy: Counter) -> int:
    """d(x, x') of equation (2): size of the multiset symmetric difference.

    Computed over the multiset, not the set of distinct digests.  Inserting or
    deleting a canonical function costs one; altering one costs two.
    """
    return sum(((cx - cy) + (cy - cx)).values())
