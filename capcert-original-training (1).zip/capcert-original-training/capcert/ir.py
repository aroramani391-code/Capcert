"""A small P-code-like intermediate representation.

This is the representation the canonicalization rules R1-R6 of Section IV-B
operate on.  It is deliberately a faithful *subset* of Ghidra P-code: enough
opcodes, varnode spaces and control flow to make the rewrite system, its
termination measure and its critical pairs real objects that can be checked,
without pulling the whole decompiler into the artifact.

Semantics are fixed-width two's-complement bit-vector semantics, which is what
makes the TV3 obligations in ``verification/tv3_smt.py`` discharge against Z3
on the same definitions used here.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, replace
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

# --------------------------------------------------------------------------
# Varnodes
# --------------------------------------------------------------------------

#: Address spaces, ordered.  The order is part of the canonical operand order
#: used by R5 and is the "fixed tie-break on storage class" of Section VII-J.
SPACES: Tuple[str, ...] = ("const", "register", "unique", "ram", "stack")
SPACE_RANK = {s: i for i, s in enumerate(SPACES)}


@dataclass(frozen=True, order=False)
class Varnode:
    space: str
    offset: int
    size: int  # in bytes

    def __post_init__(self) -> None:
        if self.space not in SPACE_RANK:
            raise ValueError(f"unknown space {self.space!r}")
        if self.size not in (1, 2, 4, 8):
            raise ValueError(f"unsupported size {self.size}")

    @property
    def bits(self) -> int:
        return self.size * 8

    @property
    def is_const(self) -> bool:
        return self.space == "const"

    def structural_key(self) -> Tuple[int, int, int]:
        """Total order on varnodes by structure alone.

        Section VII-J records that comparing by *value name* made R5 loop, and
        that comparing by structure with a fixed tie-break on storage class
        made the order ground-total.  That is this function: space rank first,
        then width, then offset.  No name is consulted.
        """
        return (SPACE_RANK[self.space], self.size, self.offset)

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        if self.is_const:
            return f"{self.offset}:{self.size}"
        return f"{self.space}[{self.offset}]:{self.size}"


def const(value: int, size: int) -> Varnode:
    return Varnode("const", value & ((1 << (size * 8)) - 1), size)


# --------------------------------------------------------------------------
# Opcodes
# --------------------------------------------------------------------------

#: Pure arithmetic/logic opcodes: no memory effect, no fault, result is a
#: function of the inputs alone.  These are the candidates for R3 and R4.
PURE_OPS: Tuple[str, ...] = (
    "COPY",
    "INT_ADD", "INT_SUB", "INT_MULT",
    "INT_AND", "INT_OR", "INT_XOR",
    "INT_LEFT", "INT_RIGHT", "INT_SRIGHT",
    "INT_NEGATE", "INT_2COMP",
    "INT_EQUAL", "INT_NOTEQUAL", "INT_LESS", "INT_SLESS",
    "INT_CARRY", "INT_SCARRY", "INT_SBORROW",
    "BOOL_AND", "BOOL_OR", "BOOL_XOR", "BOOL_NEGATE",
)

#: Foldable arithmetic opcodes.  COPY is excluded on purpose: folding rewrites
#: an op in this set into a COPY, so |foldable ops| strictly decreases with
#: every R4 application regardless of constant propagation (see rewrite.mu).
FOLDABLE_OPS: Tuple[str, ...] = tuple(o for o in PURE_OPS if o != "COPY")

#: Commutative opcodes, normalised by R5.
COMMUTATIVE_OPS: Tuple[str, ...] = (
    "INT_ADD", "INT_MULT", "INT_AND", "INT_OR", "INT_XOR",
    "INT_EQUAL", "INT_NOTEQUAL", "INT_CARRY", "INT_SCARRY",
    "BOOL_AND", "BOOL_OR", "BOOL_XOR",
)

#: Opcodes that produce a boolean (1-byte) result.
BOOLEAN_RESULT_OPS: Tuple[str, ...] = (
    "INT_EQUAL", "INT_NOTEQUAL", "INT_LESS", "INT_SLESS",
    "INT_CARRY", "INT_SCARRY", "INT_SBORROW",
    "BOOL_AND", "BOOL_OR", "BOOL_XOR", "BOOL_NEGATE",
)

TERMINATOR_OPS: Tuple[str, ...] = (
    "BRANCH", "CBRANCH", "BRANCHIND", "RETURN",
)

EFFECTFUL_OPS: Tuple[str, ...] = (
    "LOAD", "STORE", "CALL", "CALLIND", "RETURN",
    "BRANCH", "CBRANCH", "BRANCHIND",
)


@dataclass(frozen=True)
class Op:
    opcode: str
    out: Optional[Varnode] = None
    ins: Tuple[Varnode, ...] = ()
    #: call target name for CALL, successor labels for BRANCH/CBRANCH
    target: Optional[str] = None
    targets: Tuple[str, ...] = ()

    @property
    def is_pure(self) -> bool:
        return self.opcode in PURE_OPS

    @property
    def is_foldable(self) -> bool:
        return self.opcode in FOLDABLE_OPS

    @property
    def is_terminator(self) -> bool:
        return self.opcode in TERMINATOR_OPS

    def with_ins(self, ins: Sequence[Varnode]) -> "Op":
        return replace(self, ins=tuple(ins))

    def __repr__(self) -> str:  # pragma: no cover
        lhs = f"{self.out} = " if self.out is not None else ""
        tgt = f" -> {self.target or ','.join(self.targets)}" if (self.target or self.targets) else ""
        return f"{lhs}{self.opcode}({', '.join(map(repr, self.ins))}){tgt}"


@dataclass
class Block:
    label: str
    ops: List[Op] = field(default_factory=list)

    @property
    def terminator(self) -> Optional[Op]:
        return self.ops[-1] if self.ops and self.ops[-1].is_terminator else None

    def successors(self) -> List[str]:
        t = self.terminator
        if t is None:
            return []
        if t.opcode == "BRANCH":
            return [t.target] if t.target else []
        if t.opcode == "CBRANCH":
            return list(t.targets)
        return []

    def copy(self) -> "Block":
        return Block(self.label, list(self.ops))


@dataclass
class Function:
    """A recovered function: an entry block plus a control-flow graph."""

    name: str
    entry: str
    blocks: Dict[str, Block] = field(default_factory=dict)
    #: varnodes observable at every exit (Definition 4's live-out locations)
    live_out: Tuple[Varnode, ...] = ()

    # -- structure -------------------------------------------------------
    def copy(self) -> "Function":
        return Function(
            self.name,
            self.entry,
            {k: v.copy() for k, v in self.blocks.items()},
            tuple(self.live_out),
        )

    def order(self) -> List[str]:
        """Deterministic reverse-postorder from the entry; unreachable last."""
        seen, out = set(), []

        def visit(lbl: str) -> None:
            if lbl in seen or lbl not in self.blocks:
                return
            seen.add(lbl)
            out.append(lbl)
            for s in self.blocks[lbl].successors():
                visit(s)

        visit(self.entry)
        out.extend(sorted(set(self.blocks) - seen))
        return out

    def predecessors(self) -> Dict[str, List[str]]:
        preds: Dict[str, List[str]] = {k: [] for k in self.blocks}
        for lbl, blk in self.blocks.items():
            for s in blk.successors():
                if s in preds:
                    preds[s].append(lbl)
        return preds

    def iter_ops(self) -> Iterable[Tuple[str, int, Op]]:
        for lbl in self.order():
            for i, op in enumerate(self.blocks[lbl].ops):
                yield lbl, i, op

    def all_ops(self) -> List[Op]:
        return [op for _, _, op in self.iter_ops()]

    def call_targets(self) -> List[str]:
        return [op.target for op in self.all_ops()
                if op.opcode == "CALL" and op.target]

    # -- serialisation ---------------------------------------------------
    def to_text(self) -> str:
        """Deterministic textual form.  ``canonical.digest`` hashes this."""
        lines = [f"function {self.name}", f"entry {self.entry}"]
        for lbl in self.order():
            lines.append(f"block {lbl}")
            for op in self.blocks[lbl].ops:
                lines.append("  " + _op_text(op))
        lines.append("live_out " + ",".join(
            f"{v.space}:{v.offset}:{v.size}" for v in sorted(
                self.live_out, key=lambda v: v.structural_key())))
        return "\n".join(lines)

    def to_json(self) -> str:
        return json.dumps(_fn_obj(self), sort_keys=True)


def _op_text(op: Op) -> str:
    parts = [op.opcode]
    if op.out is not None:
        parts.append(f"out={op.out.space}:{op.out.offset}:{op.out.size}")
    for v in op.ins:
        parts.append(f"in={v.space}:{v.offset}:{v.size}")
    if op.target:
        parts.append(f"target={op.target}")
    for t in op.targets:
        parts.append(f"succ={t}")
    return " ".join(parts)


def _fn_obj(fn: Function) -> Dict[str, Any]:
    return {
        "name": fn.name,
        "entry": fn.entry,
        "blocks": [
            {"label": lbl, "ops": [_op_text(o) for o in fn.blocks[lbl].ops]}
            for lbl in fn.order()
        ],
        "live_out": [[v.space, v.offset, v.size] for v in fn.live_out],
    }


# --------------------------------------------------------------------------
# Concrete and symbolic evaluation
# --------------------------------------------------------------------------

def mask(bits: int) -> int:
    return (1 << bits) - 1


def to_signed(value: int, bits: int) -> int:
    value &= mask(bits)
    return value - (1 << bits) if value >> (bits - 1) else value


def eval_binary(opcode: str, a: int, b: int, bits: int) -> int:
    """Concrete fixed-width semantics of a binary pure opcode.

    Written with explicit masking rather than native bit-vector types; TV3
    proves this against Z3's native bit-vector semantics, which is exactly the
    class of masking and sign-extension bug the obligation is meant to catch.
    """
    m = mask(bits)
    a &= m
    b &= m
    sa, sb = to_signed(a, bits), to_signed(b, bits)
    if opcode == "INT_ADD":
        return (a + b) & m
    if opcode == "INT_SUB":
        return (a - b) & m
    if opcode == "INT_MULT":
        return (a * b) & m
    if opcode == "INT_AND":
        return a & b
    if opcode == "INT_OR":
        return a | b
    if opcode == "INT_XOR":
        return a ^ b
    if opcode == "INT_LEFT":
        return 0 if b >= bits else (a << b) & m
    if opcode == "INT_RIGHT":
        return 0 if b >= bits else (a >> b) & m
    if opcode == "INT_SRIGHT":
        sh = bits - 1 if b >= bits else b
        return (sa >> sh) & m
    if opcode == "INT_EQUAL":
        return int(a == b)
    if opcode == "INT_NOTEQUAL":
        return int(a != b)
    if opcode == "INT_LESS":
        return int(a < b)
    if opcode == "INT_SLESS":
        return int(sa < sb)
    if opcode == "INT_CARRY":
        return int((a + b) > m)
    if opcode == "INT_SCARRY":
        return int(to_signed((a + b) & m, bits) != sa + sb)
    if opcode == "INT_SBORROW":
        return int(to_signed((a - b) & m, bits) != sa - sb)
    if opcode == "BOOL_AND":
        return int(bool(a) and bool(b))
    if opcode == "BOOL_OR":
        return int(bool(a) or bool(b))
    if opcode == "BOOL_XOR":
        return int(bool(a) != bool(b))
    raise KeyError(f"not a binary pure opcode: {opcode}")


def eval_unary(opcode: str, a: int, bits: int) -> int:
    m = mask(bits)
    a &= m
    if opcode == "COPY":
        return a
    if opcode == "INT_NEGATE":
        return (~a) & m
    if opcode == "INT_2COMP":
        return (-a) & m
    if opcode == "BOOL_NEGATE":
        return int(not bool(a))
    raise KeyError(f"not a unary pure opcode: {opcode}")


UNARY_OPS = ("COPY", "INT_NEGATE", "INT_2COMP", "BOOL_NEGATE")
BINARY_OPS = tuple(o for o in PURE_OPS if o not in UNARY_OPS)


def eval_op(op: Op, values: Sequence[int]) -> int:
    bits = op.ins[0].bits if op.ins else 8
    if op.opcode in UNARY_OPS:
        return eval_unary(op.opcode, values[0], bits)
    return eval_binary(op.opcode, values[0], values[1], bits)
