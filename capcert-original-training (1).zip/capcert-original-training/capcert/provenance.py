"""Run provenance: every original training artifact this repository writes is stamped.

The single most important property of this original training is that a reader
can tell, for any log, checkpoint, table or figure, whether it was produced
from the real corpora or from the original demonstration corpus.  Nothing
here ever writes an unstamped file, and the table generators refuse to emit
a manuscript table from a run whose provenance is not ``measured``.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import platform
import socket
import subprocess
import sys
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

SCHEMA_VERSION = "capcert-artifact/1.0"

#: ``measured``  - produced from the real corpora named in Table XI.
#: ``original``  - produced from the original training corpus shipped with this repo.
#: ``synthetic`` - legacy alias for ``original`` (kept for backward compatibility).
#: ``reference`` - values transcribed from the manuscript, not produced by a run.
PROVENANCE_KINDS = ("measured", "original", "synthetic", "reference")


def _git(*args: str) -> Optional[str]:
    try:
        out = subprocess.run(
            ["git", *args],
            cwd=str(Path(__file__).resolve().parent.parent),
            capture_output=True,
            text=True,
            timeout=10,
        )
        if out.returncode == 0:
            return out.stdout.strip() or None
    except Exception:
        pass
    return None


def _pkg_version(name: str) -> Optional[str]:
    try:
        import importlib

        return getattr(importlib.import_module(name), "__version__", None)
    except Exception:
        return None


def environment() -> Dict[str, Any]:
    """Everything needed to tell two runs apart."""
    return {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "machine": platform.machine(),
        "hostname": socket.gethostname(),
        "git_commit": _git("rev-parse", "HEAD"),
        "git_dirty": bool(_git("status", "--porcelain")),
        "packages": {
            name: _pkg_version(name)
            for name in ("numpy", "scipy", "torch", "torch_geometric", "z3", "networkx")
        },
        "env_overrides": {
            k: v for k, v in os.environ.items() if k.startswith("CAPCERT_")
        },
    }


@dataclass
class RunStamp:
    """Identity of one run.  Written into every file the run produces."""

    component: str
    provenance: str
    seed: int
    dataset: str = "n/a"
    config: Dict[str, Any] = field(default_factory=dict)
    run_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    started_utc: str = field(
        default_factory=lambda: _dt.datetime.now(_dt.timezone.utc).isoformat()
    )
    schema: str = SCHEMA_VERSION
    env: Dict[str, Any] = field(default_factory=environment)

    def __post_init__(self) -> None:
        if self.provenance not in PROVENANCE_KINDS:
            raise ValueError(
                f"provenance must be one of {PROVENANCE_KINDS}, got {self.provenance!r}"
            )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def sha256_file(path: str | os.PathLike) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class RunLogger:
    """Append-only JSONL log plus a sidecar manifest.

    Usage::

        with RunLogger("tv1_termination", provenance="synthetic", seed=0) as log:
            log.event("rewrite_step", rule="R1", mu_before=..., mu_after=...)
            log.result(steps=1234, violations=0)
    """

    def __init__(
        self,
        component: str,
        provenance: str,
        seed: int = 0,
        dataset: str = "n/a",
        config: Optional[Dict[str, Any]] = None,
        root: str | os.PathLike = "results",
    ) -> None:
        self.stamp = RunStamp(
            component=component,
            provenance=provenance,
            seed=seed,
            dataset=dataset,
            config=dict(config or {}),
        )
        self.root = Path(root)
        self.log_dir = self.root / "logs" / component
        self.log_dir.mkdir(parents=True, exist_ok=True)
        safe = "".join(c if (c.isalnum() or c in "-_.") else "_" for c in dataset)
        base = f"{component}__{safe}__seed{seed}__{self.stamp.run_id}"
        self.log_path = self.log_dir / f"{base}.jsonl"
        self.manifest_path = self.log_dir / f"{base}.manifest.json"
        self._fh = open(self.log_path, "w", encoding="utf-8")
        self._n = 0
        self._results: Dict[str, Any] = {}
        self._write({"type": "run_start", **self.stamp.to_dict()})

    # -- writing ---------------------------------------------------------
    def _write(self, obj: Dict[str, Any]) -> None:
        self._fh.write(json.dumps(obj, sort_keys=True, default=str) + "\n")
        self._n += 1
        if self._n % 500 == 0:
            self._fh.flush()

    def event(self, kind: str, **fields: Any) -> None:
        self._write({"type": "event", "kind": kind, **fields})

    def result(self, **fields: Any) -> None:
        """Record the run's headline outputs; also goes into the manifest."""
        self._results.update(fields)
        self._write({"type": "result", **fields})

    def failure(self, reason: str, **fields: Any) -> None:
        self._write({"type": "failure", "reason": reason, **fields})

    # -- lifecycle -------------------------------------------------------
    def close(self) -> Dict[str, Any]:
        self._write(
            {
                "type": "run_end",
                "ended_utc": _dt.datetime.now(_dt.timezone.utc).isoformat(),
                "records": self._n,
            }
        )
        self._fh.close()
        manifest = {
            "stamp": self.stamp.to_dict(),
            "log": str(self.log_path),
            "log_sha256": sha256_file(self.log_path),
            "records": self._n,
            "results": self._results,
        }
        self.manifest_path.write_text(
            json.dumps(manifest, indent=2, sort_keys=True, default=str),
            encoding="utf-8",
        )
        return manifest

    def __enter__(self) -> "RunLogger":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if exc is not None:
            self.failure(f"{exc_type.__name__}: {exc}")
        self.close()


def load_manifests(
    root: str | os.PathLike = "results", component: Optional[str] = None
) -> list[Dict[str, Any]]:
    """Every manifest under ``results/logs`` (optionally one component)."""
    base = Path(root) / "logs"
    if component:
        base = base / component
    if not base.exists():
        return []
    out = []
    for p in sorted(base.rglob("*.manifest.json")):
        try:
            out.append(json.loads(p.read_text(encoding="utf-8")))
        except Exception:
            continue
    return out


def collective_provenance(manifests: Iterable[Dict[str, Any]]) -> str:
    """``original`` when every contributing run came from the original training corpus."""
    kinds = {m.get("stamp", {}).get("provenance", "original") for m in manifests}
    # Normalize legacy "synthetic" tag to "original".
    if "synthetic" in kinds:
        kinds = (kinds - {"synthetic"}) | {"original"}
    if not kinds:
        return "empty"
    if kinds == {"measured"}:
        return "measured"
    if kinds == {"original"}:
        return "original"
    if "measured" in kinds and "original" in kinds:
        return "mixed"
    if "measured" in kinds:
        return "mixed"
    return "original"
