#!/usr/bin/env python3
"""Regenerate the manuscript's tables from the logs a run produced.

Every table is built from ``results/logs/**/*.manifest.json`` and from nothing
else, so a table in ``results/tables`` can always be traced back to the runs
that produced it.

Runs stamped ``original`` were produced from the original training corpus
shipped with this repository.  Runs stamped ``measured`` were produced from
the real corpora of Table XI.  ``--strict`` restricts emission to the latter.

    python reporting/make_tables.py                 # whatever the logs support
    python reporting/make_tables.py --strict        # measured runs only
    python reporting/make_tables.py --table XVII
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from capcert.provenance import collective_provenance, load_manifests  # noqa: E402

WATERMARK = ""


def latest(manifests: List[Dict], component: str) -> Optional[Dict]:
    rows = [m for m in manifests
            if m.get("stamp", {}).get("component") == component]
    if not rows:
        return None
    return sorted(rows, key=lambda m: m["stamp"].get("started_utc", ""))[-1]


def all_of(manifests: List[Dict], component: str) -> List[Dict]:
    return [m for m in manifests
            if m.get("stamp", {}).get("component") == component]


def render(title: str, header: List[str], rows: List[List[str]],
           provenance: str, note: str = "") -> str:
    widths = [max(len(str(h)), *(len(str(r[i])) for r in rows)) if rows
              else len(str(h)) for i, h in enumerate(header)]
    def line(cells):
        return "  ".join(str(c).ljust(w) for c, w in zip(cells, widths)).rstrip()
    out = [title, "=" * len(title), ""]
    out += [line(header), "-" * max(10, len(line(header)))]
    out += [line(r) for r in rows]
    if note:
        out += ["", note]
    return "\n".join(out) + "\n"


# --------------------------------------------------------------------------
# Tables
# --------------------------------------------------------------------------

def table_xv(ms: List[Dict]) -> Optional[tuple]:
    runs = all_of(ms, "ev5_clean")
    if not runs:
        return None
    rows = []
    for m in sorted(runs, key=lambda m: m["stamp"]["seed"]):
        r = m.get("results", {})
        c = r.get("test_clean", {})
        if not c:
            continue
        ci = r.get("test_f1_interval", [None, None])
        rows.append([
            f"seed {m['stamp']['seed']}",
            f"{c.get('accuracy', 0):.2f}", f"{c.get('recall', 0):.2f}",
            f"{c.get('precision', 0):.2f}", f"{r.get('test_f1', 0):.2f}",
            f"[{ci[0]}, {ci[1]}]",
        ])
    if not rows:
        return None
    return ("TABLE XV  Clean detection on the test split",
            ["Run", "Acc", "Rec", "Prec", "F1", "95% CI (F1)"], rows,
            collective_provenance(runs),
            "Intervals are percentile bootstrap over test samples (Section VI-H).")


def table_xvii(ms: List[Dict]) -> Optional[tuple]:
    runs = all_of(ms, "ev3_certified") or all_of(ms, "ev5_clean")
    if not runs:
        return None
    rows = []
    for m in sorted(runs, key=lambda m: m["stamp"]["seed"]):
        ca = m.get("results", {}).get("certified_accuracy", {})
        if not ca:
            continue
        cells = []
        for u in ("0", "1", "2", "5", "10"):
            cell = ca.get(u) or ca.get(int(u)) if isinstance(ca, dict) else None
            if cell:
                lo, hi = cell["interval"]
                cells.append(f"{cell['value']:.2f} [{lo}, {hi}]")
            else:
                cells.append("n/a")
        rows.append([f"seed {m['stamp']['seed']}", *cells,
                     str(m["results"].get("median_radius"))])
    if not rows:
        return None
    return ("TABLE XVII  Certified accuracy by budget, in canonical-function edits",
            ["Run", "u=0", "u=1", "u=2", "u=5", "u=10", "Median radius"], rows,
            collective_provenance(runs),
            "Exact Clopper-Pearson intervals over the malware test split. "
            "A sample the detector misses is never counted as certified (C1).")


def table_xx(ms: List[Dict]) -> Optional[tuple]:
    m = latest(ms, "ev1_invariance")
    if not m:
        return None
    classes = m["results"].get("classes", {})
    rows = []
    for name, r in classes.items():
        rows.append([name, "yes" if r["in_class"] else "no",
                     f"{r['rate_percent']:.2f}",
                     f"[{r['interval'][0]}, {r['interval'][1]}]",
                     f"{r['unchanged']}/{r['trials']}"])
    return ("TABLE XX  Obfuscation invariance",
            ["Transformation", "In T_inv", "Unchanged %", "95% CI", "Count"], rows,
            collective_provenance([m]),
            "Theorem 1 requires exactly 100.00% for every in-class row.")


def table_xxii(ms: List[Dict]) -> Optional[tuple]:
    m = latest(ms, "ev2_recovery")
    if not m:
        return None
    t = m["results"].get("table_xxii", {})
    rows = []
    for code, r in t.items():
        rows.append([f"({code}) {r['family']}", str(r["median"]), str(r["mean"]),
                     str(r["max"]), f"{r['within_bound_percent']:.1f}", str(r["n"])])
    return ("TABLE XXII  Measured footprint per edit family (canonical-function units)",
            ["Edit family", "Median", "Mean", "Max", "Within bound %", "n"], rows,
            collective_provenance([m]),
            "Every footprint must lie within the Corollary 1 bound for its family.")


def table_xxiii(ms: List[Dict]) -> Optional[tuple]:
    m = latest(ms, "ev9_training")
    if not m:
        return None
    rows = []
    for label, r in m["results"].get("rows", {}).items():
        rows.append([label, f"{r['f1']:.2f}", str(r["median_votes"]),
                     str(r["ca1"]), str(r["ca2"]), str(r["mean_surrogate_gap"])])
    return ("TABLE XXIII  Effect of the training objective",
            ["Objective", "F1", "Median V(x)", "CA(1)", "CA(2)", "eps_tau"], rows,
            collective_provenance([m]),
            "eps_tau bounds |s(x) - V(x)| by Proposition 3.")


def table_xxiv(ms: List[Dict]) -> Optional[tuple]:
    m = latest(ms, "ev6_generalization")
    if not m:
        return None
    rows = []
    base = m["results"].get("rows", {}).get("random", {})
    for kind, r in m["results"].get("rows", {}).items():
        d_f1 = "" if kind == "random" else f"{r['f1'] - base.get('f1', 0):+.2f}"
        rows.append([kind, f"{r['f1']:.2f}", d_f1, str(r["ca1"]), str(r["ca2"]),
                     str(r["median_radius"]), str(r["n_test"])])
    return ("TABLE XXIV  F1 and certified accuracy under distribution shift",
            ["Split", "F1", "dF1", "CA(1)", "CA(2)", "Median radius", "n test"],
            rows, collective_provenance([m]),
            "The cross-source row bounds how much of the random-split result "
            "could be explained by provenance rather than behaviour.")


def table_xxv(ms: List[Dict]) -> Optional[tuple]:
    m = latest(ms, "ev7_efficiency")
    if not m:
        return None
    rows = []
    for stage, v in m["results"].get("stages", {}).items():
        rows.append([stage.replace("_ms", ""), f"{v['mean_ms']:.2f}",
                     f"{v['median_ms']:.2f}", f"{v['p95_ms']:.2f}"])
    return ("TABLE XXV  End-to-end cost per stage (ms per binary)",
            ["Stage", "Mean", "Median", "p95"], rows,
            collective_provenance([m]),
            m["results"].get("note", ""))


def table_xxvii(ms: List[Dict]) -> Optional[tuple]:
    comps = [("TV1", "tv1_termination", "violations", 0),
             ("TV2", "tv2_critical_pairs", "pairs_not_joinable", 0),
             ("TV3", "tv3_smt", "invalid", 0),
             ("TV4", "tv4_conformance", "verdict_changes_inside_radius", 0),
             ("TV5", "tv5_tightness", "flips_at_radius_plus_one", None),
             ("L0-inject", "l0_fault_injection", "injected_violations", ">0")]
    rows, used = [], []
    for label, comp, key, expect in comps:
        m = latest(ms, comp)
        if not m:
            rows.append([label, "not run", "-", "-"])
            continue
        used.append(m)
        res = m["results"]
        observed = res.get(key)
        extra = {
            "TV1": f"{res.get('steps')} steps",
            "TV2": f"{res.get('pairs_generated')} pairs, "
                   f"{res.get('pairs_joinable')} joinable",
            "TV3": f"{res.get('obligations')} obligations, "
                   f"{res.get('valid')} valid",
            "TV4": f"{res.get('footprints_checked')} footprints, "
                   f"{res.get('l0_audit_roots')} roots audited",
            "TV5": f"{res.get('mean_hash_evaluations')} vs "
                   f"{res.get('predicted_hash_evaluations')} predicted",
            "L0-inject": f"clean {res.get('clean_violations')}, "
                         f"injected {res.get('injected_violations')}",
        }[label]
        rows.append([label, str(expect), str(observed), extra])
    if not used:
        return None
    return ("TABLE XXVII  Outcome of the theoretical validation checks",
            ["Check", "Expected", "Observed", "Scale"], rows,
            collective_provenance(used),
            "These test the implementation against the proven results and do "
            "not add to the proofs.  The L0-inject row is the negative "
            "control: it must fail, or the audit above it is vacuous.")


def table_xxx(ms: List[Dict]) -> Optional[tuple]:
    runs = all_of(ms, "ev_packed")
    if not runs:
        return None
    rows = []
    for m in sorted(runs, key=lambda m: m["stamp"]["seed"]):
        t = m["results"].get("table_xxx", {})
        if not t:
            continue
        rows.append([f"seed {m['stamp']['seed']}", str(t.get("corpus_size")),
                     str(t.get("flagged")), f"{t.get('flagged_share_percent')}",
                     str(t.get("flagged_detection_rate_percent")),
                     str(t.get("flagged_certificates_issued"))])
    if not rows:
        return None
    return ("TABLE XXX  Packed and self-modifying subsets",
            ["Run", "Corpus", "Flagged", "Share %", "Detection %",
             "Certificates issued"], rows,
            collective_provenance(runs),
            "Certificates issued on the flagged subset must be 0: assumption A1 "
            "withholds rho_hat rather than reporting it as zero.")


BUILDERS = {
    "XV": table_xv, "XVII": table_xvii, "XX": table_xx, "XXII": table_xxii,
    "XXIII": table_xxiii, "XXIV": table_xxiv, "XXV": table_xxv,
    "XXVII": table_xxvii, "XXX": table_xxx,
}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--table", default=None, help="one table, e.g. XVII")
    ap.add_argument("--strict", action="store_true",
                    help="refuse to emit a table unless every run is 'measured'")
    args = ap.parse_args()

    ms = load_manifests(args.results)
    if not ms:
        print(f"no run manifests under {args.results}/logs -- run the "
              f"experiments first (make demo)")
        return 1

    out_dir = Path(args.results) / "tables"
    out_dir.mkdir(parents=True, exist_ok=True)
    wanted = [args.table.upper()] if args.table else list(BUILDERS)

    written, skipped = 0, 0
    for name in wanted:
        builder = BUILDERS.get(name)
        if builder is None:
            print(f"unknown table {name}")
            continue
        built = builder(ms)
        if built is None:
            print(f"Table {name:6s} skipped: no run has produced its inputs")
            skipped += 1
            continue
        title, header, rows, prov, note = built
        if args.strict and prov != "measured":
            print(f"Table {name:6s} refused: provenance is '{prov}', not "
                  f"'measured' (--strict)")
            skipped += 1
            continue
        text = render(title, header, rows, prov, note)
        path = out_dir / f"table_{name}.txt"
        path.write_text(text, encoding="utf-8")
        print(f"Table {name:6s} -> {path}  [{prov}]")
        written += 1

    print(f"\n{written} tables written, {skipped} skipped, into {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
