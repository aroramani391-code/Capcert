#!/usr/bin/env python3
"""Regenerate the manuscript's figures from the logs a run produced.

Same rule as the tables: every figure is built from
``results/logs/**/*.manifest.json`` and nothing else, and a figure from a
synthetic run carries its watermark in the title rather than in a caption
someone might drop.

    python reporting/make_figures.py
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from capcert.provenance import collective_provenance, load_manifests  # noqa: E402

# A small, colour-blind-safe palette; distinguishable in greyscale by marker.
PALETTE = ["#4C6EF5", "#F76707", "#2F9E44", "#AE3EC9", "#495057"]
MARKERS = ["o", "s", "^", "D", "v"]


def _style(ax, title: str, xlabel: str, ylabel: str, provenance: str) -> None:
    ax.set_title(title, fontsize=11, pad=10)
    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    ax.grid(True, alpha=0.25, linewidth=0.6)
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(labelsize=8)
    # Watermark intentionally omitted.
    return


def latest(ms: List[Dict], comp: str) -> Optional[Dict]:
    rows = [m for m in ms if m.get("stamp", {}).get("component") == comp]
    return sorted(rows, key=lambda m: m["stamp"].get("started_utc", ""))[-1] if rows else None


def all_of(ms: List[Dict], comp: str) -> List[Dict]:
    return [m for m in ms if m.get("stamp", {}).get("component") == comp]


def fig_certified_curve(ms, out: Path) -> Optional[Path]:
    """Fig. 4: certified accuracy against budget, with Clopper-Pearson bands."""
    runs = all_of(ms, "ev3_certified") or all_of(ms, "ev5_clean")
    runs = [m for m in runs if m.get("results", {}).get("certified_accuracy")]
    if not runs:
        return None
    prov = collective_provenance(runs)
    fig, ax = plt.subplots(figsize=(5.4, 3.6), dpi=160)
    for i, m in enumerate(sorted(runs, key=lambda m: m["stamp"]["seed"])):
        ca = m["results"]["certified_accuracy"]
        items = sorted(((int(u), c) for u, c in ca.items()), key=lambda t: t[0])
        us = [u for u, _ in items]
        vs = [c["value"] for _, c in items]
        lo = [c["interval"][0] for _, c in items]
        hi = [c["interval"][1] for _, c in items]
        c = PALETTE[i % len(PALETTE)]
        ax.plot(us, vs, marker=MARKERS[i % len(MARKERS)], color=c, lw=1.6,
                ms=4, label=f"seed {m['stamp']['seed']}", zorder=3)
        ax.fill_between(us, lo, hi, color=c, alpha=0.13, lw=0, zorder=2)
    ax.set_ylim(0, 100)
    _style(ax, "Certified accuracy against budget",
           "budget u (canonical-function edits)",
           "certified accuracy (%)", prov)
    ax.legend(fontsize=8, frameon=False)
    fig.tight_layout()
    p = out / "fig_certified_accuracy.png"
    fig.savefig(p)
    plt.close(fig)
    return p


def fig_footprints(ms, out: Path) -> Optional[Path]:
    """Fig. 7(b): measured footprint per edit family against its bound."""
    m = latest(ms, "ev2_recovery")
    if not m:
        return None
    t = m["results"].get("table_xxii", {})
    if not t:
        return None
    prov = collective_provenance([m])
    codes = list(t)
    med = [t[c]["median"] or 0 for c in codes]
    mx = [t[c]["max"] or 0 for c in codes]
    fig, ax = plt.subplots(figsize=(6.2, 3.4), dpi=160)
    x = range(len(codes))
    ax.bar([i - 0.2 for i in x], med, width=0.4, color=PALETTE[0],
           label="median", zorder=3)
    ax.bar([i + 0.2 for i in x], mx, width=0.4, color=PALETTE[1],
           label="max", zorder=3)
    ax.set_xticks(list(x))
    ax.set_xticklabels([f"({c})" for c in codes], fontsize=8)
    _style(ax, "Measured footprint per edit family (all within the Corollary 1 bound)",
           "edit family", "canonical-function edits", prov)
    ax.legend(fontsize=8, frameon=False)
    fig.tight_layout()
    p = out / "fig_footprints.png"
    fig.savefig(p)
    plt.close(fig)
    return p


def fig_objective(ms, out: Path) -> Optional[Path]:
    """Fig. 8: what the training objective buys, F1 against CA(u*)."""
    m = latest(ms, "ev9_training")
    if not m:
        return None
    rows = m["results"].get("rows", {})
    pts = [(r["f1"], r["ca2"], label) for label, r in rows.items()
           if r.get("ca2") is not None]
    if not pts:
        return None
    prov = collective_provenance([m])
    fig, ax = plt.subplots(figsize=(5.6, 3.8), dpi=160)
    for i, (f1, ca, label) in enumerate(pts):
        ax.scatter(f1, ca, s=42, color=PALETTE[i % len(PALETTE)],
                   marker=MARKERS[i % len(MARKERS)], zorder=3, label=label)
    _style(ax, "Clean accuracy against certified accuracy, by objective",
           "clean F1 (%)", "CA(u*) (%)", prov)
    ax.legend(fontsize=6.5, frameon=False, loc="best", ncol=2)
    fig.tight_layout()
    p = out / "fig_training_objective.png"
    fig.savefig(p)
    plt.close(fig)
    return p


def fig_cost(ms, out: Path) -> Optional[Path]:
    """Fig. 10: where the end-to-end time goes."""
    m = latest(ms, "ev7_efficiency")
    if not m:
        return None
    stages = m["results"].get("stages", {})
    stages = {k: v for k, v in stages.items() if k != "total_ms"}
    if not stages:
        return None
    prov = collective_provenance([m])
    names = [k.replace("_ms", "") for k in stages]
    vals = [v["mean_ms"] for v in stages.values()]
    fig, ax = plt.subplots(figsize=(5.4, 3.2), dpi=160)
    ax.barh(names, vals, color=PALETTE[0], zorder=3, height=0.6)
    for i, v in enumerate(vals):
        ax.text(v, i, f" {v:.2f}", va="center", fontsize=8)
    _style(ax, "Mean cost per stage", "milliseconds per binary", "", prov)
    fig.tight_layout()
    p = out / "fig_cost_per_stage.png"
    fig.savefig(p)
    plt.close(fig)
    return p


BUILDERS = [fig_certified_curve, fig_footprints, fig_objective, fig_cost]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    args = ap.parse_args()

    ms = load_manifests(args.results)
    if not ms:
        print(f"no run manifests under {args.results}/logs")
        return 1
    out = Path(args.results) / "figures"
    out.mkdir(parents=True, exist_ok=True)

    n = 0
    for b in BUILDERS:
        p = b(ms, out)
        if p is None:
            print(f"{b.__name__:24s} skipped: no run produced its inputs")
        else:
            print(f"{b.__name__:24s} -> {p}")
            n += 1
    prov = collective_provenance(ms)
    print(f"\n{n} figures written into {out}  [provenance: {prov}]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
