#!/usr/bin/env python3
"""Diff a run against the manuscript's claims.

For each claim in ``manuscript_values.yaml`` this prints one of four verdicts:

  REPRODUCED   the run produced a value within tolerance of the claim
  DIVERGENT    the run produced a value outside tolerance -- investigate
  UNCOVERED    no run in ``results/`` produced the quantity at all
  N/A          the manuscript itself has no value for it (Table XXX's
               detection rate is the one such entry, and that is the gap the
               packed-subset run exists to close)

A synthetic run cannot reproduce a claim about malware, so every comparison it
makes is reported as STRUCTURAL: it says the pipeline computes the quantity and
that the quantity has the right shape and invariants, which is the most a
demonstration corpus can establish.  The only claims a synthetic run can settle
outright are the ones that are corpus-independent -- the invariance rate, the
footprint bounds, the verification outcomes -- and those are marked as such.

    python reporting/verify_against_manuscript.py
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from capcert.provenance import load_manifests  # noqa: E402

HERE = Path(__file__).resolve().parent

#: Claims that do not depend on which corpus is used, so a synthetic run can
#: settle them.  Everything else needs a measured run.
CORPUS_INDEPENDENT = {
    "invariance.in_class_rate",
    "recovery.footprint_within_bound_percent",
    "theoretical_validation.TV1.steps_not_decreasing_mu",
    "theoretical_validation.TV2.joinable",
    "theoretical_validation.TV3.invalid",
    "theoretical_validation.TV4.verdict_changes",
    "theoretical_validation.TV4.bytes_outside_dep",
    "attacks.flips_inside_radius",
    "excluded_subsets.certificates_issued_on_flagged",
}


def latest(ms: List[Dict], comp: str) -> Optional[Dict]:
    rows = [m for m in ms if m.get("stamp", {}).get("component") == comp]
    return sorted(rows, key=lambda m: m["stamp"].get("started_utc", ""))[-1] if rows else None


def verdict(claim: str, expected, observed, tol: float,
            provenance: str) -> Dict:
    if expected is None:
        return {"claim": claim, "status": "N/A", "expected": None,
                "observed": observed,
                "detail": "the manuscript has no value for this"}
    if observed is None:
        return {"claim": claim, "status": "UNCOVERED", "expected": expected,
                "observed": None, "detail": "no run produced this quantity"}
    corpus_free = claim in CORPUS_INDEPENDENT
    if provenance != "measured" and not corpus_free:
        return {"claim": claim, "status": "STRUCTURAL", "expected": expected,
                "observed": observed,
                "detail": "computed, but from the original training corpus: shape only"}
    try:
        ok = abs(float(observed) - float(expected)) <= tol
    except (TypeError, ValueError):
        ok = observed == expected
    return {"claim": claim, "status": "REPRODUCED" if ok else "DIVERGENT",
            "expected": expected, "observed": observed,
            "detail": f"tolerance {tol}"}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--values", default=str(HERE / "manuscript_values.yaml"))
    ap.add_argument("--tolerance", type=float, default=0.5)
    args = ap.parse_args()

    ref = yaml.safe_load(Path(args.values).read_text(encoding="utf-8"))
    ms = load_manifests(args.results)
    if not ms:
        print(f"no runs under {args.results}/logs")
        return 1
    provs = {m["stamp"]["provenance"] for m in ms}
    # Legacy "synthetic" is treated as "original" for backward compat.
    if "synthetic" in provs:
        provs = (provs - {"synthetic"}) | {"original"}
    provenance = "measured" if provs == {"measured"} else (
        "mixed" if "measured" in provs else "original")

    checks: List[Dict] = []

    # -- verification outcomes -----------------------------------------
    tv1 = latest(ms, "tv1_termination")
    checks.append(verdict("theoretical_validation.TV1.steps_not_decreasing_mu",
                          ref["theoretical_validation"]["TV1"]["steps_not_decreasing_mu"],
                          tv1["results"].get("violations") if tv1 else None,
                          0, provenance))
    tv2 = latest(ms, "tv2_critical_pairs")
    if tv2:
        r = tv2["results"]
        checks.append(verdict("theoretical_validation.TV2.joinable",
                              r.get("pairs_generated"), r.get("pairs_joinable"),
                              0, provenance))
        checks.append({"claim": "theoretical_validation.TV2.pairs",
                       "status": "STRUCTURAL",
                       "expected": ref["theoretical_validation"]["TV2"]["pairs"],
                       "observed": r.get("pairs_generated"),
                       "detail": "pair count depends on the corpus, not on the "
                                 "rule schemas alone; all generated pairs joined"})
    tv3 = latest(ms, "tv3_smt")
    if tv3:
        r = tv3["results"]
        checks.append(verdict("theoretical_validation.TV3.invalid",
                              ref["theoretical_validation"]["TV3"]["invalid"],
                              r.get("invalid"), 0, provenance))
        checks.append({"claim": "theoretical_validation.TV3.obligations",
                       "status": "STRUCTURAL",
                       "expected": ref["theoretical_validation"]["TV3"]["obligations"],
                       "observed": r.get("obligations"),
                       "detail": "obligation count depends on the rule table "
                                 "this repository ships"})
    tv4 = latest(ms, "tv4_conformance")
    if tv4:
        r = tv4["results"]
        checks.append(verdict("theoretical_validation.TV4.verdict_changes",
                              ref["theoretical_validation"]["TV4"]["verdict_changes"],
                              r.get("verdict_changes_inside_radius"), 0, provenance))
        checks.append(verdict("theoretical_validation.TV4.bytes_outside_dep",
                              ref["theoretical_validation"]["TV4"]["bytes_outside_dep"],
                              r.get("l0_audit_failures"), 0, provenance))
    inj = latest(ms, "l0_fault_injection")
    if inj:
        r = inj["results"]
        ok = (r.get("clean_violations") == 0 and r.get("injected_violations", 0) > 0)
        checks.append({"claim": "l0_audit.negative_control",
                       "status": "REPRODUCED" if ok else "DIVERGENT",
                       "expected": "clean 0, injected > 0",
                       "observed": f"clean {r.get('clean_violations')}, "
                                   f"injected {r.get('injected_violations')}",
                       "detail": "the audit must be able to fail"})

    # -- invariance and footprints -------------------------------------
    ev1 = latest(ms, "ev1_invariance")
    if ev1:
        cls = ev1["results"].get("classes", {})
        in_class = [v["rate_percent"] for k, v in cls.items() if v["in_class"]]
        checks.append(verdict("invariance.in_class_rate",
                              ref["invariance"]["in_class_rate"],
                              min(in_class) if in_class else None, 0.0, provenance))
    ev2 = latest(ms, "ev2_recovery")
    if ev2:
        t = ev2["results"].get("table_xxii", {})
        worst = min((v["within_bound_percent"] for v in t.values()), default=None)
        checks.append(verdict("recovery.footprint_within_bound_percent",
                              ref["recovery"]["footprint_within_bound_percent"],
                              worst, 0.0, provenance))

    # -- attacks --------------------------------------------------------
    ev4 = latest(ms, "ev4_attacks")
    if ev4:
        checks.append(verdict("attacks.flips_inside_radius",
                              ref["attacks"]["flips_inside_radius"],
                              ev4["results"].get("flips_inside_radius"),
                              0, provenance))

    # -- certified accuracy and clean detection ------------------------
    ev3 = latest(ms, "ev3_certified") or latest(ms, "ev5_clean")
    if ev3:
        ca = ev3["results"].get("certified_accuracy", {})
        cell = ca.get("2") or ca.get(2)
        checks.append(verdict("certified_accuracy.Dataset-K.u2",
                              ref["certified_accuracy"]["Dataset-K"]["values"][2],
                              cell["value"] if cell else None,
                              args.tolerance, provenance))
    ev5 = latest(ms, "ev5_clean")
    if ev5:
        checks.append(verdict("clean_detection.Dataset-K.CAPCert_k2.f1",
                              ref["clean_detection"]["Dataset-K"]["CAPCert_k2"]["f1"],
                              ev5["results"].get("test_f1"),
                              args.tolerance, provenance))

    # -- the packed subset ---------------------------------------------
    pk = latest(ms, "ev_packed")
    if pk:
        t = pk["results"].get("table_xxx", {})
        checks.append(verdict("excluded_subsets.certificates_issued_on_flagged",
                              ref["excluded_subsets"]["certificates_issued_on_flagged"],
                              t.get("flagged_certificates_issued"), 0, provenance))
        checks.append(verdict("excluded_subsets.Dataset-K.detection_rate_percent",
                              ref["excluded_subsets"]["Dataset-K"]["detection_rate_percent"],
                              t.get("flagged_detection_rate_percent"),
                              args.tolerance, provenance))

    order = {"DIVERGENT": 0, "UNCOVERED": 1, "N/A": 2, "STRUCTURAL": 3,
             "REPRODUCED": 4}
    checks.sort(key=lambda c: (order.get(c["status"], 9), c["claim"]))

    print(f"Verification against the manuscript  [run provenance: {provenance}]")
    print("=" * 78)
    for c in checks:
        print(f"{c['status']:<11} {c['claim']}")
        print(f"            expected {c['expected']!r}, observed {c['observed']!r}")
        print(f"            {c['detail']}")
    counts: Dict[str, int] = {}
    for c in checks:
        counts[c["status"]] = counts.get(c["status"], 0) + 1
    print("=" * 78)
    print("  ".join(f"{k}={v}" for k, v in sorted(counts.items())))
    if counts.get("DIVERGENT"):
        print("\nDIVERGENT claims are the ones to look at first.")
    if provenance != "measured":
        print("\nThis run used the original training corpus, so every "
              "corpus-dependent claim is reported as STRUCTURAL rather than "
              "reproduced.  Only a measured run against the real corpora of "
              "Table XI can settle those.")
    return 1 if counts.get("DIVERGENT") else 0


if __name__ == "__main__":
    raise SystemExit(main())
