#!/usr/bin/env python3
"""Fault injection: show that the L0 audit can fail.

An audit that only reported what the accessor recorded would pass no matter
what the code did.  This script injects the defect reported in Section VII-J --
the jump-table length rule reading one entry past the bound without recording
it in Dep -- and requires the audit to catch it.

A run has two phases and both must come out as expected:

    clean     every root audits clean               -> 0 violations expected
    injected  the off-by-one is enabled             -> >0 violations expected

If the injected phase passes the audit, the audit is vacuous and this script
exits non-zero.  That is the point: the negative control is the evidence that
the positive result means something.
"""
from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path
from typing import List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from capcert.datasets import synthetic_corpus
from capcert.image import Accessor
from capcert.lfr import (
    RecoveryOptions,
    dependency_closure,
    enumerate_roots,
    recover_root,
)
from capcert.provenance import RunLogger


def audit(images, opts: RecoveryOptions, rng: random.Random,
          trials: int = 6) -> List[dict]:
    """Audit every root two ways.

    ``set`` compares the recorded content reads with the independent closure.
    It catches a read that is recorded but should not have been.

    ``diff`` mutates bytes *outside* Dep_x(e) and requires kappa(f_e) to stay
    bit-identical.  It catches a read that happened but was never recorded --
    which a set comparison cannot see, and which is exactly the shape of the
    jump-table off-by-one.  Both are needed; neither subsumes the other.
    """
    from capcert.canonical import digest

    recs = []
    for sha, img in images.items():
        for kind, name in enumerate_roots(img):
            acc = Accessor(img)
            rr = recover_root(img, name, kind, opts, accessor=acc)
            expected = dependency_closure(img, name, opts)
            extra = rr.dep_content - expected
            missing = expected - rr.dep_content
            undeclared = acc.undeclared()
            set_ok = not extra and not missing and not undeclared

            base = digest(rr.function)
            outside = [i for i in range(len(img.data))
                       if i not in rr.dep_content and i not in rr.dep_locator]
            diff_fail = 0
            for _ in range(trials):
                if not outside:
                    break
                pos = rng.choice(outside)
                mutant = img.copy()
                mutant.data[pos] = (mutant.data[pos] + 1 + rng.randrange(254)) & 0xFF
                try:
                    after = digest(recover_root(mutant, name, kind, opts).function)
                except Exception:
                    continue      # an undecodable mutant is not an L0 failure
                if after != base:
                    diff_fail += 1

            recs.append({
                "binary": sha[:16], "root": name,
                "recorded": len(rr.dep_content), "expected": len(expected),
                "n_extra": len(extra), "n_missing": len(missing),
                "n_undeclared": len(undeclared),
                "set_ok": set_ok,
                "diff_failures": diff_fail,
                "ok": set_ok and diff_fail == 0,
            })
    return recs


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=40)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--results", default="results")
    args = ap.parse_args()

    _, images = synthetic_corpus(n_malicious=args.n // 2, n_benign=args.n // 2,
                                 seed=args.seed)

    with RunLogger("l0_fault_injection", "original", seed=args.seed,
                   dataset="original", root=args.results,
                   config={"n_images": len(images)}) as log:
        rng = random.Random(args.seed)
        clean = audit(images, RecoveryOptions(), rng)
        clean_bad = sum(1 for r in clean if not r["ok"])
        for r in clean:
            log.event("clean_audit", **r)

        injected = audit(images,
                         RecoveryOptions(inject_jumptable_off_by_one=True), rng)
        inj_bad = sum(1 for r in injected if not r["ok"])
        for r in injected:
            log.event("injected_audit", **r)

        # A corpus with no BRANCHIND has no jump table to read past, so the
        # injected fault would have nothing to trigger on.  Say so rather than
        # reporting a vacuous pass.
        has_jump_tables = _corpus_has_jump_tables(images)

        detected = inj_bad > 0
        passed = (clean_bad == 0) and (detected or not has_jump_tables)
        log.result(
            clean_roots=len(clean), clean_violations=clean_bad,
            injected_roots=len(injected), injected_violations=inj_bad,
            corpus_has_jump_tables=has_jump_tables,
            fault_detected=detected,
            expected={"clean_violations": 0, "fault_detected": True},
            passed=passed,
            note=("the injected fault reads one jump-table entry past the bound "
                  "without recording it, which is the defect of Section VII-J"),
        )

    print(f"L0 fault injection {'PASS' if passed else 'FAIL'}")
    print(f"     clean phase:    {len(clean)} roots, {clean_bad} violations "
          f"(expected 0)")
    print(f"     injected phase: {len(injected)} roots, {inj_bad} violations "
          f"(expected > 0)")
    if not has_jump_tables:
        print("     note: this corpus contains no BRANCHIND jump tables, so the "
              "injected fault had nothing to trigger on; rerun with a corpus "
              "that has them before reading this as evidence.")
    return 0 if passed else 1


def _corpus_has_jump_tables(images) -> bool:
    from capcert.edits import image_functions

    for img in images.values():
        for fn in image_functions(img).values():
            for op in fn.all_ops():
                if op.opcode == "BRANCHIND" and op.targets:
                    return True
    return False


if __name__ == "__main__":
    raise SystemExit(main())
