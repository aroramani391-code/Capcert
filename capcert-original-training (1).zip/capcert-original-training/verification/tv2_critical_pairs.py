#!/usr/bin/env python3
"""TV2: local confluence by critical-pair analysis.

Two rule instances form a critical pair when they overlap -- they touch the
same block or the same op -- or when applying one can disable the other's
precondition.  The system is terminating (TV1), so by Newman's lemma local
confluence gives confluence, and confluence is what makes kappa a *function*
rather than a strategy-dependent choice.  Theorem 1 needs exactly that.

For each pair (r1, r2) at a site, the check applies r1 then normalises, applies
r2 then normalises, and requires the two normal forms to be identical.  That is
joinability, decided rather than argued, which is possible here because the
system terminates.

The pairs are generated from real functions, not from the rule schemas in the
abstract, so the count depends on the corpus.  The run reports the number it
actually generated; it does not assert a number fixed in advance.

Usage
-----
    python verification/tv2_critical_pairs.py --n 120
"""
from __future__ import annotations

import argparse
import itertools
import sys
from collections import Counter
from pathlib import Path
from typing import List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from capcert import rewrite as rw
from capcert.canonical import digest_of_canonical, kappa
from capcert.datasets import synthetic_corpus
from capcert.edits import image_functions
from capcert.ir import Function
from capcert.provenance import RunLogger


def _site_blocks(rx: rw.Redex) -> Tuple[str, ...]:
    """The block labels a redex touches, for the overlap test."""
    if rx.rule in ("R1",):
        return tuple(rx.site)
    if rx.rule in ("R2",):
        return (rx.site[0],)
    return (rx.site[0],)


def overlapping(a: rw.Redex, b: rw.Redex) -> bool:
    """Do these two redexes overlap, or can one disable the other?"""
    if a.key() == b.key():
        return False
    if set(_site_blocks(a)) & set(_site_blocks(b)):
        return True
    # structural rules can relabel or remove blocks another redex names
    return a.rule in ("R1", "R2") or b.rule in ("R1", "R2")


def joinable(fn: Function, a: rw.Redex, b: rw.Redex) -> Tuple[bool, Optional[str], Optional[str]]:
    """Apply each redex, normalise both results, compare canonical digests."""
    try:
        fa = rw.normal_form(rw.apply_redex(fn, a))
        fb = rw.normal_form(rw.apply_redex(fn, b))
    except (rw.TerminationViolation, ValueError, KeyError):
        return False, None, None
    from capcert.canonical import _relabel

    da = digest_of_canonical(_relabel(fa))
    db = digest_of_canonical(_relabel(fb))
    return da == db, da, db


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=120)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--max-pairs-per-function", type=int, default=40)
    ap.add_argument("--results", default="results")
    args = ap.parse_args()

    _, images = synthetic_corpus(n_malicious=args.n // 2, n_benign=args.n // 2,
                                 seed=args.seed)

    with RunLogger("tv2_critical_pairs", "original", seed=args.seed,
                   dataset="original", root=args.results,
                   config={"n_images": len(images)}) as log:
        pairs = 0
        joined = 0
        by_class: Counter = Counter()
        failures: List[dict] = []
        seen_classes = set()

        for sha, img in images.items():
            for name, fn in sorted(image_functions(img).items()):
                rs = rw.redexes(fn)
                n_here = 0
                for a, b in itertools.combinations(rs, 2):
                    if not overlapping(a, b):
                        continue
                    if n_here >= args.max_pairs_per_function:
                        break
                    n_here += 1
                    pairs += 1
                    cls = tuple(sorted((a.rule, b.rule)))
                    by_class[cls] += 1
                    seen_classes.add(cls)
                    ok, da, db = joinable(fn, a, b)
                    if ok:
                        joined += 1
                    else:
                        rec = {"binary": sha[:16], "function": name,
                               "rule_a": a.rule, "site_a": str(a.site),
                               "rule_b": b.rule, "site_b": str(b.site),
                               "nf_a": da, "nf_b": db}
                        failures.append(rec)
                        log.failure("not_joinable", **rec)
                    log.event("critical_pair", binary=sha[:16], function=name,
                              rule_a=a.rule, rule_b=b.rule,
                              site_a=str(a.site), site_b=str(b.site),
                              joinable=ok)

        log.result(
            pairs_generated=pairs,
            pairs_joinable=joined,
            pairs_not_joinable=pairs - joined,
            pair_classes=sorted(f"{x}/{y}" for x, y in seen_classes),
            pairs_by_class={f"{x}/{y}": n for (x, y), n in sorted(by_class.items())},
            passed=(pairs == joined),
        )

    status = "PASS" if pairs == joined else "FAIL"
    print(f"TV2 {status}: {pairs} critical pairs generated, {joined} joinable, "
          f"{pairs - joined} not")
    print(f"     {len(seen_classes)} distinct pair classes: "
          + ", ".join(f"{x}/{y}" for x, y in sorted(seen_classes)))
    return 0 if pairs == joined else 1


if __name__ == "__main__":
    raise SystemExit(main())
