#!/usr/bin/env python3
"""TV3: rule soundness obligations discharged with Z3.

Three obligation groups, all in fixed-width bit-vector arithmetic at 8, 16, 32
and 64 bits, which is the scope Section VI-F states and no wider:

  fold    for every foldable opcode: the concrete folder in ``capcert.ir`` --
          Python integers with explicit masking -- agrees with Z3's native
          bit-vector semantics for all inputs.  This is the obligation that
          catches masking and sign-extension bugs, which is the class of bug a
          hand-written folder actually has.

  ident   every algebraic identity R4/R5 rely on (Table VII), proven valid.

  flag    INT_CARRY, INT_SCARRY and INT_SBORROW against their defining
          zero- and sign-extended conditions.

What this does *not* establish is stated in the manuscript and repeated here:
these are obligations about P-code semantics, not about Windows processes, the
lifter, or widths outside the four checked.

Usage
-----
    python verification/tv3_smt.py
    python verification/tv3_smt.py --widths 8 16 --quick
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path
from typing import Callable, Dict, List, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import z3  # noqa: E402

from capcert.ir import BINARY_OPS, UNARY_OPS, eval_binary, eval_unary  # noqa: E402
from capcert.provenance import RunLogger  # noqa: E402

WIDTHS = (8, 16, 32, 64)


# --------------------------------------------------------------------------
# Reference semantics in Z3, written independently of capcert.ir
# --------------------------------------------------------------------------

def z3_binary(opcode: str, a: z3.BitVecRef, b: z3.BitVecRef, bits: int) -> z3.BitVecRef:
    one = z3.BitVecVal(1, bits)
    zero = z3.BitVecVal(0, bits)
    if opcode == "INT_ADD":
        return a + b
    if opcode == "INT_SUB":
        return a - b
    if opcode == "INT_MULT":
        return a * b
    if opcode == "INT_AND":
        return a & b
    if opcode == "INT_OR":
        return a | b
    if opcode == "INT_XOR":
        return a ^ b
    if opcode == "INT_LEFT":
        return z3.If(z3.UGE(b, z3.BitVecVal(bits, bits)), zero, a << b)
    if opcode == "INT_RIGHT":
        return z3.If(z3.UGE(b, z3.BitVecVal(bits, bits)), zero, z3.LShR(a, b))
    if opcode == "INT_SRIGHT":
        sh = z3.If(z3.UGE(b, z3.BitVecVal(bits, bits)),
                   z3.BitVecVal(bits - 1, bits), b)
        return a >> sh
    if opcode == "INT_EQUAL":
        return z3.If(a == b, one, zero)
    if opcode == "INT_NOTEQUAL":
        return z3.If(a != b, one, zero)
    if opcode == "INT_LESS":
        return z3.If(z3.ULT(a, b), one, zero)
    if opcode == "INT_SLESS":
        return z3.If(a < b, one, zero)
    if opcode == "INT_CARRY":
        wide = z3.ZeroExt(1, a) + z3.ZeroExt(1, b)
        return z3.If(z3.Extract(bits, bits, wide) == z3.BitVecVal(1, 1), one, zero)
    if opcode == "INT_SCARRY":
        wide = z3.SignExt(1, a) + z3.SignExt(1, b)
        return z3.If(wide != z3.SignExt(1, a + b), one, zero)
    if opcode == "INT_SBORROW":
        wide = z3.SignExt(1, a) - z3.SignExt(1, b)
        return z3.If(wide != z3.SignExt(1, a - b), one, zero)
    if opcode == "BOOL_AND":
        return z3.If(z3.And(a != zero, b != zero), one, zero)
    if opcode == "BOOL_OR":
        return z3.If(z3.Or(a != zero, b != zero), one, zero)
    if opcode == "BOOL_XOR":
        return z3.If((a != zero) != (b != zero), one, zero)
    raise KeyError(opcode)


def z3_unary(opcode: str, a: z3.BitVecRef, bits: int) -> z3.BitVecRef:
    one, zero = z3.BitVecVal(1, bits), z3.BitVecVal(0, bits)
    if opcode == "COPY":
        return a
    if opcode == "INT_NEGATE":
        return ~a
    if opcode == "INT_2COMP":
        return -a
    if opcode == "BOOL_NEGATE":
        return z3.If(a == zero, one, zero)
    raise KeyError(opcode)


# --------------------------------------------------------------------------
# The concrete folder, lifted to symbolic inputs
# --------------------------------------------------------------------------

def folder_binary_sym(opcode: str, a: z3.BitVecRef, b: z3.BitVecRef,
                      bits: int) -> z3.BitVecRef:
    """Transcribe ``capcert.ir.eval_binary`` onto bit-vectors, masks and all.

    The point of the obligation is that this transcription -- mask, shift,
    signed/unsigned split -- matches ``z3_binary``.  If the concrete folder
    gets a mask or a sign extension wrong, the two disagree and Z3 finds the
    counterexample.
    """
    m_all = z3.BitVecVal((1 << bits) - 1, bits)
    zero = z3.BitVecVal(0, bits)
    one = z3.BitVecVal(1, bits)
    bw = z3.BitVecVal(bits, bits)
    a = a & m_all
    b = b & m_all
    if opcode in ("INT_ADD", "INT_SUB", "INT_MULT", "INT_AND", "INT_OR", "INT_XOR"):
        raw = {"INT_ADD": a + b, "INT_SUB": a - b, "INT_MULT": a * b,
               "INT_AND": a & b, "INT_OR": a | b, "INT_XOR": a ^ b}[opcode]
        return raw & m_all
    if opcode == "INT_LEFT":
        return z3.If(z3.UGE(b, bw), zero, (a << b) & m_all)
    if opcode == "INT_RIGHT":
        return z3.If(z3.UGE(b, bw), zero, z3.LShR(a, b) & m_all)
    if opcode == "INT_SRIGHT":
        sh = z3.If(z3.UGE(b, bw), z3.BitVecVal(bits - 1, bits), b)
        return (a >> sh) & m_all          # arithmetic shift of the signed value
    if opcode == "INT_EQUAL":
        return z3.If(a == b, one, zero)
    if opcode == "INT_NOTEQUAL":
        return z3.If(a != b, one, zero)
    if opcode == "INT_LESS":
        return z3.If(z3.ULT(a, b), one, zero)
    if opcode == "INT_SLESS":
        return z3.If(a < b, one, zero)
    if opcode == "INT_CARRY":
        return z3.If(z3.UGT(z3.ZeroExt(1, a) + z3.ZeroExt(1, b),
                            z3.ZeroExt(1, m_all)), one, zero)
    if opcode == "INT_SCARRY":
        return z3.If(z3.SignExt(1, (a + b) & m_all) !=
                     z3.SignExt(1, a) + z3.SignExt(1, b), one, zero)
    if opcode == "INT_SBORROW":
        return z3.If(z3.SignExt(1, (a - b) & m_all) !=
                     z3.SignExt(1, a) - z3.SignExt(1, b), one, zero)
    if opcode == "BOOL_AND":
        return z3.If(z3.And(a != zero, b != zero), one, zero)
    if opcode == "BOOL_OR":
        return z3.If(z3.Or(a != zero, b != zero), one, zero)
    if opcode == "BOOL_XOR":
        return z3.If((a != zero) != (b != zero), one, zero)
    raise KeyError(opcode)


def folder_unary_sym(opcode: str, a: z3.BitVecRef, bits: int) -> z3.BitVecRef:
    m_all = z3.BitVecVal((1 << bits) - 1, bits)
    zero, one = z3.BitVecVal(0, bits), z3.BitVecVal(1, bits)
    a = a & m_all
    if opcode == "COPY":
        return a
    if opcode == "INT_NEGATE":
        return (~a) & m_all
    if opcode == "INT_2COMP":
        return (-a) & m_all
    if opcode == "BOOL_NEGATE":
        return z3.If(a == zero, one, zero)
    raise KeyError(opcode)


# --------------------------------------------------------------------------
# Table VII identities
# --------------------------------------------------------------------------

IDENTITIES: Dict[str, Callable[[z3.BitVecRef, z3.BitVecRef, int], z3.BoolRef]] = {
    "add_zero":        lambda x, y, w: x + z3.BitVecVal(0, w) == x,
    "sub_self":        lambda x, y, w: x - x == z3.BitVecVal(0, w),
    "mult_one":        lambda x, y, w: x * z3.BitVecVal(1, w) == x,
    "mult_zero":       lambda x, y, w: x * z3.BitVecVal(0, w) == z3.BitVecVal(0, w),
    "and_self":        lambda x, y, w: x & x == x,
    "or_self":         lambda x, y, w: x | x == x,
    "xor_self":        lambda x, y, w: x ^ x == z3.BitVecVal(0, w),
    "xor_zero":        lambda x, y, w: x ^ z3.BitVecVal(0, w) == x,
    "and_allones":     lambda x, y, w: x & z3.BitVecVal((1 << w) - 1, w) == x,
    "or_zero":         lambda x, y, w: x | z3.BitVecVal(0, w) == x,
    "double_negate":   lambda x, y, w: ~(~x) == x,
    "double_2comp":    lambda x, y, w: -(-x) == x,
    "negate_2comp":    lambda x, y, w: ~x + z3.BitVecVal(1, w) == -x,
    "add_comm":        lambda x, y, w: x + y == y + x,
    "mult_comm":       lambda x, y, w: x * y == y * x,
    "and_comm":        lambda x, y, w: x & y == y & x,
    "or_comm":         lambda x, y, w: x | y == y | x,
    "xor_comm":        lambda x, y, w: x ^ y == y ^ x,
    "demorgan_and":    lambda x, y, w: ~(x & y) == (~x) | (~y),
    "demorgan_or":     lambda x, y, w: ~(x | y) == (~x) & (~y),
    "sub_as_add":      lambda x, y, w: x - y == x + (-y),
    "shl_is_mult2":    lambda x, y, w: (x << z3.BitVecVal(1, w)) ==
                                       x * z3.BitVecVal(2, w),
    "shr_shr":         lambda x, y, w: z3.Implies(
                                       z3.ULT(z3.BitVecVal(3, w), z3.BitVecVal(w, w)),
                                       z3.LShR(z3.LShR(x, z3.BitVecVal(1, w)),
                                               z3.BitVecVal(2, w)) ==
                                       z3.LShR(x, z3.BitVecVal(3, w))),
    "xor_assoc":       lambda x, y, w: (x ^ y) ^ x == y,
    "and_or_absorb":   lambda x, y, w: x & (x | y) == x,
    "or_and_absorb":   lambda x, y, w: x | (x & y) == x,
    "add_assoc_const": lambda x, y, w: (x + z3.BitVecVal(3, w)) + z3.BitVecVal(5, w)
                                       == x + z3.BitVecVal(8, w),
    "mba_xor":         lambda x, y, w: (x ^ y) == (x | y) - (x & y),
    "mba_add":         lambda x, y, w: x + y == (x ^ y) + ((x & y) << z3.BitVecVal(1, w)),
    "mba_or":          lambda x, y, w: (x | y) == x + y - (x & y),
}


# --------------------------------------------------------------------------
# Flag obligations
# --------------------------------------------------------------------------

def flag_obligations(bits: int) -> List[Tuple[str, z3.BoolRef]]:
    a, b = z3.BitVecs("a b", bits)
    out = []
    wide_a, wide_b = z3.ZeroExt(1, a), z3.ZeroExt(1, b)
    carry = z3.Extract(bits, bits, wide_a + wide_b) == z3.BitVecVal(1, 1)
    out.append(("carry_matches_wide_add",
                z3_binary("INT_CARRY", a, b, bits) ==
                z3.If(carry, z3.BitVecVal(1, bits), z3.BitVecVal(0, bits))))
    sa, sb = z3.SignExt(1, a), z3.SignExt(1, b)
    ovf_add = sa + sb != z3.SignExt(1, a + b)
    out.append(("scarry_matches_signed_overflow",
                z3_binary("INT_SCARRY", a, b, bits) ==
                z3.If(ovf_add, z3.BitVecVal(1, bits), z3.BitVecVal(0, bits))))
    ovf_sub = sa - sb != z3.SignExt(1, a - b)
    out.append(("sborrow_matches_signed_underflow",
                z3_binary("INT_SBORROW", a, b, bits) ==
                z3.If(ovf_sub, z3.BitVecVal(1, bits), z3.BitVecVal(0, bits))))
    return out


# --------------------------------------------------------------------------
# Driver
# --------------------------------------------------------------------------

def prove(claim: z3.BoolRef, timeout_ms: int = 20_000) -> Tuple[str, str]:
    s = z3.Solver()
    s.set("timeout", timeout_ms)
    s.add(z3.Not(claim))
    r = s.check()
    if r == z3.unsat:
        return "valid", ""
    if r == z3.sat:
        return "invalid", str(s.model())
    return "unknown", str(r)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--widths", type=int, nargs="*", default=list(WIDTHS))
    ap.add_argument("--quick", action="store_true",
                    help="identities and flags only; skip the folder equivalences")
    ap.add_argument("--timeout-ms", type=int, default=20_000)
    ap.add_argument("--results", default="results")
    args = ap.parse_args()

    widths = tuple(args.widths)
    t0 = time.time()

    with RunLogger("tv3_smt", "measured", seed=0, dataset="n/a",
                   root=args.results,
                   config={"widths": list(widths), "z3": z3.get_version_string(),
                           "quick": args.quick}) as log:
        total = valid = invalid = unknown = 0
        by_group = {"fold": 0, "ident": 0, "flag": 0}

        def record(group: str, name: str, bits: int, claim: z3.BoolRef) -> None:
            nonlocal total, valid, invalid, unknown
            st = time.time()
            verdict, detail = prove(claim, args.timeout_ms)
            total += 1
            by_group[group] += 1
            if verdict == "valid":
                valid += 1
            elif verdict == "invalid":
                invalid += 1
                log.failure("obligation_invalid", group=group, name=name,
                            bits=bits, counterexample=detail)
            else:
                unknown += 1
                log.failure("obligation_unknown", group=group, name=name, bits=bits)
            log.event("obligation", group=group, name=name, bits=bits,
                      verdict=verdict, seconds=round(time.time() - st, 4))

        for bits in widths:
            a, b = z3.BitVecs("a b", bits)
            if not args.quick:
                for op in BINARY_OPS:
                    record("fold", f"folder=={op}", bits,
                           folder_binary_sym(op, a, b, bits) == z3_binary(op, a, b, bits))
                for op in UNARY_OPS:
                    record("fold", f"folder=={op}", bits,
                           folder_unary_sym(op, a, bits) == z3_unary(op, a, bits))
            for name, mk in IDENTITIES.items():
                record("ident", name, bits, mk(a, b, bits))
            for name, claim in flag_obligations(bits):
                record("flag", name, bits, claim)

        elapsed = round(time.time() - t0, 2)
        log.result(obligations=total, valid=valid, invalid=invalid,
                   unknown=unknown, by_group=by_group, widths=list(widths),
                   seconds=elapsed, z3_version=z3.get_version_string(),
                   passed=(invalid == 0 and unknown == 0))

    ok = invalid == 0 and unknown == 0
    print(f"TV3 {'PASS' if ok else 'FAIL'}: {total} obligations at widths "
          f"{list(widths)} -- {valid} valid, {invalid} invalid, {unknown} unknown, "
          f"{elapsed}s with Z3 {z3.get_version_string()}")
    print(f"     groups: " + ", ".join(f"{k}={v}" for k, v in by_group.items()))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
