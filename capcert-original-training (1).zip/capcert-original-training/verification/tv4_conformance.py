#!/usr/bin/env python3
"""TV4: certificate conformance, and the Property L0 audit.

Four things are checked on every sample, because the end-to-end guarantee
rests on all four and a proof about the specification says nothing about the
code:

  L0-audit     for every root, the content bytes the accessor recorded while
               building the view must equal the dependency set computed
               independently by ``lfr.dependency_closure``.  Two
               implementations that have to agree is what makes this able to
               fail; an audit that merely reported what the accessor recorded
               would pass vacuously.

  L0-diff      mutating a byte *outside* Dep_x(e) must leave kappa(f_e)
               bit-identical.  This is the forward direction of L0, and it is
               the direction the proof of Lemma 1 actually uses.

  Lemma1       every applied edit's measured footprint must lie within the
               bound Corollary 1 states for its family.

  Theorem2/4   for an edit sequence whose footprints sum to at most rho_hat(x),
               the verdict must not change; and the number of buckets whose
               content changed must not exceed k * d(x, x').

Passing cannot establish the guarantee, which rests on the proofs.  A single
failure reveals an implementation defect -- which is how the jump-table
off-by-one of Section VII-J was found, and ``l0_fault_injection.py`` puts that
defect back to show the audit catching it.

Usage
-----
    python verification/tv4_conformance.py --n 60 --sequences 4
"""
from __future__ import annotations

import argparse
import random
import sys
from collections import Counter
from pathlib import Path
from typing import List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from capcert.canonical import digest, edit_distance
from capcert.datasets import synthetic_corpus
from capcert.edits import (
    EDIT_FAMILIES,
    canonical_of_image,
    footprint_report,
)
from capcert.image import Accessor
from capcert.lfr import (
    RecoveryOptions,
    dependency_closure,
    enumerate_roots,
    recover_root,
)
from capcert.partition import PartitionConfig, theorem2_bound
from capcert.provenance import RunLogger
from capcert.vote import LinearBaseClassifier, VoteConfig, vote

FREE_FAMILIES = "abci"      # Corollary 1 says these cost nothing
PAID_FAMILIES = "defgh"


def l0_audit(image, opts: RecoveryOptions) -> List[dict]:
    """Compare recorded reads with the independently computed closure."""
    out = []
    for kind, name in enumerate_roots(image):
        acc = Accessor(image)
        rr = recover_root(image, name, kind, opts, accessor=acc)
        expected = dependency_closure(image, name, opts)
        extra = sorted(rr.dep_content - expected)[:16]
        missing = sorted(expected - rr.dep_content)[:16]
        undeclared = sorted(acc.undeclared())[:16]
        out.append({
            "root": name,
            "recorded": len(rr.dep_content),
            "expected": len(expected),
            "reads": acc.reads,
            "extra": extra,
            "missing": missing,
            "undeclared": undeclared,
            "ok": not extra and not missing and not undeclared,
        })
    return out


def l0_differential(image, opts: RecoveryOptions, rng: random.Random,
                    trials: int = 8) -> List[dict]:
    """Mutate bytes outside Dep_x(e); kappa(f_e) must not move."""
    out = []
    for kind, name in enumerate_roots(image):
        dep = dependency_closure(image, name, opts)
        base = digest(recover_root(image, name, kind, opts).function)
        outside = [i for i in range(len(image.data)) if i not in dep]
        if not outside:
            continue
        for _ in range(trials):
            pos = rng.choice(outside)
            mutant = image.copy()
            mutant.data[pos] = (mutant.data[pos] + 1 + rng.randrange(254)) & 0xFF
            try:
                after = digest(recover_root(mutant, name, kind, opts).function)
            except Exception as exc:          # a corrupted table is not an L0 failure
                out.append({"root": name, "offset": pos, "ok": True,
                            "note": f"undecodable after mutation: {type(exc).__name__}"})
                continue
            out.append({"root": name, "offset": pos, "ok": after == base})
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=60)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--sequences", type=int, default=4,
                    help="edit sequences per certified sample")
    ap.add_argument("--B", type=int, default=64)
    ap.add_argument("--k", type=int, default=2)
    ap.add_argument("--t", type=int, default=3)
    ap.add_argument("--results", default="results")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    opts = RecoveryOptions()
    pcfg = PartitionConfig(B=args.B, k=args.k)
    vcfg = VoteConfig(t=args.t)

    corpus, images = synthetic_corpus(n_malicious=args.n // 2,
                                      n_benign=args.n // 2, seed=args.seed)
    mal = [s for s in corpus.samples if s.is_malicious and not s.excluded_by_a1]

    # a fixed, transparent base classifier: positive on any bucket holding a
    # digest seen in malicious training images
    train_digests = set()
    for s in mal[: max(1, len(mal) // 2)]:
        train_digests |= set(canonical_of_image(images[s.sha256]).keys())
    g = LinearBaseClassifier.fit_reference(sorted(train_digests))

    with RunLogger("tv4_conformance", "original", seed=args.seed,
                   dataset="original", root=args.results,
                   config={"B": args.B, "k": args.k, "t": args.t,
                           "sequences": args.sequences}) as log:
        audit_roots = audit_bad = 0
        diff_trials = diff_bad = 0
        fp_checked = fp_bad = 0
        thm2_checked = thm2_bad = 0
        certified = 0
        verdict_changes = 0
        fam_counts: Counter = Counter()

        for s in mal:
            img = images[s.sha256]

            for rec in l0_audit(img, opts):
                audit_roots += 1
                if not rec["ok"]:
                    audit_bad += 1
                    log.failure("l0_audit", binary=s.sha256[:16], **rec)
                log.event("l0_audit", binary=s.sha256[:16], **rec)

            for rec in l0_differential(img, opts, rng, trials=3):
                diff_trials += 1
                if not rec["ok"]:
                    diff_bad += 1
                    log.failure("l0_differential", binary=s.sha256[:16], **rec)

            cx = canonical_of_image(img, opts)
            v = vote(cx, g, pcfg, vcfg)
            if v.label != 1:
                log.event("not_detected", binary=s.sha256[:16], votes=v.votes)
                continue
            certified += 1
            budget = v.radius or 0
            log.event("certified", binary=s.sha256[:16], votes=v.votes,
                      radius=budget)

            for _ in range(args.sequences):
                cur, spent, applied = img, 0, []
                # fill the budget with paid edits, then free ones
                for _ in range(8):
                    fam = rng.choice(PAID_FAMILIES if spent < budget else FREE_FAMILIES)
                    res = EDIT_FAMILIES[fam](cur, rng)
                    rep = footprint_report(cur, res, opts)
                    fp_checked += 1
                    fam_counts[fam] += 1
                    if not rep.within_bound:
                        fp_bad += 1
                        log.failure("corollary1_bound", binary=s.sha256[:16],
                                    family=fam, measured=rep.measured,
                                    bound=rep.bound)
                    if spent + rep.measured > budget:
                        continue           # would exceed rho_hat; skip this edit
                    cy = canonical_of_image(res.image, opts)
                    changed, cap = theorem2_bound(canonical_of_image(cur, opts),
                                                  cy, pcfg)
                    thm2_checked += 1
                    if changed > cap:
                        thm2_bad += 1
                        log.failure("theorem2_bound", binary=s.sha256[:16],
                                    changed=changed, cap=cap)
                    spent += rep.measured
                    applied.append((fam, rep.measured))
                    cur = res.image

                cz = canonical_of_image(cur, opts)
                total = edit_distance(cx, cz)
                v2 = vote(cz, g, pcfg, vcfg)
                changed_verdict = int(v2.label != 1)
                verdict_changes += changed_verdict
                if changed_verdict:
                    log.failure("verdict_changed_inside_radius",
                                binary=s.sha256[:16], radius=budget,
                                charged=spent, measured_total=total,
                                votes_before=v.votes, votes_after=v2.votes,
                                sequence=[f"{f}:{c}" for f, c in applied])
                log.event("sequence", binary=s.sha256[:16], radius=budget,
                          charged=spent, measured_total=total,
                          votes_before=v.votes, votes_after=v2.votes,
                          verdict_changed=bool(changed_verdict),
                          sequence=[f"{f}:{c}" for f, c in applied])

        passed = (audit_bad == 0 and diff_bad == 0 and fp_bad == 0
                  and thm2_bad == 0 and verdict_changes == 0)
        log.result(
            certified_samples=certified,
            l0_audit_roots=audit_roots, l0_audit_failures=audit_bad,
            l0_differential_trials=diff_trials, l0_differential_failures=diff_bad,
            footprints_checked=fp_checked, corollary1_violations=fp_bad,
            theorem2_checked=thm2_checked, theorem2_violations=thm2_bad,
            verdict_changes_inside_radius=verdict_changes,
            edits_by_family=dict(fam_counts),
            expected={"l0_audit_failures": 0, "l0_differential_failures": 0,
                      "corollary1_violations": 0, "theorem2_violations": 0,
                      "verdict_changes_inside_radius": 0},
            passed=passed,
        )

    print(f"TV4 {'PASS' if passed else 'FAIL'}")
    print(f"     L0 audit:        {audit_roots} roots, {audit_bad} with reads "
          f"outside Dep")
    print(f"     L0 differential: {diff_trials} mutations outside Dep, "
          f"{diff_bad} that moved kappa")
    print(f"     Corollary 1:     {fp_checked} footprints, {fp_bad} outside bound")
    print(f"     Theorem 2:       {thm2_checked} edits, {thm2_bad} moving more "
          f"than k*d buckets")
    print(f"     Theorem 4:       {certified} certified samples, "
          f"{verdict_changes} verdict changes inside the radius")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
