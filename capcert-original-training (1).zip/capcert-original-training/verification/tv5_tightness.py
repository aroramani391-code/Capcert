#!/usr/bin/env python3
"""TV5: the Theorem 5 construction, and bucket occupancy against Proposition 1.

Two measurements, neither of which proves anything:

  tightness  On samples with a small rho_hat(x), run the construction in the
             proof of Theorem 5 -- reserve candidate canonical functions, hash
             them, and look for one whose bucket set covers a prescribed group
             -- against a *synthetic adversarial* base classifier g'.  Record
             whether a flip occurs at rho_hat(x) + 1 and how many hash
             evaluations it took, and compare that cost with 1/q_k.

  occupancy  Compare measured |S_b(x)| with E|S_b(x)| of equation (32).

The adversarial g' is the point and the limitation at once.  Theorem 5 exhibits
a classifier that agrees with g_theta on every bucket content of x and is free
to answer benign on contents it has never seen; that is what this harness
builds.  It therefore measures how reachable the *construction* is on real
bucket geometry.  It says nothing about whether a trained classifier can be
flipped at that budget, and the manuscript does not claim it does.

Usage
-----
    python verification/tv5_tightness.py --n 40 --candidates 20000
"""
from __future__ import annotations

import argparse
import math
import random
import statistics
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Set, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from capcert.canonical import digest
from capcert.datasets import synthetic_corpus
from capcert.edits import _new_leaf, canonical_of_image
from capcert.lfr import RecoveryOptions
from capcert.partition import (
    PartitionConfig,
    bucket_indices,
    expected_occupancy,
    occupancy,
    q_k,
)
from capcert.provenance import RunLogger
from capcert.vote import LinearBaseClassifier, VoteConfig, vote


def candidate_digests(n: int, seed: int) -> List[str]:
    """Assumption G's variant supply: distinct canonical functions, each
    insertable at footprint one (Corollary 1(d)).

    Built the way the manuscript says: functions returning distinct constants,
    reached through a new export.  The constant is live-out, so
    canonicalization keeps it and the forms stay distinct.
    """
    out = []
    for i in range(n):
        out.append(digest(_new_leaf(f"cand{i}", (seed << 20) + i)))
    return out


def find_cover(
    group: Sequence[int], cands: Sequence[str], pcfg: PartitionConfig
) -> Tuple[Optional[str], int]:
    """Search for a candidate whose k buckets contain the prescribed group.

    Returns the candidate and the number of hash evaluations spent, which is
    the quantity Theorem 5 predicts to be about 1/q_k.
    """
    want = set(group)
    evals = 0
    for dg in cands:
        evals += pcfg.k
        if want <= set(bucket_indices(dg, pcfg)):
            return dg, evals
    return None, evals


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=40)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--B", type=int, default=64)
    ap.add_argument("--k", type=int, default=2)
    ap.add_argument("--t", type=int, default=3)
    ap.add_argument("--candidates", type=int, default=20_000,
                    help="reserved candidates per group (Assumption G's M/u)")
    ap.add_argument("--results", default="results")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    opts = RecoveryOptions()
    pcfg = PartitionConfig(B=args.B, k=args.k)
    vcfg = VoteConfig(t=args.t)

    corpus, images = synthetic_corpus(n_malicious=args.n, n_benign=args.n,
                                      seed=args.seed)
    mal = [s for s in corpus.samples if s.is_malicious and not s.excluded_by_a1]

    train = set()
    for s in mal[: max(1, len(mal) // 2)]:
        train |= set(canonical_of_image(images[s.sha256], opts).keys())
    g = LinearBaseClassifier.fit_reference(sorted(train))

    cands = candidate_digests(args.candidates, args.seed)
    qk = q_k(pcfg)
    predicted = 1.0 / qk if qk > 0 else float("inf")

    with RunLogger("tv5_tightness", "original", seed=args.seed,
                   dataset="original", root=args.results,
                   config={"B": args.B, "k": args.k, "t": args.t,
                           "candidates": args.candidates}) as log:
        attempts = flips = 0
        eval_costs: List[int] = []
        occ_ratios: List[float] = []

        for s in mal:
            cx = canonical_of_image(images[s.sha256], opts)
            n_funcs = sum(cx.values())
            obs = occupancy(cx, pcfg)
            exp = expected_occupancy(n_funcs, pcfg)
            if exp > 0:
                ratio = statistics.mean(obs) / exp
                occ_ratios.append(ratio)
                log.event("occupancy", binary=s.sha256[:16], n_functions=n_funcs,
                          mean_observed=round(statistics.mean(obs), 4),
                          expected=round(exp, 4), ratio=round(ratio, 4),
                          max_observed=max(obs))

            v = vote(cx, g, pcfg, vcfg)
            if v.label != 1:
                continue
            D = v.votes - vcfg.t + 1
            u = math.ceil(D / pcfg.k)
            if u != (v.radius or 0) + 1:
                log.event("u_mismatch", binary=s.sha256[:16], u=u, radius=v.radius)
            malicious_buckets = [b for b, z in enumerate(v.logits) if z > 0.0]
            if len(malicious_buckets) < D:
                continue
            chosen = malicious_buckets[:D]
            groups = [chosen[i:i + pcfg.k] for i in range(0, D, pcfg.k)]

            attempts += 1
            per_group = args.candidates // max(1, len(groups))
            covered: List[str] = []
            total_evals = 0
            for gi, grp in enumerate(groups):
                pool = cands[gi * per_group:(gi + 1) * per_group]
                dg, ev = find_cover(grp, pool, pcfg)
                total_evals += ev
                if dg is not None:
                    covered.append(dg)
                    eval_costs.append(ev)
            success = len(covered) == len(groups)
            if success:
                # g' agrees with g on every bucket content of x and answers
                # benign on the new contents of the chosen buckets
                flipped_votes = v.votes - D
                if flipped_votes < vcfg.t:
                    flips += 1
            log.event("tightness_attempt", binary=s.sha256[:16],
                      votes=v.votes, radius=v.radius, D=D, u=u,
                      groups=len(groups), construction_succeeded=success,
                      hash_evaluations=total_evals,
                      inserted=len(covered))

        failure_bound = None
        if eval_costs:
            m_per_group = args.candidates // max(1, pcfg.k)
            failure_bound = math.exp(-m_per_group * qk)

        log.result(
            attempts=attempts,
            flips_at_radius_plus_one=flips,
            flip_rate_percent=round(100.0 * flips / attempts, 2) if attempts else None,
            mean_hash_evaluations=round(statistics.mean(eval_costs), 1) if eval_costs else None,
            predicted_hash_evaluations=round(predicted, 1),
            q_k=qk,
            theorem5_failure_bound_per_group=failure_bound,
            occupancy_ratio_mean=round(statistics.mean(occ_ratios), 4) if occ_ratios else None,
            occupancy_within_percent=(
                round(abs(statistics.mean(occ_ratios) - 1.0) * 100, 2)
                if occ_ratios else None),
            note=("measurement only: the flip is exhibited against an adversarial "
                  "base classifier, not against the trained g_theta"),
        )

    print("TV5 (measurement, not a proof)")
    print(f"     construction attempted on {attempts} certified samples; "
          f"{flips} flipped at rho_hat+1 against an adversarial g'")
    if eval_costs:
        print(f"     hash evaluations: {statistics.mean(eval_costs):.0f} measured "
              f"vs {predicted:.0f} predicted by 1/q_k")
    if occ_ratios:
        print(f"     bucket occupancy within "
              f"{abs(statistics.mean(occ_ratios)-1)*100:.1f}% of equation (32)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
