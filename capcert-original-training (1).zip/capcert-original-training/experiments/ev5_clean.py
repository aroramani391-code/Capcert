#!/usr/bin/env python3
"""EV5: clean detection, with the training run that produces the checkpoint.

Trains the base classifier with the certified-margin MIL objective, writes a
checkpoint plus the metadata needed to reproduce it, and reports clean
detection on the test split with bootstrap intervals.

This is the script every other EV runner's checkpoint comes from, so it is
also where per-seed training logs are written.

    python experiments/ev5_clean.py --n 200 --seeds 0 1 2 3 4
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from _common import (BUDGETS, RunLogger, base_parser, build, configs,  # noqa: E402
                     evaluate_split, fit, seeds_of)

from capcert.model import save_checkpoint                 # noqa: E402
from capcert.stats import bootstrap_metric, mean_sd       # noqa: E402


def main() -> int:
    ap = base_parser("EV5: clean detection and the training run")
    ap.add_argument("--bootstrap", type=int, default=2000)
    args = ap.parse_args()
    pcfg, vcfg, tcfg = configs(args)

    per_seed_f1, per_seed_ca = {}, {}

    for seed in seeds_of(args):
        tcfg.seed = seed
        corpus, images, provenance, prep = build(args, seed, pcfg)

        with RunLogger("ev5_clean", provenance, seed=seed, dataset=args.dataset,
                       root=args.results,
                       config={"B": args.B, "k": args.k, "t": args.t,
                               "epochs": args.epochs,
                               "backend": tcfg.resolved_backend(),
                               "margin_m": tcfg.margin(pcfg),
                               "eta": tcfg.eta, "n": args.n}) as log:
            t0 = time.time()

            def on_epoch(epoch: int, tau: float, loss: float) -> None:
                log.event("epoch", epoch=epoch, tau=round(tau, 4),
                          loss=round(loss, 6))

            model = fit(prep, pcfg, vcfg, tcfg, on_epoch=on_epoch)
            train_s = round(time.time() - t0, 2)

            ckpt_dir = Path(args.results) / "checkpoints"
            ext = ".pt" if getattr(model, "kind", "") == "torch" else ".json"
            ckpt = ckpt_dir / f"{args.dataset}__B{args.B}_k{args.k}_t{args.t}__seed{seed}{ext}"
            save_checkpoint(model, ckpt, meta={
                "stamp": log.stamp.to_dict(),
                "partition": {"B": pcfg.B, "k": pcfg.k,
                              "occurrence_cap": pcfg.occurrence_cap},
                "vote": {"t": vcfg.t},
                "train": {"epochs": tcfg.epochs, "lr": tcfg.lr,
                          "weight_decay": tcfg.weight_decay,
                          "margin_m": tcfg.margin(pcfg), "eta": tcfg.eta,
                          "tau_start": tcfg.tau_start, "tau_end": tcfg.tau_end,
                          "anneal": tcfg.anneal, "backend": tcfg.resolved_backend()},
                "train_seconds": train_s,
                "n_train": len(corpus.split("train")),
            })
            log.event("checkpoint", path=str(ckpt), seconds=train_s)

            for split in ("val", "test"):
                samples = corpus.split(split)
                res = evaluate_split(prep, model, pcfg, vcfg, samples)
                y_true = [1 if s.is_malicious else 0 for s in samples]
                y_pred = [r["predicted"] for r in res["per_sample"]]
                f1, ci = bootstrap_metric(y_true, y_pred, "f1",
                                          n_resamples=args.bootstrap, seed=seed)
                log.event("split_result", split=split,
                          clean={k: v for k, v in res["clean"].items()},
                          f1=f1, f1_interval=list(ci),
                          certified_accuracy=res["certified_accuracy"],
                          median_radius=res["median_radius"])
                if split == "test":
                    per_seed_f1[seed] = f1
                    ca2 = res["certified_accuracy"].get(2)
                    per_seed_ca[seed] = ca2["value"] if ca2 else None
                    log.result(checkpoint=str(ckpt), train_seconds=train_s,
                               test_f1=f1, test_f1_interval=list(ci),
                               test_clean=res["clean"],
                               certified_accuracy=res["certified_accuracy"],
                               median_radius=res["median_radius"],
                               n_test=res["n"], n_test_malware=res["n_malicious"])

    f1m, f1s = mean_sd(list(per_seed_f1.values()))
    cav = [v for v in per_seed_ca.values() if v is not None]
    cam, cas = mean_sd(cav) if cav else (float("nan"), float("nan"))
    print(f"EV5 over seeds {sorted(per_seed_f1)}: "
          f"test F1 {f1m:.2f} +/- {f1s:.2f}, CA(2) {cam:.2f} +/- {cas:.2f}")
    print(f"     checkpoints in {Path(args.results) / 'checkpoints'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
