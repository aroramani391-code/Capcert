#!/usr/bin/env python3
"""EV4/EV8: adaptive attacks and partition stress -- Tables XVIII and XIX.

Three attacks are implemented here and all three are *white box*: they know
the hash keys, the canonicalizer and the threshold, which is the attacker
Theorem 4 is stated against.

  bucket-targeting   synthesize canonical functions that land in the buckets
                     currently voting malicious, and insert them through new
                     root-table entries (Corollary 1(d), one unit each).
  dilution           insert benign canonical functions drawn from the corpus
                     to push malicious evidence below the threshold.
  duplicate-flooding insert copies of one canonical function repeatedly, which
                     is what the occurrence cap of Table XIV exists to blunt.

The adaptive attack *generator* of Section VIII-E -- the one that searches for
functionality-preserving problem-space edits against a real PE -- is not in
this repository and will not be: it is evasion tooling, and the restriction is
documented in docs/RESTRICTED.md.  What is here operates on the canonical
representation only, needs the keys, and cannot be pointed at a binary to
produce a working evasive sample.  No certified result depends on the withheld
component.

Results are empirical robust accuracy, which is an upper bound on robust
accuracy for the attacks tried.  It is never evidence of robustness, and the
run labels it as such.

    python experiments/ev4_attacks.py --n 200 --budget-max 12
"""
from __future__ import annotations

import random
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from _common import RunLogger, base_parser, build, configs, fit  # noqa: E402

from capcert.canonical import digest, edit_distance              # noqa: E402
from capcert.edits import _new_leaf                              # noqa: E402
from capcert.partition import bucket_indices                     # noqa: E402
from capcert.stats import Proportion                             # noqa: E402
from capcert.vote import as_base_classifier, vote                # noqa: E402


def synth_variants(n: int, seed: int) -> List[str]:
    return [digest(_new_leaf(f"v{i}", (seed << 22) + i)) for i in range(n)]


def attack_bucket_targeting(cx: Counter, model, pcfg, vcfg, budget: int,
                            variants: List[str]) -> Tuple[Counter, int]:
    """Insert variants that land in buckets currently voting malicious."""
    g = as_base_classifier(model)
    cur = Counter(cx)
    spent = 0
    for _ in range(budget):
        v = vote(cur, g, pcfg, vcfg)
        hot = {b for b, z in enumerate(v.logits) if z > 0.0}
        if not hot:
            break
        best, best_hit = None, -1
        for dg in variants:
            hit = len(hot & set(bucket_indices(dg, pcfg)))
            if hit > best_hit:
                best, best_hit = dg, hit
            if best_hit == pcfg.k:
                break
        if best is None or best_hit <= 0:
            break
        cur[best] += 1
        spent += 1
    return cur, spent


def attack_dilution(cx: Counter, benign_pool: List[str], budget: int,
                    rng: random.Random) -> Tuple[Counter, int]:
    cur = Counter(cx)
    spent = 0
    for _ in range(budget):
        if not benign_pool:
            break
        cur[rng.choice(benign_pool)] += 1
        spent += 1
    return cur, spent


def attack_duplicate_flood(cx: Counter, budget: int) -> Tuple[Counter, int]:
    cur = Counter(cx)
    if not cur:
        return cur, 0
    target = max(cur, key=lambda d: (cur[d], d))
    cur[target] += budget
    return cur, budget


def main() -> int:
    ap = base_parser("EV4/EV8: adaptive attacks and partition stress")
    ap.add_argument("--budget-max", type=int, default=12)
    ap.add_argument("--variants", type=int, default=4000)
    args = ap.parse_args()
    pcfg, vcfg, tcfg = configs(args)

    corpus, images, provenance, prep = build(args, args.seed, pcfg)
    model = fit(prep, pcfg, vcfg, tcfg)
    rng = random.Random(args.seed)
    variants = synth_variants(args.variants, args.seed)

    benign_pool: List[str] = []
    for s in corpus.split("train"):
        if not s.is_malicious:
            benign_pool.extend(prep.canonical[s.sha256].keys())
    benign_pool = sorted(set(benign_pool))

    with RunLogger("ev4_attacks", provenance, seed=args.seed,
                   dataset=args.dataset, root=args.results,
                   config={"budget_max": args.budget_max,
                           "variants": args.variants,
                           "B": args.B, "k": args.k, "t": args.t}) as log:
        inside_attempts = inside_flips = 0
        beyond_attempts = beyond_flips = 0
        era: Dict[int, List[int]] = {u: [] for u in range(args.budget_max + 1)}

        for s in corpus.split("test"):
            if not s.is_malicious:
                continue
            cx = prep.canonical[s.sha256]
            v0 = vote(cx, model, pcfg, vcfg)
            if v0.label != 1:
                continue
            r = v0.radius or 0

            for u in range(args.budget_max + 1):
                survived = 1
                for name, run in (
                    ("bucket_targeting",
                     lambda: attack_bucket_targeting(cx, model, pcfg, vcfg, u, variants)),
                    ("dilution",
                     lambda: attack_dilution(cx, benign_pool, u, rng)),
                    ("duplicate_flood",
                     lambda: attack_duplicate_flood(cx, u)),
                ):
                    cy, spent = run()
                    d = edit_distance(cx, cy)
                    v1 = vote(cy, model, pcfg, vcfg)
                    flipped = int(v1.label != 1)
                    survived &= (1 - flipped)
                    if d <= r:
                        inside_attempts += 1
                        inside_flips += flipped
                        if flipped:
                            log.failure("flip_inside_radius",
                                        binary=s.sha256[:16], attack=name,
                                        radius=r, distance=d,
                                        votes_before=v0.votes, votes_after=v1.votes)
                    else:
                        beyond_attempts += 1
                        beyond_flips += flipped
                    log.event("attack", binary=s.sha256[:16], attack=name,
                              budget=u, distance=d, radius=r,
                              votes_before=v0.votes, votes_after=v1.votes,
                              flipped=bool(flipped))
                era[u].append(survived)

        era_rows = {u: {"value": Proportion(sum(v), len(v)).value,
                        "interval": list(Proportion(sum(v), len(v)).interval),
                        "n": len(v)}
                    for u, v in era.items() if v}
        inside_p = Proportion(inside_flips, max(1, inside_attempts))
        passed = inside_flips == 0
        log.result(
            empirical_robust_accuracy=era_rows,
            attempts_inside_radius=inside_attempts,
            flips_inside_radius=inside_flips,
            flip_rate_inside_radius=inside_p.value,
            attempts_beyond_radius=beyond_attempts,
            flips_beyond_radius=beyond_flips,
            flip_rate_beyond_radius=round(
                100.0 * beyond_flips / beyond_attempts, 2) if beyond_attempts else None,
            expected={"flips_inside_radius": 0},
            passed=passed,
            note=("empirical robust accuracy is an upper bound for the attacks "
                  "tried and is never evidence of robustness; the certificate "
                  "is the evidence"),
        )

    print(f"EV4/EV8 {'PASS' if passed else 'FAIL'} (Tables XVIII, XIX)")
    print(f"     inside the radius: {inside_flips} flips in {inside_attempts} "
          f"attempts (Theorem 4 requires 0)")
    if beyond_attempts:
        print(f"     beyond the radius: {beyond_flips} flips in "
              f"{beyond_attempts} attempts "
              f"({100.0*beyond_flips/beyond_attempts:.1f}%)")
    for u in sorted(era_rows)[:8]:
        print(f"     ERA(u={u:>2}) = {era_rows[u]['value']:.2f}%")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
