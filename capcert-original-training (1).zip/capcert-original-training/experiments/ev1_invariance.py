#!/usr/bin/env python3
"""EV1: obfuscation invariance (Theorem 1), the data behind Table XX.

For each transformation class, apply it to every function of every sample and
measure the share whose canonical form is unchanged.  Classes in T_inv must
come out at 100.0%: Theorem 1 says the canonical form is identical, not merely
close, so anything below 100 is a defect rather than a weaker result.

Out-of-class obfuscations are reported alongside, and they are expected *not*
to be cancelled.  Reporting them is the honest half of the claim: it shows
what the invariant class does not cover.

    python experiments/ev1_invariance.py --n 120 --repeats 3
"""
from __future__ import annotations

import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from _common import RunLogger, base_parser, configs  # noqa: E402

from capcert.canonical import digest                 # noqa: E402
from capcert.edits import (                          # noqa: E402
    OUT_OF_CLASS, T_INV, T_INV_OPS, image_functions, out_of_class,
)
from capcert.pipeline import load_corpus             # noqa: E402
from capcert.stats import Proportion                 # noqa: E402


def main() -> int:
    ap = base_parser("EV1: obfuscation invariance")
    ap.add_argument("--repeats", type=int, default=3,
                    help="transformation applications per function")
    args = ap.parse_args()
    pcfg, vcfg, tcfg = configs(args)

    corpus, images, provenance = load_corpus(args.dataset, args.manifest,
                                             n=args.n, seed=args.seed)
    rng = random.Random(args.seed)

    with RunLogger("ev1_invariance", provenance, seed=args.seed,
                   dataset=args.dataset, root=args.results,
                   config={"repeats": args.repeats, "n": args.n}) as log:
        tally = {name: [0, 0] for name in list(T_INV) + list(OUT_OF_CLASS)
                 + ["all_in_class_combined"]}

        for s in corpus.samples:
            for fname, fn in sorted(image_functions(images[s.sha256]).items()):
                base = digest(fn)
                for cls in T_INV:
                    for _ in range(args.repeats):
                        g = T_INV_OPS[cls](fn, rng)
                        same = digest(g) == base
                        tally[cls][0] += int(same)
                        tally[cls][1] += 1
                        if not same:
                            log.failure("invariance_broken", cls=cls,
                                        binary=s.sha256[:16], function=fname)
                for _ in range(args.repeats):
                    g = fn
                    for cls in T_INV:
                        g = T_INV_OPS[cls](g, rng)
                    same = digest(g) == base
                    tally["all_in_class_combined"][0] += int(same)
                    tally["all_in_class_combined"][1] += 1
                    if not same:
                        log.failure("invariance_broken", cls="combined",
                                    binary=s.sha256[:16], function=fname)
                for cls in OUT_OF_CLASS:
                    for _ in range(max(1, args.repeats // 2)):
                        g = out_of_class(cls, fn, rng)
                        tally[cls][0] += int(digest(g) == base)
                        tally[cls][1] += 1

        rows = {}
        for name, (same, total) in tally.items():
            p = Proportion(same, total)
            rows[name] = {"in_class": name in T_INV or name.startswith("all_"),
                          "unchanged": same, "trials": total,
                          "rate_percent": p.value, "interval": list(p.interval)}
            log.event("class_result", cls=name, **rows[name])

        in_class_ok = all(rows[c]["rate_percent"] == 100.0
                          for c in list(T_INV) + ["all_in_class_combined"])
        log.result(classes=rows, in_class_all_100=in_class_ok,
                   expected={"in_class_rate_percent": 100.0}, passed=in_class_ok)

    print(f"EV1 {'PASS' if in_class_ok else 'FAIL'} (Table XX)")
    for name in list(T_INV) + ["all_in_class_combined"]:
        r = rows[name]
        print(f"     in-class  {name:28s} {r['rate_percent']:6.2f}%  "
              f"({r['unchanged']}/{r['trials']})")
    for name in OUT_OF_CLASS:
        r = rows[name]
        print(f"     out-class {name:28s} {r['rate_percent']:6.2f}%  "
              f"({r['unchanged']}/{r['trials']})")
    return 0 if in_class_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
