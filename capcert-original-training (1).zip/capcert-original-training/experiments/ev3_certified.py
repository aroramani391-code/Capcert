#!/usr/bin/env python3
"""EV3: certified accuracy against budget -- the data behind Table XVII.

Loads a checkpoint from EV5 (or trains one), computes rho_hat(x) for every
malware test sample in one pass over the buckets, and reports CA(u) with its
exact Clopper-Pearson interval at each budget, together with the counts the
proportion is computed over.

Convention C1 is enforced by the pipeline: a malware sample the detector
misses receives no certificate and is never counted as certified at any
budget, so CA(0) is the clean detection rate on malware and every later
budget is a subset of it.

    python experiments/ev3_certified.py --n 300 --seeds 0 1 2
"""
from __future__ import annotations

import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from _common import (BUDGETS, RunLogger, base_parser, build,  # noqa: E402
                     configs, evaluate_split, fit, seeds_of)

from capcert.stats import mean_sd                    # noqa: E402


def main() -> int:
    ap = base_parser("EV3: certified accuracy")
    ap.add_argument("--checkpoint", default=None,
                    help="reuse a checkpoint instead of training")
    args = ap.parse_args()
    pcfg, vcfg, tcfg = configs(args)

    per_seed = {u: {} for u in BUDGETS}
    medians = {}

    for seed in seeds_of(args):
        tcfg.seed = seed
        corpus, images, provenance, prep = build(args, seed, pcfg)

        with RunLogger("ev3_certified", provenance, seed=seed,
                       dataset=args.dataset, root=args.results,
                       config={"B": args.B, "k": args.k, "t": args.t,
                               "budgets": list(BUDGETS)}) as log:
            if args.checkpoint:
                from capcert.model import load_checkpoint

                model = load_checkpoint(args.checkpoint, tcfg)
                log.event("checkpoint_loaded", path=args.checkpoint)
            else:
                model = fit(prep, pcfg, vcfg, tcfg)

            res = evaluate_split(prep, model, pcfg, vcfg, corpus.split("test"))
            for u, cell in res["certified_accuracy"].items():
                per_seed[u][seed] = cell["value"]
                log.event("budget", u=u, **cell)
            medians[seed] = res["median_radius"]
            log.result(certified_accuracy=res["certified_accuracy"],
                       median_radius=res["median_radius"],
                       clean=res["clean"], n_test=res["n"],
                       n_test_malware=res["n_malicious"],
                       unit="canonical-function edits")

    print("EV3 (Table XVII): certified accuracy on malware test samples")
    print(f"     {'budget u':>10}  {'CA(u) %':>18}  seeds={sorted(medians)}")
    for u in BUDGETS:
        m, s = mean_sd(list(per_seed[u].values()))
        print(f"     {u:>10}  {m:>8.2f} +/- {s:<6.2f}")
    mm, ms = mean_sd([v for v in medians.values() if v is not None])
    print(f"     median certified radius {mm:.1f} +/- {ms:.1f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
