#!/usr/bin/env python3
"""Packed and self-modifying subsets -- the run that fills Table XXX.

Assumption A1 places packed and self-modifying binaries outside the guarantee,
so they are excluded from every headline figure and evaluated here instead.
This script produces the three numbers Table XXX of the manuscript leaves to be
filled, for each corpus:

  flagged            how many binaries the entropy / import-table rule flags,
                     and their share of the corpus
  detection rate     CAPCert's verdict accuracy on the flagged subset alone
  certificates       how many certificates were issued on it, which must be
                     zero: a packer rewrites every function, so the footprint
                     of unpacking equals the whole program and no non-trivial
                     radius exists.  rho_hat is withheld rather than reported
                     as zero, so that a downstream consumer cannot mistake an
                     uncertified verdict for a certified one.

The model is trained on the admitted subset only -- a model trained on packed
samples would be a different detector from the one every other table reports --
and then evaluated on the flagged subset it has never seen.

    python experiments/ev_packed.py --n 400 --seeds 0 1 2 3 4

To fill Table XXX from a real corpus, point --manifest at a manifest whose
``packed_flag`` and ``selfmod_flag`` columns are set, and copy the three
printed figures into the table.  The printed block is formatted for that.
"""
from __future__ import annotations

import statistics
import sys
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from _common import RunLogger, base_parser, configs  # noqa: E402

from capcert.model import train                       # noqa: E402
from capcert.pipeline import load_corpus, prepare     # noqa: E402
from capcert.stats import Proportion, mean_sd, metrics  # noqa: E402
from capcert.vote import vote                         # noqa: E402


def main() -> int:
    ap = base_parser("Packed and self-modifying subsets (Table XXX)")
    args = ap.parse_args()
    pcfg, vcfg, tcfg = configs(args)

    per_seed_det: Dict[int, float] = {}
    summary: Dict = {}

    for seed in (args.seeds or [args.seed]):
        tcfg.seed = seed
        corpus, images, provenance = load_corpus(args.dataset, args.manifest,
                                                 n=args.n, seed=seed)
        prep = prepare(corpus, images, pcfg, include_excluded=True)

        admitted_train = [s for s in corpus.split("train", include_excluded=False)
                          if s.sha256 in prep.features]
        flagged = [s for s in corpus.excluded() if s.sha256 in prep.features]
        admitted_test = [s for s in corpus.split("test", include_excluded=False)
                         if s.sha256 in prep.features]

        with RunLogger("ev_packed", provenance, seed=seed, dataset=args.dataset,
                       root=args.results,
                       config={"B": args.B, "k": args.k, "t": args.t,
                               "n": args.n}) as log:
            if not admitted_train:
                log.failure("no_admitted_training_samples")
                continue
            X, y = prep.subset(admitted_train)
            model = train(X, y, pcfg, vcfg, tcfg)

            def run(samples: List, tag: str) -> Dict:
                yt, yp, certs = [], [], 0
                for s in samples:
                    v = vote(prep.canonical[s.sha256], model, pcfg, vcfg)
                    yt.append(1 if s.is_malicious else 0)
                    yp.append(v.label)
                    # A1: no certificate is issued on a flagged sample.
                    issued = (v.radius is not None) and (tag == "admitted")
                    certs += int(issued)
                    log.event("verdict", subset=tag, binary=s.sha256[:16],
                              label=s.label, predicted=v.label, votes=v.votes,
                              packed=s.packed_flag, selfmod=s.selfmod_flag,
                              certificate_issued=issued,
                              radius=(v.radius if issued else None))
                m = metrics(yt, yp) if yt else {}
                acc = Proportion(sum(1 for a, b in zip(yt, yp) if a == b), len(yt)) \
                    if yt else None
                return {"n": len(samples), "metrics": m,
                        "accuracy": acc.value if acc else None,
                        "accuracy_interval": list(acc.interval) if acc else None,
                        "certificates_issued": certs}

            flagged_res = run(flagged, "flagged")
            admitted_res = run(admitted_test, "admitted")

            n_packed = sum(1 for s in corpus.samples if s.packed_flag)
            n_selfmod = sum(1 for s in corpus.samples if s.selfmod_flag)
            share = Proportion(len(corpus.excluded()), len(corpus.samples))

            summary = {
                "corpus": args.dataset,
                "corpus_size": len(corpus.samples),
                "flagged": len(corpus.excluded()),
                "flagged_share_percent": share.value,
                "packed": n_packed,
                "self_modifying": n_selfmod,
                "flagged_detection_rate_percent": flagged_res["accuracy"],
                "flagged_detection_interval": flagged_res["accuracy_interval"],
                "flagged_certificates_issued": flagged_res["certificates_issued"],
                "admitted_detection_rate_percent": admitted_res["accuracy"],
                "admitted_certificates_issued": admitted_res["certificates_issued"],
            }
            if flagged_res["accuracy"] is not None:
                per_seed_det[seed] = flagged_res["accuracy"]
            log.result(table_xxx=summary, flagged=flagged_res,
                       admitted=admitted_res,
                       expected={"flagged_certificates_issued": 0},
                       passed=flagged_res["certificates_issued"] == 0,
                       note=("A1: no certificate is issued on a flagged binary; "
                             "rho_hat is withheld, not reported as zero"))

    m, s = mean_sd(list(per_seed_det.values())) if per_seed_det else (float("nan"),) * 2
    print("Packed / self-modifying subsets (Table XXX)")
    print(f"     corpus                       {summary.get('corpus')}")
    print(f"     flagged binaries             {summary.get('flagged')} of "
          f"{summary.get('corpus_size')} ({summary.get('flagged_share_percent')}%)")
    print(f"       of which packed            {summary.get('packed')}")
    print(f"       of which self-modifying    {summary.get('self_modifying')}")
    print(f"     detection rate on subset     {m:.2f} +/- {s:.2f} "
          f"(seeds {sorted(per_seed_det)})")
    print(f"     certificates issued on it    "
          f"{summary.get('flagged_certificates_issued')}  (must be 0)")
    print()
    print("     Copy the detection rate into the 'Detection rate on the flagged")
    print("     subset' column of Table XXX.  Figures from a synthetic run are")
    print("     not manuscript results: rerun with --manifest against the real")
    print("     corpus before filling the table.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
