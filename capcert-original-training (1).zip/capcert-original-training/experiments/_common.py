"""Shared plumbing for the EV runners."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from capcert.lfr import RecoveryOptions           # noqa: E402,F401
from capcert.model import TrainConfig              # noqa: E402
from capcert.partition import PartitionConfig      # noqa: E402
from capcert.pipeline import (                     # noqa: E402,F401
    BUDGETS, evaluate_split, fit, load_corpus, prepare,
)
from capcert.provenance import RunLogger           # noqa: E402,F401
from capcert.vote import VoteConfig                # noqa: E402


def base_parser(description: str) -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description=description)
    ap.add_argument("--dataset", default="original",
                    help="corpus name; with --manifest this names the real corpus")
    ap.add_argument("--manifest", default=None,
                    help="CSV manifest of a real corpus (see docs/REAL_DATA.md)")
    ap.add_argument("--n", type=int, default=120, help="original training corpus size")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--seeds", type=int, nargs="*", default=None,
                    help="run several seeds and aggregate (default: just --seed)")
    ap.add_argument("--B", type=int, default=64)
    ap.add_argument("--k", type=int, default=2)
    ap.add_argument("--t", type=int, default=6)
    ap.add_argument("--epochs", type=int, default=25)
    ap.add_argument("--backend", default="auto", choices=("auto", "torch", "numpy"))
    ap.add_argument("--results", default="results")
    return ap


def configs(args) -> Tuple[PartitionConfig, VoteConfig, TrainConfig]:
    pcfg = PartitionConfig(B=args.B, k=args.k)
    vcfg = VoteConfig(t=args.t)
    tcfg = TrainConfig(epochs=args.epochs, seed=args.seed, backend=args.backend)
    return pcfg, vcfg, tcfg


def seeds_of(args):
    return args.seeds if args.seeds else [args.seed]


def build(args, seed: int, pcfg: PartitionConfig, include_excluded: bool = True):
    corpus, images, provenance = load_corpus(
        args.dataset, args.manifest, n=args.n, seed=seed)
    prep = prepare(corpus, images, pcfg, include_excluded=include_excluded)
    return corpus, images, provenance, prep
