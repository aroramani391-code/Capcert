#!/usr/bin/env python3
"""EV2a/EV2b: recovery locality and coverage -- Tables XXI and XXII.

EV2a  ownership counts omega_x(v), and the measured footprint of every edit
      family against the bound Corollary 1 states for it.  Every footprint
      must lie within its bound; the share that does is the "within bound"
      column of Table XXII.

EV2b  what locality costs in coverage: LFR against LFR+D on the same images.
      LFR+D follows code pointers held in data, so it recovers functions LFR
      cannot see -- and gives up the locality bound for them, which is why it
      is not the default.  The gap is the coverage limitation Section VII-E
      discusses, and the point of measuring it is that the certified radius is
      a statement about the recovered program, not the whole program.

    python experiments/ev2_recovery.py --n 120 --trials 4
"""
from __future__ import annotations

import random
import statistics
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from _common import RunLogger, base_parser, configs  # noqa: E402

from capcert.edits import (                          # noqa: E402
    EDIT_FAMILIES, FAMILIES, canonical_of_image, footprint_report,
)
from capcert.lfr import RecoveryOptions, enumerate_roots, ownership, recover  # noqa: E402
from capcert.pipeline import load_corpus             # noqa: E402
from capcert.stats import Proportion                 # noqa: E402


def main() -> int:
    ap = base_parser("EV2: recovery locality and coverage")
    ap.add_argument("--trials", type=int, default=4,
                    help="edits per family per binary")
    args = ap.parse_args()
    pcfg, vcfg, tcfg = configs(args)

    corpus, images, provenance = load_corpus(args.dataset, args.manifest,
                                             n=args.n, seed=args.seed)
    rng = random.Random(args.seed)
    lfr = RecoveryOptions(follow_data_pointers=False)
    lfr_d = RecoveryOptions(follow_data_pointers=True)

    with RunLogger("ev2_recovery", provenance, seed=args.seed,
                   dataset=args.dataset, root=args.results,
                   config={"trials": args.trials, "n": args.n}) as log:
        omegas: list[int] = []
        per_family: dict[str, list[int]] = {f: [] for f in FAMILIES}
        within: dict[str, list[int]] = {f: [] for f in FAMILIES}

        for s in corpus.samples:
            img = images[s.sha256]
            om = ownership(img, lfr)
            if om:
                omegas.extend(om.values())
                log.event("ownership", binary=s.sha256[:16],
                          max_omega=max(om.values()),
                          mean_omega=round(statistics.mean(om.values()), 3),
                          bytes_owned=len(om))
            for fam in FAMILIES:
                for _ in range(args.trials):
                    res = EDIT_FAMILIES[fam](img, rng)
                    rep = footprint_report(img, res, lfr)
                    per_family[fam].append(rep.measured)
                    within[fam].append(int(rep.within_bound))
                    if not rep.within_bound:
                        log.failure("footprint_exceeds_bound", family=fam,
                                    binary=s.sha256[:16],
                                    measured=rep.measured, bound=rep.bound)
                    log.event("footprint", family=fam, binary=s.sha256[:16],
                              measured=rep.measured, bound=rep.bound,
                              within_bound=rep.within_bound)

        table_xxii = {}
        for fam, vals in per_family.items():
            ok = within[fam]
            p = Proportion(sum(ok), len(ok))
            table_xxii[fam] = {
                "family": FAMILIES[fam],
                "median": statistics.median(vals) if vals else None,
                "mean": round(statistics.mean(vals), 3) if vals else None,
                "max": max(vals) if vals else None,
                "within_bound_percent": p.value,
                "n": len(vals),
            }
            log.event("family_summary", code=fam, **table_xxii[fam])

        # EV2b: coverage of LFR against LFR+D on the same images
        cov = []
        for s in corpus.samples:
            img = images[s.sha256]
            a = sum(canonical_of_image(img, lfr).values())
            b = sum(canonical_of_image(img, lfr_d).values())
            cov.append((a, b))
            log.event("coverage", binary=s.sha256[:16], lfr=a, lfr_d=b)
        tot_a = sum(a for a, _ in cov)
        tot_b = sum(b for _, b in cov)

        all_within = all(v["within_bound_percent"] == 100.0
                         for v in table_xxii.values())
        log.result(
            table_xxii=table_xxii,
            omega={"max": max(omegas) if omegas else None,
                   "mean": round(statistics.mean(omegas), 3) if omegas else None,
                   "share_above_one": round(
                       100.0 * sum(1 for o in omegas if o > 1) / len(omegas), 2)
                   if omegas else None},
            coverage={"functions_lfr": tot_a, "functions_lfr_d": tot_b,
                      "recall_relative_percent": round(100.0 * tot_a / tot_b, 2)
                      if tot_b else None},
            all_footprints_within_bound=all_within,
            passed=all_within,
            note=("recall here is relative to LFR+D on the same images, not to "
                  "compiler ground truth; a measured run against PDB symbols "
                  "is what Table XXI reports"),
        )

    print(f"EV2 {'PASS' if all_within else 'FAIL'} (Tables XXI, XXII)")
    for fam, v in table_xxii.items():
        print(f"     ({fam}) {v['family']:32s} median={v['median']:>5} "
              f"max={v['max']:>5}  within bound {v['within_bound_percent']:.1f}%")
    if omegas:
        print(f"     omega: max {max(omegas)}, "
              f"{100.0*sum(1 for o in omegas if o>1)/len(omegas):.1f}% of bytes "
              f"owned by more than one root")
    print(f"     coverage: LFR sees {tot_a} canonical functions against "
          f"{tot_b} for LFR+D")
    if tot_a == tot_b:
        print("     note: this corpus contains no functions reachable only "
              "through code pointers held in data, so the coverage gap is zero "
              "by construction and this row measures nothing. Table XXI's recall "
              "figures come from a measured run against PDB ground truth; see "
              "docs/REAL_DATA.md.")
    return 0 if all_within else 1


if __name__ == "__main__":
    raise SystemExit(main())
