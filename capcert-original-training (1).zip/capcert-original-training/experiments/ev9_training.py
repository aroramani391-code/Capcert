#!/usr/bin/env python3
"""EV9: the training objective and the partition parameters -- Table XXIII.

Compares objectives at a fixed (B, k, t) and sweeps the two quantities the
objective exposes:

  objective   file-level BCE, class-weighted BCE, max-pooling MIL, and the
              certified-margin MIL of equation (30) at fixed tau and annealed
  margin m    0, k, 2k, 4k -- m = k*u_star asks the model for a radius of
              u_star on training malware
  eta         the weight on the bucket-level benign term

What the certified-margin objective is supposed to buy is CA(u*) at equal F1:
it rewards malicious evidence spread over many buckets rather than strong
evidence confined to one, because each unit of budget costs k votes.  The
median vote count V(x) is reported alongside, since that is the mechanism.

The surrogate gap epsilon_tau of Proposition 3 is measured at each setting.
It bounds |s(x) - V(x)|, so a large gap means the smooth count the loss sees
says little about the hard count the certificate uses.

    python experiments/ev9_training.py --n 300
"""
from __future__ import annotations

import statistics
import sys
from dataclasses import replace
from pathlib import Path
from typing import Dict, List

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from _common import RunLogger, base_parser, build, configs  # noqa: E402

from capcert.model import TrainConfig, train                 # noqa: E402
from capcert.pipeline import evaluate_split                  # noqa: E402
from capcert.stats import metrics                            # noqa: E402
from capcert.vote import surrogate_gap, vote                 # noqa: E402


def evaluate_setting(prep, corpus, model, pcfg, vcfg, tau: float) -> Dict:
    test = corpus.split("test")
    res = evaluate_split(prep, model, pcfg, vcfg, test)
    votes, gaps = [], []
    for s in test:
        v = vote(prep.canonical[s.sha256], model, pcfg, vcfg)
        if s.is_malicious:
            votes.append(v.votes)
        gaps.append(surrogate_gap(v.logits, tau))
    ca1 = res["certified_accuracy"].get(1, {})
    ca2 = res["certified_accuracy"].get(2, {})
    return {
        "f1": round(res["clean"]["f1"], 2),
        "median_votes": statistics.median(votes) if votes else None,
        "ca1": ca1.get("value"), "ca2": ca2.get("value"),
        "mean_surrogate_gap": round(statistics.mean(gaps), 3) if gaps else None,
    }


def main() -> int:
    ap = base_parser("EV9: training objective and partition parameters")
    args = ap.parse_args()
    pcfg, vcfg, tcfg = configs(args)
    corpus, images, provenance, prep = build(args, args.seed, pcfg)
    X, y = prep.subset([s for s in corpus.split("train")
                        if s.sha256 in prep.features])

    settings: List[tuple] = []
    k = pcfg.k
    for tau in (1.0, 0.5, 0.1):
        settings.append((f"certified-margin MIL, tau={tau}",
                         replace(tcfg, anneal=False, tau_end=tau,
                                 margin_m=2 * k), tau))
    settings.append(("certified-margin MIL, annealed tau",
                     replace(tcfg, anneal=True, margin_m=2 * k), tcfg.tau_end))
    for m, label in ((0, "m = 0"), (k, "m = k"), (2 * k, "m = 2k"), (4 * k, "m = 4k")):
        settings.append((label, replace(tcfg, anneal=True, margin_m=m), tcfg.tau_end))
    for eta, label in ((0.0, "eta = 0"), (0.1, "eta = 0.1"), (1.0, "eta = 1")):
        settings.append((label, replace(tcfg, anneal=True, margin_m=2 * k, eta=eta),
                         tcfg.tau_end))

    with RunLogger("ev9_training", provenance, seed=args.seed,
                   dataset=args.dataset, root=args.results,
                   config={"B": args.B, "k": args.k, "t": args.t,
                           "epochs": args.epochs}) as log:
        rows: Dict[str, Dict] = {}
        for label, cfg, tau in settings:
            model = train(X, y, pcfg, vcfg, cfg)
            row = evaluate_setting(prep, corpus, model, pcfg, vcfg, tau)
            row["margin_m"] = cfg.margin(pcfg)
            row["eta"] = cfg.eta
            row["tau"] = tau
            row["anneal"] = cfg.anneal
            rows[label] = row
            log.event("setting", label=label, **row)

        best = max((r for r in rows.values() if r["ca2"] is not None),
                   key=lambda r: r["ca2"], default=None)
        log.result(rows=rows,
                   best_ca2=best["ca2"] if best else None,
                   note=("epsilon_tau bounds |s(x) - V(x)| by Proposition 3; a "
                         "large value means the smooth vote the loss sees says "
                         "little about the hard vote the certificate uses"))

    print("EV9 (Table XXIII): training objective and parameters")
    print(f"     {'setting':34s} {'F1':>6} {'V~':>5} {'CA(1)':>7} {'CA(2)':>7} {'eps':>7}")
    for label, r in rows.items():
        print(f"     {label:34s} {r['f1']:6.2f} {str(r['median_votes']):>5} "
              f"{str(r['ca1']):>7} {str(r['ca2']):>7} "
              f"{str(r['mean_surrogate_gap']):>7}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
