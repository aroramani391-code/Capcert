#!/usr/bin/env python3
"""EV8: partition stress tests -- Table XIX.

Measures the geometry the certificate depends on, independently of any
classifier:

  occupancy      |S_b(x)| against E|S_b(x)| of equation (32), which is where
                 Proposition 1's accuracy-radius trade-off comes from.
  collisions     how often the k hashes of one canonical form coincide, which
                 wastes a vote and is the reason Theorem 2's bound is k rather
                 than exactly k.
  crowding       occupancy on the largest programs in the corpus, where the
                 bucket a vote comes from holds the most evidence.
  occurrence cap the effect of the Table XIV readout cap under duplicate
                 flooding: with the cap off, inserting many copies of one
                 canonical form lets a single form dominate a bucket's readout.

Nothing here needs a trained model, which is the point: these are properties
of the partition, so they hold for any base classifier plugged into it.

    python experiments/ev8_partition.py --n 200
"""
from __future__ import annotations

import statistics
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from _common import RunLogger, base_parser, configs  # noqa: E402

from capcert.edits import canonical_of_image         # noqa: E402
from capcert.partition import (                      # noqa: E402
    PartitionConfig, bucket_indices, expected_occupancy, occupancy, q_k,
    readout_vector,
)
from capcert.pipeline import load_corpus             # noqa: E402


def main() -> int:
    ap = base_parser("EV8: partition stress tests")
    ap.add_argument("--flood", type=int, default=64,
                    help="duplicate copies inserted in the flooding test")
    args = ap.parse_args()
    pcfg, vcfg, tcfg = configs(args)

    corpus, images, provenance = load_corpus(args.dataset, args.manifest,
                                             n=args.n, seed=args.seed)

    with RunLogger("ev8_partition", provenance, seed=args.seed,
                   dataset=args.dataset, root=args.results,
                   config={"B": args.B, "k": args.k, "flood": args.flood}) as log:
        ratios, occupied, collisions, totals = [], [], 0, 0
        crowd = []

        for s in corpus.samples:
            cx = canonical_of_image(images[s.sha256])
            n = sum(cx.values())
            if n == 0:
                continue
            obs = occupancy(cx, pcfg)
            exp = expected_occupancy(n, pcfg)
            ratios.append(statistics.mean(obs) / exp if exp else 0.0)
            occupied.append(sum(1 for o in obs if o > 0))
            crowd.append((n, max(obs)))
            for dg in cx:
                idx = bucket_indices(dg, pcfg)
                totals += 1
                collisions += int(len(set(idx)) < pcfg.k)
            log.event("occupancy", binary=s.sha256[:16], functions=n,
                      mean_observed=round(statistics.mean(obs), 3),
                      expected=round(exp, 3), occupied=occupied[-1],
                      max_bucket=max(obs))

        # Duplicate flooding, with the occurrence cap on and off.  The test
        # only says anything in a bucket that holds several distinct canonical
        # forms -- in a bucket holding one form the readout is that form
        # whatever the multiplicity -- so pick the most crowded bucket in the
        # corpus and flood a form that lives in it.
        from capcert.partition import buckets as _buckets

        best = None
        for s_ in corpus.samples:
            cxx = canonical_of_image(images[s_.sha256])
            bs = _buckets(cxx, pcfg)
            for bi, content in bs.items():
                if len(content) >= 2 and (best is None or len(content) > best[2]):
                    best = (cxx, bi, len(content))
        if best is None:
            cx = canonical_of_image(images[corpus.samples[0].sha256])
            b = 0
        else:
            cx, b, _ = best
        target = max(_buckets(cx, pcfg)[b], key=lambda d: (cx[d], d))
        flooded = Counter(cx)
        flooded[target] += args.flood
        capped = PartitionConfig(B=pcfg.B, k=pcfg.k, occurrence_cap=pcfg.occurrence_cap)
        uncapped = PartitionConfig(B=pcfg.B, k=pcfg.k, occurrence_cap=10 ** 9)
        from capcert.partition import buckets as _buckets

        # How far does flooding move the bucket's readout away from what it
        # was?  Cosine similarity with the un-flooded readout is the useful
        # measure: a cap that works keeps the other canonical forms in the
        # bucket visible, so the vector stays close to the original.
        def cos(a, b):
            num = sum(x * y for x, y in zip(a, b))
            da = sum(x * x for x in a) ** 0.5
            db = sum(y * y for y in b) ** 0.5
            return num / (da * db) if da and db else 0.0

        base_vec = readout_vector(_buckets(cx, capped)[b], capped)
        v_cap = readout_vector(_buckets(flooded, capped)[b], capped)
        v_unc = readout_vector(_buckets(flooded, uncapped)[b], uncapped)
        dom_cap = cos(base_vec, v_cap)
        dom_unc = cos(base_vec, v_unc)
        log.event("duplicate_flood", bucket=b, copies=args.flood,
                  bucket_forms=len(_buckets(cx, capped)[b]),
                  similarity_to_unflooded_capped=round(dom_cap, 4),
                  similarity_to_unflooded_uncapped=round(dom_unc, 4))

        coll_rate = round(100.0 * collisions / totals, 3) if totals else None
        log.result(
            occupancy_ratio_mean=round(statistics.mean(ratios), 4) if ratios else None,
            occupancy_within_percent=round(
                abs(statistics.mean(ratios) - 1.0) * 100, 2) if ratios else None,
            occupied_buckets_mean=round(statistics.mean(occupied), 2) if occupied else None,
            B=pcfg.B, k=pcfg.k, q_k=q_k(pcfg),
            hash_collision_rate_percent=coll_rate,
            crowding_max_bucket=max((c for _, c in crowd), default=None),
            duplicate_flood={"copies": args.flood,
                             "similarity_to_unflooded_capped": round(dom_cap, 4),
                             "similarity_to_unflooded_uncapped": round(dom_unc, 4),
                             "cap": pcfg.occurrence_cap},
        )

    print("EV8 (Table XIX): partition geometry")
    if ratios:
        print(f"     occupancy within {abs(statistics.mean(ratios)-1)*100:.2f}% "
              f"of equation (32); {statistics.mean(occupied):.1f} of {pcfg.B} "
              f"buckets occupied on average")
    print(f"     k-hash collision rate {coll_rate}% over {totals} canonical forms")
    print(f"     duplicate flooding ({args.flood} copies): readout stays "
          f"{dom_cap:.3f} similar to the un-flooded bucket with the cap, "
          f"{dom_unc:.3f} without")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
