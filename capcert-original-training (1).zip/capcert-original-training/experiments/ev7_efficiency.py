#!/usr/bin/env python3
"""EV7: end-to-end cost per stage -- Table XXV.

Times every stage of the pipeline separately, because the claim in the
manuscript is about the *end-to-end* cost including recovery, and a figure
that leaves recovery out is not comparable with a detector that has to
disassemble first.

Stages timed: recovery (Stage 1), canonicalization (Stage 2, the rewrite
system), partition and readout (Stage 3), inference and the vote (Stages 4-5),
and the certificate itself (Theorem 3, one pass over the buckets).

The absolute numbers depend entirely on the machine and on the reference
Python implementation; they are reported per stage and per binary so that the
shape of the cost is visible even when the magnitude is not comparable with a
Rust build.

    python experiments/ev7_efficiency.py --n 120
"""
from __future__ import annotations

import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from _common import RunLogger, base_parser, build, configs, fit  # noqa: E402

from capcert.canonical import canonical_multiset                 # noqa: E402
from capcert.lfr import RecoveryOptions, recover                 # noqa: E402
from capcert.model import bucket_features                        # noqa: E402
from capcert.vote import vote                                    # noqa: E402


def main() -> int:
    ap = base_parser("EV7: end-to-end efficiency")
    args = ap.parse_args()
    pcfg, vcfg, tcfg = configs(args)

    corpus, images, provenance, prep = build(args, args.seed, pcfg)
    model = fit(prep, pcfg, vcfg, tcfg)
    opts = RecoveryOptions()

    with RunLogger("ev7_efficiency", provenance, seed=args.seed,
                   dataset=args.dataset, root=args.results,
                   config={"B": args.B, "k": args.k,
                           "backend": tcfg.resolved_backend()}) as log:
        stages = {"recover_ms": [], "canonicalize_ms": [], "partition_ms": [],
                  "inference_ms": [], "certificate_ms": [], "total_ms": []}
        sizes = []

        for s in corpus.split("test"):
            img = images[s.sha256]
            t0 = time.perf_counter()
            roots = recover(img, opts)
            t1 = time.perf_counter()
            cx = canonical_multiset([r.function for r in roots])
            t2 = time.perf_counter()
            feats = bucket_features(cx, pcfg)
            t3 = time.perf_counter()
            v = vote(cx, model, pcfg, vcfg)
            t4 = time.perf_counter()
            _ = v.radius            # computed in the same pass; timed separately
            t5 = time.perf_counter()

            row = {
                "recover_ms": (t1 - t0) * 1e3,
                "canonicalize_ms": (t2 - t1) * 1e3,
                "partition_ms": (t3 - t2) * 1e3,
                "inference_ms": (t4 - t3) * 1e3,
                "certificate_ms": (t5 - t4) * 1e3,
                "total_ms": (t5 - t0) * 1e3,
            }
            for k, val in row.items():
                stages[k].append(val)
            sizes.append(len(img.data))
            log.event("sample", binary=s.sha256[:16], bytes=len(img.data),
                      functions=sum(cx.values()),
                      **{k: round(x, 3) for k, x in row.items()})

        summary = {k: {"mean_ms": round(statistics.mean(v), 3),
                       "median_ms": round(statistics.median(v), 3),
                       "p95_ms": round(sorted(v)[int(0.95 * len(v)) - 1], 3)}
                   for k, v in stages.items() if v}
        log.result(stages=summary, n=len(sizes),
                   mean_bytes=round(statistics.mean(sizes), 1) if sizes else None,
                   throughput_per_s=round(
                       1000.0 / statistics.mean(stages["total_ms"]), 2)
                   if stages["total_ms"] else None,
                   backend=tcfg.resolved_backend(),
                   note=("reference Python implementation on this machine; not "
                         "comparable with the Rust build the manuscript times"))

    print("EV7 (Table XXV): cost per stage, milliseconds per binary")
    for k, v in summary.items():
        print(f"     {k:18s} mean {v['mean_ms']:8.2f}  median {v['median_ms']:8.2f}"
              f"  p95 {v['p95_ms']:8.2f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
