#!/usr/bin/env python3
"""EV6: generalization under distribution shift -- Table XXIV.

Three shifts, all of which train on one population and test on another:

  temporal        train on the earlier collection, test on the later
  family-disjoint hold out whole families from training
  cross-source    separate training and test files by collection source

The cross-source split is the one that matters most and the one whose result
should be read next to every headline number.  When a corpus draws its benign
and malicious files from different places -- installed software on one side, a
threat-intelligence feed on the other -- a model can separate the classes by
provenance rather than by behaviour, and the random-split figure is inflated by
however much of that shortcut it used.  The cross-source row removes the
shortcut and so bounds the inflation.

The certificate is the more fragile quantity under every shift, because a
verdict needs only V(x) >= t while a radius of u needs V(x) >= t + ku.  A
deployment that relies on the radius therefore needs recalibrating more often
than accuracy alone would suggest.

    python experiments/ev6_generalization.py --n 300
"""
from __future__ import annotations

import sys
from dataclasses import replace
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from _common import RunLogger, base_parser, configs  # noqa: E402

from capcert.datasets import Corpus, Sample          # noqa: E402
from capcert.model import train                       # noqa: E402
from capcert.pipeline import evaluate_split, load_corpus, prepare  # noqa: E402


def respilt(corpus: Corpus, kind: str) -> Corpus:
    """Re-split the corpus by a criterion other than chance."""
    out: List[Sample] = []
    if kind == "random":
        return corpus
    if kind == "cross_source":
        sources = sorted({s.source for s in corpus.samples})
        test_src = set(sources[: max(1, len(sources) // 2)])
        for s in corpus.samples:
            out.append(replace(s, split="test" if s.source in test_src else "train"))
    elif kind == "family_disjoint":
        fams = sorted({s.family for s in corpus.samples if s.family})
        held = set(fams[: max(1, len(fams) // 3)])
        for s in corpus.samples:
            is_test = s.family in held if s.family else (hash(s.sha256) % 5 == 0)
            out.append(replace(s, split="test" if is_test else "train"))
    elif kind == "temporal":
        for s in corpus.samples:
            later = int(s.sha256[:2], 16) >= 0xC0
            out.append(replace(s, split="test" if later else "train"))
    else:
        raise KeyError(kind)
    return Corpus(corpus.name, out, corpus.provenance)


def main() -> int:
    ap = base_parser("EV6: generalization under distribution shift")
    args = ap.parse_args()
    pcfg, vcfg, tcfg = configs(args)

    corpus, images, provenance = load_corpus(args.dataset, args.manifest,
                                             n=args.n, seed=args.seed)

    with RunLogger("ev6_generalization", provenance, seed=args.seed,
                   dataset=args.dataset, root=args.results,
                   config={"B": args.B, "k": args.k, "t": args.t}) as log:
        rows: Dict[str, Dict] = {}
        for kind in ("random", "temporal", "family_disjoint", "cross_source"):
            c = respilt(corpus, kind)
            prep = prepare(c, images, pcfg)
            tr = [s for s in c.split("train") if s.sha256 in prep.features]
            te = [s for s in c.split("test") if s.sha256 in prep.features]
            if not tr or not te:
                log.event("skipped", split=kind, n_train=len(tr), n_test=len(te))
                continue
            X, y = prep.subset(tr)
            model = train(X, y, pcfg, vcfg, tcfg)
            res = evaluate_split(prep, model, pcfg, vcfg, te)
            ca1 = res["certified_accuracy"].get(1, {})
            ca2 = res["certified_accuracy"].get(2, {})
            rows[kind] = {
                "n_train": len(tr), "n_test": len(te),
                "f1": round(res["clean"]["f1"], 2),
                "ca1": ca1.get("value"), "ca2": ca2.get("value"),
                "median_radius": res["median_radius"],
            }
            log.event("split_result", split=kind, **rows[kind],
                      certified_accuracy=res["certified_accuracy"])

        base = rows.get("random")
        deltas = {}
        if base:
            for kind, r in rows.items():
                if kind == "random":
                    continue
                deltas[kind] = {
                    "delta_f1": round(r["f1"] - base["f1"], 2),
                    "delta_ca2": (round(r["ca2"] - base["ca2"], 2)
                                  if r["ca2"] is not None and base["ca2"] is not None
                                  else None),
                }
        log.result(rows=rows, deltas_against_random=deltas,
                   note=("the cross-source row bounds how much of the random-split "
                         "result provenance could explain"))

    print("EV6 (Table XXIV): F1 and certified accuracy under shift")
    for kind, r in rows.items():
        d = deltas.get(kind, {})
        df1 = d.get("delta_f1")
        dca = d.get("delta_ca2")
        suffix_f1 = "" if kind == "random" else f"  (dF1 {df1:+.2f})"
        suffix_ca = "" if kind == "random" else f"  (dCA {dca})"
        print(f"     {kind:16s} F1 {r['f1']:6.2f}{suffix_f1}"
              f"   CA(2) {r['ca2']}{suffix_ca}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
